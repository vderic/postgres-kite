#include "chtab_int.h"
#include "support.h"

typedef struct slot_t slot_t;
struct slot_t {
  uint64_t hval;
  void *value;
};

struct chtab_t {
  slot_t *slot;  /* slot[capacity] */
  char *ctrl;    /* ctrl[capacity + 16] control bytes */
  uint32_t mask; /* capacity - 1  */
  int capacity;  /* number of slots */
  int nitem;     /* #valid entries in slot[] */
};

static void expand(chtab_t *tab, int xcapacity);

chtab_t *chtab_create() { return calloc(1, sizeof(chtab_t)); }

void chtab_destroy(chtab_t *tab) {
  if (tab) {
    chtab_reset(tab);
    free(tab);
  }
}

void chtab_reset(chtab_t *tab) {
  free(tab->slot);
  free(tab->ctrl);
  memset(tab, 0, sizeof(*tab));
}

static slot_t *find(const chtab_t *tab, uint64_t hval) {
  if (tab->nitem == 0)
    return 0;

  int h2 = H2(hval);
  int mask = tab->mask;
  slot_t *slot = tab->slot;
  const char *ctrl = tab->ctrl;

  for (int pos = H1(hval); 1; pos += 16) {
    pos &= mask;
    const char *group = ctrl + pos;
    // search for h2
    uint32_t candidate = match_byte(group, h2);
    while (candidate) {
      int i = __builtin_ffs(candidate) - 1;
      slot_t *s = &slot[(pos + i) & mask];
      if (s->hval == hval) {
        return s;
      }
      candidate &= ~(1 << i);
    }
    if (match_empty(group)) {
      return 0;
    }
  }
}

static slot_t *emplace(chtab_t *tab, uint64_t hval) {
  int pos = H1(hval);
  int mask = tab->mask;
  slot_t *slot = tab->slot;
  char *ctrl = tab->ctrl;

  int ngroup = tab->capacity / 16;
  for (int g = 0; g < ngroup; g++) {
    pos &= mask;
    char *group = ctrl + pos;
    // search for h2
    uint32_t candidate = match_empty_or_deleted(group);
    if (!candidate) {
      pos += 16;
      continue;
    }

    // Point of no return. Take up the slot.
    // Caller will fill in key/klen/value.

    int i = __builtin_ffs(candidate) - 1;
    char ctrlch = group[i];
    assert(ctrlch <= DELETED);
    (void)ctrlch;
    // tab->ndeleted -= (ctrlch == DELETED);

    set_ctrl(tab->capacity, ctrl,
             (pos + i) >= tab->capacity ? (pos + i) - tab->capacity : (pos + i),
             H2(hval));

    return &slot[(pos + i) & mask];
  }

  // completely full and cannot accomodate another insert
  return 0;
}

static void expand(chtab_t *tab, int xcapacity) {
  // printf("expand %d!\n", xcapacity);
  xcapacity = (xcapacity < tab->capacity) ? tab->capacity : xcapacity;
  xcapacity = (xcapacity < 16) ? 16 : xcapacity;
  xcapacity = next_pow2(xcapacity);
  if (xcapacity < 0) {
    return; // can't expand beyond MAXINT
  }

  char *xctrl = 0;
  slot_t *xslot = 0;

  xctrl = calloc(1, xcapacity + 16);
  xslot = calloc(1, xcapacity * sizeof(*xslot));
  CHECKBAIL(xctrl && xslot);
  memset(xctrl, EMPTY, xcapacity + 16);

  // swap with tab
  SWAP(char *, xctrl, tab->ctrl);
  SWAP(slot_t *, xslot, tab->slot);
  SWAP(int, xcapacity, tab->capacity);
  // tab->ndeleted = 0;
  tab->mask = tab->capacity - 1;

  // go thru slots and emplace into new tab
  int inserted = 0;
  for (int i = 0; i < xcapacity; i++) {
    if (xctrl[i] >= 0) {
      slot_t *s = emplace(tab, xslot[i].hval);
      *s = xslot[i];
      inserted++;
    }
  }
  assert(tab->nitem == inserted);
  // assert(tab->ndeleted == 0);

bail:
  free(xctrl);
  free(xslot);
}

void **chtab_emplace_ex(chtab_t *tab, uint64_t hval) {
  // expand if necessary
  int capacity = tab->capacity;
  if (tab->nitem >= capacity * 0.8) {
    expand(tab, 2 * capacity);
  }

  // find a slot for key
  slot_t *s = emplace(tab, hval);
  s->hval = hval;
  s->value = 0;
  tab->nitem++;

  return &s->value;
}

void **chtab_emplace(chtab_t *tab, uint64_t hval) {
  slot_t *s = find(tab, hval);
  if (s) {
    // existing entry
    return &s->value;
  }
  return chtab_emplace_ex(tab, hval);
}

void **chtab_find(const chtab_t *tab, uint64_t hval) {
  slot_t *s = find(tab, hval);
  return s ? &s->value : 0;
}

int chtab_next(const chtab_t *tab, int idx, uint64_t *hval, void **value) {
  if (idx >= -1) {
    const char *ctrl = tab->ctrl;
    for (int i = idx + 1, top = tab->capacity; i < top; i++) {
      if (ctrl[i] >= 0) {
        *hval = tab->slot[i].hval;
        *value = tab->slot[i].value;
        return i;
      }
    }
  }
  return -1;
}

int chtab_first(const chtab_t *tab, uint64_t *hval, void **value) {
  return chtab_next(tab, -1, hval, value);
}
