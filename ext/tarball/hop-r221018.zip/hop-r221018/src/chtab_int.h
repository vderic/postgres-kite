#ifndef CHTAB_INT_H
#define CHTAB_INT_H

#include "chtab.h"

#include "komihash.h"
#include <assert.h>
#include <nmmintrin.h>

#define EMPTY -128 // 0b1000_0000
#define DELETED -2 // 0b1111_1110

#define H1(h) (((uint64_t)h) >> 7)
#define H2(h) ((uint8_t)(h & 0x7F))

#define SWAP(T, A, B)                                                          \
  do {                                                                         \
    T tmp = A;                                                                 \
    A = B;                                                                     \
    B = tmp;                                                                   \
  } while (0)

static inline uint32_t next_pow2(uint32_t x) {
  // next pow2(17) == 32
  // next_pow2(16) == 16
  // next_pow2(15) == 16
  return x == 1 ? 1 : 1 << (32 - __builtin_clz(x - 1));
}

static inline uint32_t match_byte(const char *group, int h2) {
  __m128i ctrl = _mm_loadu_si128((__m128i *)group);
  __m128i value = _mm_set1_epi8(h2);
  return _mm_movemask_epi8(_mm_cmpeq_epi8(value, ctrl));
}

static inline uint32_t match_empty(const char *group) {
#if 1
  // This only works because EMPTY is -128, and neg(-128) gives -128,
  // while neg(other negative char ch) gives abs(ch).
  __m128i ctrl = _mm_loadu_si128((__m128i *)group);
  return _mm_movemask_epi8(_mm_sign_epi8(ctrl, ctrl));
#else
  return match_byte(EMPTY);
#endif
}

static inline uint32_t match_empty_or_deleted(const char *group) {
  // find x where -1 > x.
  // x can only be a negative number less than -1.
  // DELETED is -2 & EMPTY is -128.
  __m128i value = _mm_set1_epi8(-1);
  __m128i ctrl = _mm_loadu_si128((__m128i *)group);
  return _mm_movemask_epi8(_mm_cmpgt_epi8(value, ctrl));
}

// Set group[i] to h2
static inline void set_ctrl(int capacity, char *ctrl, int idx, int h2) {
  assert(0 <= idx && idx < capacity);
  ctrl[idx] = h2;
  if (idx < 16) {
    // Clone the first 16 bytes to tail
    ctrl[capacity + idx] = h2;
  }
}

#endif /* CHTAB_INT_H */
