#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "hashjoin.h"
#include "arena.h"
#include "chtab.h"
#include "spill.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(hj, fmt, ...)                                                     \
  reterr(snprintf((hj)->errmsg, sizeof((hj)->errmsg), fmt, ##__VA_ARGS__))

struct hj_t {
  void *context;
  chtab_t *tab;
  spill_t *spill;
  arena_t *arena;
  int64_t memlimit;
  hj_reclen_t *reclen;
  hj_keyeq_t *keyeq;
  hj_type_t type;

  char errmsg[200];
};

const char *hj_errmsg(hj_t *hj) { return hj->errmsg; }

#define MATCH(hj, br, pr)                                                      \
  ((matchfn((hj)->context, br, pr)) ? perr(hj, "matchfn failed %s", FLINE) : 0)

hj_t *hj_start(void *context, hj_type_t type, int64_t memlimit,
               const char *spilldir, hj_reclen_t *reclen, hj_keyeq_t *keyeq) {

  hj_t *hj = calloc(1, sizeof(*hj));
  CHECKBAIL(hj);

  hj->tab = chtab_create();
  CHECKBAIL(hj->tab);

  hj->spill = spill_create(spilldir);
  CHECKBAIL(hj->spill);

  hj->arena = arena_create();
  CHECKBAIL(hj->arena);

  hj->context = context;
  hj->memlimit = memlimit;
  hj->reclen = reclen;
  hj->keyeq = keyeq;
  hj->type = type;

  return hj;

bail:
  hj_release(hj);
  return 0;
}

typedef struct atom_t atom_t;
struct atom_t {
  intptr_t next; // points to next atom_t; we steal a bit to indicate HIT.
  char rec[0];
};

// Insert an entry into htab.
// pp is the result of a prevous chtab_find() call ONLY IF it is not NULL. In
// this case, we can simply use it to insert the new entry.
static int insert(hj_t *hj, uint64_t hval, const void *rec, int len,
                  void **pp) {
  atom_t *atom = arena_alloc(hj->arena, sizeof(atom_t) + len);
  CHECK(atom);
  memcpy(atom->rec, rec, len);
  if (!pp) {
    // Note: must call chtab_emplace() instead of chtab_emplace_ex() because
    // pp == NULL does not mean we have done a chtab_find() before.
    pp = chtab_emplace(hj->tab, hval);
  }
  CHECK(pp);
  atom->next = (intptr_t)*pp;
  *pp = atom;
  return 0;
}

/* Feed the hashjoin with a build record. The build record will either be
 * inserted into the htab or spilled. */
int hj_build(hj_t *hj, uint64_t hval, const void *br) {
  spill_t *sp = hj->spill;
  int len = hj->reclen(br);
  void **pp = 0;
  int do_insert = 0;

  // insert if htab is below memory limit
  do_insert = do_insert || (arena_size(hj->arena) < hj->memlimit);

  // insert if hval already exists in htab
  do_insert = do_insert || (0 != (pp = chtab_find(hj->tab, hval)));

  if (do_insert) {
    // insert br into htab
    if (insert(hj, hval, br, len, pp)) {
      return perr(hj, "out of memory %s", FLINE);
    }
    return 0;
  }

  // Else spill the tuple

  // expand if spill is empty to start with at least 2 buckets
  int do_expand = 0;
  do_expand = do_expand || (sp->nrow == 0);

  // expand if average-bucket-size exceeds memlimit
  do_expand = do_expand || (sp->nbyte / (1 << sp->N) >= hj->memlimit);

  if (do_expand) {
    CHECK(0 == spill_expand(sp, hj->errmsg, sizeof(hj->errmsg)));
  }

  return spill_add(sp, SPILL_BUILD, hval, br, len, hj->errmsg,
                   sizeof(hj->errmsg));
}

// Feed the hashjoin with a probe record.
int hj_probe(hj_t *hj, uint64_t hval, const void *pr, hj_matchfn_t *matchfn) {

  spill_t *sp = hj->spill;

  // if the hval is in the htab, match with either hit or miss.
  void **pp = chtab_find(hj->tab, hval);
  if (pp) {
    int hitflag = 0;
    for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
      const void *br = atom->rec;
      if (hj->keyeq(hj->context, br, pr)) {
        CHECK(0 == MATCH(hj, br, pr));
        hitflag = 1;
        atom->next |= 1; // mark hit
      }
    }
    if (!hitflag) {
      if (hj->type & HJ_RIGHT) {
        CHECK(0 == MATCH(hj, 0, pr));
      }
    }
    // Done! because build0() would not spill records with this hval.
    // i.e. this hval does not exist in any build-side spill buckets.
    return 0;
  }

  // if not spilling, yet, then we have a miss. Done.
  if (sp->nrow == 0) {
    if (hj->type & HJ_RIGHT) {
      CHECK(0 == MATCH(hj, 0, pr));
    }
    return 0;
  }

  // if spill knows this tup does not match a build tuple. it is a miss.
  if (spill_can_ignore(sp, hval)) {
    if (hj->type & HJ_RIGHT) {
      CHECK(0 == MATCH(hj, 0, pr));
    }
    return 0;
  }

  // spill this tuple. It may match a build-tuple already in the spill.
  return spill_add(sp, SPILL_PROBE, hval, pr, hj->reclen(pr), hj->errmsg,
                   sizeof(hj->errmsg));
}

/*
 *  Build up the hashtable for a particular spill id.
 */
static int build(hj_t *hj, int spid) {
  // printf("--- build %d\n", spid);
  spill_t *sp = hj->spill;

  // Done with old htab. Create a new one.
  chtab_reset(hj->tab);
  arena_reset(hj->arena);

  // Make sure all records have landed on disk.
  CHECK(0 == spill_flush(sp, hj->errmsg, sizeof(hj->errmsg)));

  // Open scan on the file containing build records
  const char *path = spill_path(sp, spid);
  if (!path) {
    return 0; // nothing to do. done.
  }
  spill_file_t *scan =
      spill_file_scan_build(path, hj->errmsg, sizeof(hj->errmsg));
  CHECKBAIL(scan);

  // For each build tuple
  for (;;) {
    spill_rec_t *rec;
    CHECKBAIL(0 == spill_file_next(scan, &rec, hj->errmsg, sizeof(hj->errmsg)));
    if (!rec) {
      break; // EOF
    }
    uint64_t hval = rec->hval;

    /* Add record to either hj->tab or other (higher up) spill build buckets */
    int destid = spill_id(sp, hval);
    if (destid == spid) {
      const void *br = rec->raw;
      if (insert(hj, hval, br, hj->reclen(br), 0)) {
        perr(hj, "out of memory %s", FLINE);
        goto bail;
      }
    } else {
      if (destid < spid) { // MUST go to a higher bucket by design
        perr(hj, "internal error - destid > id %s", FLINE);
        goto bail;
      }

      // build records inserted when N = 1 may need to go to other
      // buckets if current N is 3 (i.e. we did two more expands *after*
      // the records were expanded).
      CHECKBAIL(0 == spill_add(sp, SPILL_BUILD, hval, rec->raw, rec->len,
                               hj->errmsg, sizeof(hj->errmsg)));
    }
  }

  // Done with this spill file
  spill_file_close(scan, /*truncate*/ 1);
  return 0;

bail:
  if (scan) {
    spill_file_close(scan, 0);
  }
  return -1;
}

/*
 *  Probe the hashtable with records from a particular spill probe bucket.
 *  Call matchfn for each hit/miss entries.
 */
static int probe(hj_t *hj, int spid, hj_matchfn_t *matchfn) {
  // printf("--- probe %d\n", spid);
  spill_t *sp = hj->spill;

  // Make sure all records have landed on disk.
  CHECK(0 == spill_flush(sp, hj->errmsg, sizeof(hj->errmsg)));

  // Open spill probe file for spid
  const char *path = spill_path(sp, spid);
  if (!path) {
    return 0; // nothing to do. done.
  }

  spill_file_t *scan =
      spill_file_scan_probe(path, hj->errmsg, sizeof(hj->errmsg));
  CHECKBAIL(scan);

  // Scan until EOF
  for (;;) {
    spill_rec_t *rec;
    if (spill_file_next(scan, &rec, hj->errmsg, sizeof(hj->errmsg))) {
      CHECKBAIL(0);
    }
    if (!rec) {
      break; // EOF
    }

    uint64_t hval = rec->hval;
    const void *pr = rec->raw;

    // match against build tuples in htab
    void **pp = chtab_find(hj->tab, hval);
    if (pp) {
      int hitflag = 0;
      for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
        const void *br = atom->rec;
        if (hj->keyeq(hj->context, br, pr)) {
          CHECK(0 == MATCH(hj, br, pr));
          hitflag = 1;
          atom->next |= 1; // mark hit
        }
      }
      if (!hitflag) {
        if (hj->type & HJ_RIGHT) {
          CHECK(0 == MATCH(hj, 0, pr));
        }
      }
    }
  }

  // Done with this probe file
  spill_file_close(scan, /*truncate*/ 1);
  return 0;

bail:
  if (scan) {
    spill_file_close(scan, 0);
  }
  return -1;
}

static int scan_for_missed_records(hj_t *hj, hj_matchfn_t *matchfn) {
  // this function should only be called for a LEFT or FULL join
  assert(hj->type & HJ_LEFT);

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = hj->tab;

  for (int idx = chtab_first(tab, &hval, (void **)&atom); idx >= 0;
       idx = chtab_next(tab, idx, &hval, (void **)&atom)) {
    for (; atom; atom = (atom_t *)(atom->next & ~1)) {
      int hit = atom->next & 1;
      if (!hit) {
        const void *br = atom->rec;
        CHECK(0 == MATCH(hj, br, 0));
      }
    }
  }
  return 0;
}

// Do hashjoin on each pair of build/probe files.
int hj_probe_spilled(hj_t *hj, hj_matchfn_t matchfn) {
  spill_t *sp = hj->spill;

  // Scan the current hashtable.
  // All tuples in the current hashtable that were not hit are misses.
  // For LEFT/FULL outer join, invoke matchfn on them with build records from
  // hashtable and null probe records.
  if (hj->type & HJ_LEFT) {
    CHECK(0 == scan_for_missed_records(hj, matchfn));
  }

  for (int id = 0; spill_has_id(sp, id); id++) {

    // Build up a new hashtable for spill build file 'id'
    CHECK(0 == build(hj, id));

    // Probe the hashtable for spill probe file 'id'
    CHECK(0 == probe(hj, id, matchfn));

    // Scan the current hashtable.
    // All tuples in the current hashtable that were not hit are misses.
    // For LEFT/FULL outer join, invoke matchfn on them with build records from
    // hashtable and null probe records.
    if (hj->type & HJ_LEFT) {
      CHECK(0 == scan_for_missed_records(hj, matchfn));
    }
  }

  return 0;
}

void hj_release(hj_t *hj) {
  if (hj) {
    spill_destroy(hj->spill);
    chtab_destroy(hj->tab);
    arena_destroy(hj->arena);
    free(hj);
  }
}
