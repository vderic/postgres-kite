#ifndef SPILL_H
#define SPILL_H

#include "mbloom.h"
#include <stdint.h>

typedef enum spill_part_t spill_part_t;
enum spill_part_t {
  SPILL_BUILD,
  SPILL_PROBE,
};

// Spill control block
typedef struct spill_bucket_t spill_bucket_t;
typedef struct mbloom_t mbloom_t;
typedef struct spill_t spill_t;
struct spill_t {
  uint64_t serial; // serial number
  const char *dir;
  int N;                   // incremented at each spill_expand()
  spill_bucket_t **bucket; // array dim[2^N]
  struct {                 // stores sequence of spill_rec_t
    spill_part_t part;
    char *ptr;
    int bot, top, max;
  } buf;
  mbloom_t *bloom; // bloom filter on build buckets

  int64_t nrow;  // total #row spilled so far
  int64_t nbyte; // total #byte spilled so far
};

/**
 * Create a spill. Returns NULL if out of memory
 */
spill_t *spill_create(const char *dir);

/**
 * Destroy a spill. Free all memory and delete all spill files.
 */
void spill_destroy(spill_t *sp);

/**
 *  Check if a hval potentially match a build tuple
 */
static inline int spill_can_ignore(spill_t *sp, uint64_t hval) {
  return !mbloom_check(sp->bloom, hval);
}

/**
 * Double the spill files. Returns 0 on success, -1 otherwise.
 * Note: only expand when average build bucket is bigger than the
 * peudo memory limit.  So, if you have limit of 1MB, and you have 8
 * buckets, only call expand when total bytes is 8MB.
 */
int spill_expand(spill_t *sp, char *errmsg, int errmsglen);

/**
 * Add a record to the corresponding spill file depending on hval.
 * Returns 0 on success, -1 otherwise.
 */
int spill_add(spill_t *sp, spill_part_t part, uint64_t hval, const void *rec,
              int len, char *errmsg, int errmsglen);

/**
 * Check if id is valid in the current spill.
 */
static inline int spill_has_id(spill_t *sp, int id) {
  return 0 <= id && id < (1 << sp->N);
}

/**
 * Return the spill id given a hval
 */
static inline int spill_id(spill_t *sp, uint64_t hval) {
  hval >>= 32;
  return hval & ((1 << sp->N) - 1);
}

int spill_flush(spill_t *sp, char *errmsg, int errmsglen);

const char *spill_path(spill_t *sp, int id);

#endif /* SPILL_H */
