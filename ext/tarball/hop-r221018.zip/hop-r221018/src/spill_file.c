#define _POSIX_C_SOURCE 200809L
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

/* file format:

   [BUILD section]
   [PROBE section]
   [MARKER]

   Both Build and Probe sections are just sequential serialized records.

   The Marker contains the sizes of the build and probe sections.

 */

#define MAGIC "SPILL001"

typedef struct marker_t marker_t;
struct marker_t {
  char magic[8];
  int64_t build_size;
  int64_t probe_size;
};

static int readfully(int fd, void *buf, int len, char *errmsg, int errlen) {
  char *p = buf;
  char *q = buf + len;
  while (p < q) {
    int n = read(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s", strerror(errno));
    }

    if (n == 0) {
      return perr("%s", "read beyond eof");
    }

    p += n;
  }

  return 0;
}

static int writefully(int fd, int64_t pos, const void *buf, int len,
                      char *errmsg, int errlen) {
  const char *p = buf;
  const char *q = buf + len;
  while (p < q) {
    int n = pwrite(fd, p, q - p, pos);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s", strerror(errno));
    }

    if (n == 0) {
      return perr("%s", strerror(errno));
    }

    p += n;
    pos += n;
  }

  return 0;
}

static int has_marker(int fd) { return (0 != lseek(fd, 0, SEEK_END)); }

static int read_marker(int fd, marker_t *marker, char *errmsg, int errlen) {
  if (-1 == lseek(fd, -(int)sizeof(*marker), SEEK_END)) {
    return perr("%s", strerror(errno));
  }

  CHECK(0 == readfully(fd, marker, sizeof(*marker), errmsg, errlen));

  if (0 != memcmp(marker->magic, MAGIC, 8)) {
    return perr("%s", "spill file corrupted");
  }

  return 0;
}

struct spill_append_t {
  const char *path;
  int fd;
  int build_mode; // 1 if build_mode, 0 if probe mode
  marker_t marker;
  int64_t pos;

  char buf[1024 * 16 - 24];
  int top;
};

static spill_append_t *spill_append_open(const char *path, char *errmsg,
                                         int errlen) {
  spill_append_t *fp = calloc(1, sizeof(*fp));
  if (!fp) {
    perr("%s", "out of memory");
    goto bail;
  }
  fp->path = strdup(path);
  if (!fp->path) {
    perr("%s", "out of memory");
    goto bail;
  }

  fp->fd = open(path, O_RDWR);
  if (fp->fd <= 0) {
    perr("%s", strerror(errno));
    goto bail;
  }

  memcpy(fp->marker.magic, MAGIC, 8);
  if (has_marker(fp->fd)) {
    CHECKBAIL(0 == read_marker(fp->fd, &fp->marker, errmsg, errlen));
  }

  return fp;

bail:
  spill_append_close(fp, 0, 0);
  return 0;
}

spill_append_t *spill_append_build(const char *path, char *errmsg, int errlen) {

  spill_append_t *fp = spill_append_open(path, errmsg, errlen);
  CHECKBAIL(fp);

  if (fp->marker.probe_size != 0) {
    perr("%s", "spill file corrupted");
    goto bail;
  }

  fp->pos = fp->marker.build_size;
  fp->build_mode = 1;

  return fp;

bail:
  spill_append_close(fp, 0, 0);
  return 0;
}

spill_append_t *spill_append_probe(const char *path, char *errmsg, int errlen) {

  spill_append_t *fp = spill_append_open(path, errmsg, errlen);
  CHECKBAIL(fp);

  fp->pos = fp->marker.build_size + fp->marker.probe_size;
  fp->build_mode = 0;

  return fp;

bail:
  spill_append_close(fp, 0, 0);
  return 0;
}

static int flush(spill_append_t *fp, char *errmsg, int errlen) {
  CHECK(0 == writefully(fp->fd, fp->pos, fp->buf, fp->top, errmsg, errlen));
  fp->pos += fp->top;
  fp->top = 0;
  return 0;
}

int spill_append(spill_append_t *fp, const spill_rec_t *rec, char *errmsg,
                 int errlen) {
  int recsz = rec_size(rec);

  const char *p = (const char *)rec;
  int plen = recsz;

  while (plen > 0) {
    // #bytes available for writing in fp->buf
    int nb = sizeof(fp->buf) - fp->top;
    if (nb == 0) {
      CHECK(0 == flush(fp, errmsg, errlen));
      continue;
    }
    if (nb > plen) {
      nb = plen;
    }
    memcpy(fp->buf + fp->top, p, nb);
    fp->top += nb;
    plen -= nb;
    p += nb;
  }

  if (fp->build_mode) {
    fp->marker.build_size += recsz;
  } else {
    fp->marker.probe_size += recsz;
  }

  return 0;
}

int spill_append_close(spill_append_t *fp, char *errmsg, int errlen) {
  int ret = 0;
  if (fp) {
    if (fp->fd >= 0) {
      ret = ret ? ret : flush(fp, errmsg, errlen);
      ret = ret ? ret
                : writefully(fp->fd, fp->pos, &fp->marker, sizeof(fp->marker),
                             errmsg, errlen);
      close(fp->fd);
    }
    free((void *)fp->path);
    free(fp);
  }
  return ret;
}

struct spill_file_t {
  const char *path;
  int fd;
  int64_t avail; //#bytes available to read starting at current pos

  char *buf;
  int bot, top, max;
};

static spill_file_t *spill_file_open(const char *path, marker_t *marker,
                                     char *errmsg, int errlen) {
  spill_file_t *sf = 0;

  sf = calloc(1, sizeof(*sf));
  if (!sf) {
    perr("%s", "out of memory");
    goto bail;
  }
  sf->fd = open(path, O_RDONLY);
  if (sf->fd < 0) {
    perr("%s", strerror(errno));
    goto bail;
  }

  CHECKBAIL(0 == read_marker(sf->fd, marker, errmsg, errlen));

  sf->max = 32 * 1024;
  sf->buf = malloc(sf->max);
  sf->path = strdup(path);
  if (!(sf->buf && sf->path)) {
    perr("%s", "out of memory");
    goto bail;
  }

  return sf;

bail:
  spill_file_close(sf, 0);
  return 0;
}

spill_file_t *spill_file_scan_build(const char *path, char *errmsg,
                                    int errlen) {
  marker_t marker;
  spill_file_t *sf = spill_file_open(path, &marker, errmsg, errlen);
  CHECKBAIL(sf);

  // #bytes that can be read
  sf->avail = marker.build_size;

  // start of read region
  if (-1 == lseek(sf->fd, 0, SEEK_SET)) {
    perr("%s", strerror(errno));
    goto bail;
  }

  return sf;

bail:
  spill_file_close(sf, 0);
  return 0;
}

spill_file_t *spill_file_scan_probe(const char *path, char *errmsg,
                                    int errlen) {
  marker_t marker;
  spill_file_t *sf = spill_file_open(path, &marker, errmsg, errlen);
  CHECKBAIL(sf);

  // #bytes that can be read
  sf->avail = marker.probe_size;

  // start of read region
  if (-1 == lseek(sf->fd, marker.build_size, SEEK_SET)) {
    perr("%s", strerror(errno));
    goto bail;
  }

  return sf;

bail:
  spill_file_close(sf, 0);
  return 0;
}

void spill_file_close(spill_file_t *fp, int truncate_flag) {
  if (fp) {
    int fd = fp->fd;
    if (fd >= 0) {
      if (truncate_flag) {
        int n = ftruncate(fd, 0);
        (void)n;
      }
      close(fd);
    }
    free((void *)fp->path);
    free(fp->buf);
    free(fp);
  }
}

static int read_more(spill_file_t *fp, char *errmsg, int errlen) {
  if (fp->avail == 0) {
    return perr("spill_scan(%s): incomplete last record", fp->path);
  }

  // shift buf[bot..top] to buf[0]
  if (fp->bot) {
    int inuse = fp->top - fp->bot;
    memmove(fp->buf, fp->buf + fp->top, inuse);
    fp->bot = 0;
    fp->top = inuse;
  }

  // nb bytes of free buffer
  int nb = fp->max - fp->top;
  if (nb == 0) {
    // extend the buffer
    int newmax = fp->max * 1.5;
    if (newmax < 0) {
      return perr("spill_scan(%s): record is too big", fp->path);
    }
    char *tmp = realloc(fp->buf, newmax);
    if (!tmp) {
      return perr("%s", "out of memory");
    }
    fp->buf = tmp;
    fp->max = newmax;
    nb = fp->max - fp->top;
  }
  assert(nb > 0);

  // Top up the buffer
  if (nb > fp->avail) {
    nb = fp->avail;
  }
  CHECK(0 == readfully(fp->fd, fp->buf + fp->top, nb, errmsg, errlen));

  // reduce #bytes available to read from disk
  fp->avail -= nb;

  // increase #bytes in buffer
  fp->top += nb;

  return 0;
}

int spill_file_next(spill_file_t *fp, spill_rec_t **prec, char *errmsg,
                    int errlen) {
  spill_rec_t *rec = 0;
  int recsz = 0;

  while (!rec) {
    int nb = fp->top - fp->bot;

    if (nb == 0 && fp->avail == 0) {
      // signal EOF to caller
      *prec = 0;
      return 0;
    }

    // enough for the record header?
    if (nb > (int)sizeof(*rec)) {
      // obtain the record size using the header
      rec = (spill_rec_t *)(fp->buf + fp->bot);
      recsz = rec_size(rec);

      // enough for the full record?
      if (nb < recsz) {
        rec = 0;
      }
    }

    // read more into buffer if we still don't have a complete record
    if (!rec) {
      if (read_more(fp, errmsg, errlen)) {
        return -1;
      }
    }
  }

  // return the rec
  *prec = rec;

  // next byte to read is beyond this record
  fp->bot += recsz;

  return 0;
}
