#ifndef SPILL_FILE_H
#define SPILL_FILE_H

#include <stdint.h>

// A serialized record in the spill file
typedef struct spill_rec_t spill_rec_t;
struct spill_rec_t {
  uint64_t hval;
  int32_t len;
  char raw[0]; // len bytes
};

static inline int rec_size(const spill_rec_t *rp) {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Warray-bounds"
  // size of spill record, inclusive of header
  return &rp->raw[rp->len] - (char *)rp;
#pragma GCC diagnostic pop
}

typedef struct spill_file_t spill_file_t;
typedef struct spill_append_t spill_append_t;

spill_append_t *spill_append_build(const char *path, char *errmsg, int errlen);
spill_append_t *spill_append_probe(const char *path, char *errmsg, int errlen);
int spill_append(spill_append_t *fp, const spill_rec_t *rec, char *errmsg,
                 int errlen);
int spill_append_close(spill_append_t *fp, char *errmsg, int errlen);

spill_file_t *spill_file_scan_build(const char *path, char *errmsg, int errlen);
spill_file_t *spill_file_scan_probe(const char *path, char *errmsg, int errlen);
int spill_file_next(spill_file_t *fp, spill_rec_t **prec, char *errmsg,
                    int errlen);
void spill_file_close(spill_file_t *fp, int truncate_flag);

#endif /* SPILL_FILE_H */
