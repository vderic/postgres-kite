#include "hashagg.h"
#include "arena.h"
#include "chtab.h"
#include "spill.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(agg, fmt, ...)                                                    \
  reterr(snprintf((agg)->errmsg, sizeof((agg)->errmsg), fmt, ##__VA_ARGS__))

static void dummy_reset(void *){};

static void default_serialize(void *context, const void *rec, void *dest,
                              int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

struct hagg_t {
  void *context;
  chtab_t *tab;
  spill_t *spill;
  arena_t *arena;
  int64_t memlimit;
  hagg_keyeqfn_t *keyeq;
  hagg_initfn_t *init;
  hagg_transfn_t *trans;
  hagg_reclenfn_t *reclen;
  hagg_resetfn_t *reset;
  hagg_serializefn_t *serialize;
  spf_t *spf; // active scan
  char errmsg[200];
};

const char *hagg_errmsg(hagg_t *agg) { return agg->errmsg; }

hagg_t *hagg_start(void *context, int64_t memlimit, const char *spilldir,
                   const hagg_dispatch_t *dispatch) {

  hagg_t *agg = calloc(1, sizeof(*agg));
  CHECKBAIL(agg);

  agg->tab = chtab_create();
  CHECKBAIL(agg->tab);

  agg->spill = spill_create(spilldir);
  CHECKBAIL(agg->spill);

  agg->arena = arena_create();
  CHECKBAIL(agg->arena);

  agg->context = context;
  agg->memlimit = memlimit;
  agg->keyeq = dispatch->keyeq;
  agg->init = dispatch->init;
  agg->trans = dispatch->trans;
  agg->reclen = dispatch->reclen;
  agg->reset = dispatch->reset ? dispatch->reset : dummy_reset;
  agg->serialize =
      dispatch->serialize ? dispatch->serialize : default_serialize;

  return agg;

bail:
  hagg_release(agg);
  return 0;
}

void hagg_release(hagg_t *agg) {
  if (agg) {
    if (agg->spf) {
      spf_close(agg->spf, 0, 0, 0);
    }
    arena_destroy(agg->arena);
    spill_destroy(agg->spill);
    chtab_destroy(agg->tab);
    free(agg);
  }
}

// The hashtable contains pointers to list of atoms with the same hashval.
// Each atom contains pointers to the record and the associated agg data.
typedef struct atom_t atom_t;
struct atom_t {
  atom_t *next; // link to next atom with the same hval
  void *data;   // agg data returned by init() and trans()
  int32_t len;  // len of rec[]
  char rec[0];  // rec[len] bytes
};

// Insert a new key into the htab. This will invoke initfn() on the new entry.
static int new_atom(hagg_t *agg, void **pp, const void *rec, int len) {
  atom_t *atom = arena_alloc(agg->arena, sizeof(atom_t) + len);
  if (!atom) {
    return perr(agg, "out of memory %s", FLINE);
  }
  atom->len = len;
  memcpy(atom->rec, rec, len);
  atom->next = *pp;
  *pp = atom;

  atom->data = agg->init(agg->context, atom->rec);
  return atom->data ? 0 : perr(agg, "initfn failed %s", FLINE);
}

// scan the list looking for (atom->rec == rec)
static inline atom_t *chase(hagg_t *agg, atom_t *list, void *rec) {
  atom_t *atom = list;
  while (atom && !agg->keyeq(agg->context, atom->rec, rec)) {
    atom = atom->next;
  }
  return atom;
}

int hagg_feed(hagg_t *agg, uint64_t hval, void *rec) {
  spill_t *sp = agg->spill;
  int len = agg->reclen(agg->context, rec);
  char serialized[len];
  agg->serialize(agg->context, rec, serialized, len);

  // look for records matching hval in chtab
  void **pp = chtab_find(agg->tab, hval);
  if (pp) {
    // look for records matching rec in atom chain
    atom_t *atom = chase(agg, (atom_t *)*pp, serialized);
    if (atom) {
      // Found a match: do trans().
      atom->data = agg->trans(agg->context, serialized, atom->data);
      return atom->data ? 0 : perr(agg, "transfn failed %s", FLINE);
    }
    // Not found: make a new atom, do init(), and attach to list pp
    return new_atom(agg, pp, serialized, len);
  }

  // insert if htab is below memory limit
  if (arena_size(agg->arena) < agg->memlimit) {
    // we can call chtab_emplace_ex() which skips a call to its internal find()
    // routine. This is a slight optimization when we know for sure hval does
    // not exist in the chtab.
    pp = chtab_emplace_ex(agg->tab, hval);
    return new_atom(agg, pp, serialized, len);
  }

  // Else spill the tuple

  // expand if spill is empty to start with at least 2 buckets
  int do_expand = 0;
  do_expand = do_expand || (sp->nrow == 0);

  // expand if average-bucket-size exceeds memlimit
  do_expand = do_expand || (sp->nbyte / (1 << sp->N) >= agg->memlimit);

  if (do_expand) {
    CHECK(0 == spill_expand(sp, agg->errmsg, sizeof(agg->errmsg)));
  }

  void *dest = spill_emplace(sp, SPILL_BUILD, hval, len, agg->errmsg,
                             sizeof(agg->errmsg));
  CHECK(dest);
  memcpy(dest, serialized, len);

  return 0;
}

// For records in the spill file: do hashagg
static int process(hagg_t *agg, int spid) {
  spill_t *sp = agg->spill;

  // Done with old htab. Create a new one.
  chtab_reset(agg->tab);
  arena_reset(agg->arena);
  agg->reset(agg->context);

  // Make sure all records have landed on disk.
  CHECK(0 == spill_flush(sp, agg->errmsg, sizeof(agg->errmsg)));

  // Open scan on the file containing build records
  const char *path = spill_path_for_build(sp, spid);
  if (!path) {
    return 0; // nothing to do. done.
  }
  spf_t *scan = spf_scan(path, agg->errmsg, sizeof(agg->errmsg));
  CHECKBAIL(scan);
  agg->spf = scan;

  // For each spill record
  for (;;) {
    spill_rec_t *sprec;
    CHECKBAIL(0 == spf_next(scan, &sprec, agg->errmsg, sizeof(agg->errmsg)));
    if (!sprec) {
      break; // EOF
    }
    uint64_t hval = sprec->hval;

    // If the spill record is not meant for this spid, write it to its
    // destined spill file.
    int destid = spill_id(sp, hval);
    if (destid != spid) {
      // record MUST go to a higher bucket (by design)
      if (destid < spid) {
        perr(agg, "internal error - destid > id %s", FLINE);
        goto bail;
      }

      // Build records inserted when N = 1 may need to go to other
      // buckets. Note: if current N is 3 (i.e. we did two more
      // expands *after* the records were expanded).
      void *dest = spill_emplace(sp, SPILL_BUILD, hval, sprec->len, agg->errmsg,
                                 sizeof(agg->errmsg));
      CHECKBAIL(dest);
      memcpy(dest, sprec->raw, sprec->len);
      continue;
    }

    // Rec belongs to this spid
    void *rec = sprec->raw;
    int len = sprec->len;

    // Look for records matching hval in chtab
    void **pp = chtab_find(agg->tab, hval);
    if (pp) {
      // Hval is in chtab. Look for records matching rec in atom chain
      atom_t *atom = chase(agg, (atom_t *)*pp, rec);
      if (atom) {
        // Found a match: do trans().
        atom->data = agg->trans(agg->context, rec, atom->data);
        if (!atom->data) {
          perr(agg, "transfn failed %s", FLINE);
          goto bail;
        }
        continue;
      }
      // Not found: make a new atom, do init(), and attach to list pp
      CHECKBAIL(new_atom(agg, pp, rec, len));
      continue; // done.
    }

    // No records matching hval. Insert into chtab.
    pp = chtab_emplace_ex(agg->tab, hval);
    CHECKBAIL(0 == new_atom(agg, pp, rec, len));
  }

  // Done with this spill file
  agg->spf = 0;
  spf_close(scan, /*truncate*/ 1, 0, 0);
  return 0;

bail:
  if (scan) {
    agg->spf = 0;
    spf_close(scan, 0, 0, 0);
  }
  return -1;
}

// For each entry in htab, invoke finalize function.
static int finalize(hagg_t *agg, hagg_finfn_t *fin) {

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = agg->tab;

  // first slot
  int idx = chtab_first(tab, &hval, (void **)&atom);
  while (idx >= 0) {

    // slot contains a list.
    // scan the list and invoke fin()
    for (; atom; atom = atom->next) {
      if (fin(agg->context, atom->rec, atom->data)) {
        return perr(agg, "finfn failed %s", FLINE);
      }
    }

    // next slot
    idx = chtab_next(tab, idx, &hval, (void **)&atom);
  }

  return 0;
}

int hagg_finalize_batch(hagg_t *agg, int batch, hagg_finfn_t *fin) {

  spill_t *sp = agg->spill;

  // Scan the current hashtable, and finalize each entry.
  if (batch == 0) {
    return finalize(agg, fin);
  }

  int id = batch - 1;
  if (spill_has_id(sp, id)) {
    // Do hash agg on spill file 'id'
    CHECK(0 == process(agg, id));

    // Scan the current hashtable, and finalize each entry.
    return finalize(agg, fin);
  }

  return perr(agg, "bad batch number %s", FLINE);
}

int hagg_batch_max(hagg_t *agg) {
  spill_t *sp = agg->spill;
  return 1 + (1 << sp->N);
}

int hagg_process_batch(hagg_t *agg, int batch, hagg_iter_t *iter) {
  iter->tab = 0;
  iter->idx = -1;
  iter->atom = 0;

  if (batch == 0) {
    iter->tab = agg->tab;
  } else {
    int id = batch - 1;
    if (!spill_has_id(agg->spill, id)) {
      return perr(agg, "bad batch number %s", FLINE);
    }
    CHECK(0 == process(agg, id));
    iter->tab = agg->tab;
  }

  // move to the first slot
  uint64_t hval; // unused
  iter->idx = chtab_first(iter->tab, &hval, &iter->atom);
  return 0;
}

int hagg_next(hagg_iter_t *iter, const void **ret_rec, void **ret_ptr) {
  // EOF reached?
  if (!iter->atom) {
    *ret_rec = 0;
    *ret_ptr = 0;
    return 0;
  }

  // return the current slot
  atom_t *atom = iter->atom;
  *ret_rec = atom->rec;
  *ret_ptr = atom->data;

  // move to the next slot
  chtab_t *tab = iter->tab;
  uint64_t hval;
  iter->idx = chtab_next(tab, iter->idx, &hval, &iter->atom);
  if (iter->idx < 0) {
    iter->atom = 0;
  }
  return 0;
}
