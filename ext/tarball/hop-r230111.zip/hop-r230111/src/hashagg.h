#ifndef HASHAGG_H
#define HASHAGG_H

#include <stdint.h>

typedef struct hagg_t hagg_t;

// Check if two records fed to hagg are equal.
// rec1 and rec2 are not const because they maybe modified (swizzled).
typedef int hagg_keyeqfn_t(void *context, void *rec1, void *rec2);

// Initialize a new agg entry. Returns an aggrec to be associated with
// rec.  This probably involves a malloc() call to create aggrec.
// rec is not const because it may be modified (swizzled).
typedef void *hagg_initfn_t(void *context, void *rec);

// Transition function. Given (rec, aggrec), return same or different
// aggrec to be associated with rec.  This probably involves
// realloc(aggrec) if the associated struct changes size.
// rec is not const because it may be modified (swizzled).
typedef void *hagg_transfn_t(void *context, void *rec, void *aggrec);

// Finalize function. Take (rec, aggrec) and do something with it.  This
// probably involves free(aggrec).
// rec is not const because it may be modified (swizzled).
typedef int hagg_finfn_t(void *context, void *rec, void *aggrec);

// Notification that the hashtable has been reset to empty
typedef void hagg_resetfn_t(void *context);

// Return the serialized length of rec.
typedef int hagg_reclenfn_t(void *context, const void *rec);

// Serialize rec to dest.
typedef void hagg_serializefn_t(void *context, const void *rec, void *dest,
                                int destsz);

typedef struct hagg_dispatch_t hagg_dispatch_t;
struct hagg_dispatch_t {
  // mandatory
  hagg_keyeqfn_t *keyeq;
  hagg_initfn_t *init;
  hagg_transfn_t *trans;
  hagg_reclenfn_t *reclen;
  // optional
  hagg_resetfn_t *reset;
  hagg_serializefn_t *serialize;
};

// Iterator struct
typedef struct hagg_iter_t hagg_iter_t;
struct hagg_iter_t {
  void *tab;  /* internal */
  int idx;    /* internal */
  void *atom; /* internal */
};

/**
 *  Start a hashagg. Returns NULL if out-of-memory.
 */
extern hagg_t *hagg_start(void *context, int64_t memlimit, const char *spilldir,
                          const hagg_dispatch_t *dispatch);

/**
 * Feed a record to the agg. Hagg will call reclen and serialize to
 * make a copy of rec internally. The init and trans functions will be
 * invoked on the copy of rec if the hashtable fit in memory. Otherwise, the
 * record will be spilled to disk. Returns 0 on success, -1 otherwise.
 *
 * Note: rec is not const because it may be modified (swizzled).
 */
extern int hagg_feed(hagg_t *agg, uint64_t hval, void *rec);

/**
 * Return the number of batches accumulated in the hagg.
 * Batch 0 is the current in-memory htab.
 * Batch 1 is spill #0.
 * Batch 2 is spill #1, etc.
 * Returns 0 on success, -1 otherwise.
 */
extern int hagg_batch_max(hagg_t *agg);

/**
 * The callback way to finalize the agg for a particular batch. The fin() will
 * be invoked for each distinct record in this batch. Returns 0 on success, -1
 * otherwise.
 */
extern int hagg_finalize_batch(hagg_t *agg, int batch, hagg_finfn_t *fin);

/**
 * The iterative way to finalize the agg for a particular batch. Caller is
 * responsible for invoking their fin() functions. Returns 0 on success, -1
 * otherwise. On success, iter will be initialized to point to the first (rec,
 * ptr) pair in the agg. Use the hagg_next() function to retrieve the data and
 * advance the iterator.
 */
extern int hagg_process_batch(hagg_t *agg, int batch, hagg_iter_t *iter);

/**
 * Return the current (rec, ptr), and advance the iterator to the next value.
 * Returns 0 on success, -1 otherwise. When there are no more (rec, ptr), this
 * function will return success, but with *ret_rec set to NULL.
 */
extern int hagg_next(hagg_iter_t *iter, const void **ret_rec, void **ret_ptr);

/**
 * Release all resources.
 */
extern void hagg_release(hagg_t *agg);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hagg_errmsg(hagg_t *agg);

#endif /* HASHAGG_H */
