#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "hashjoin.h"
#include "arena.h"
#include "chtab.h"
#include "spill.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

static int dummy_checkstop(void *) { return 0; }
static void default_serialize(void *context, const void *rec, void *dest,
                              int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

#define perr(hj, fmt, ...)                                                     \
  reterr(snprintf((hj)->errmsg, sizeof((hj)->errmsg), fmt, ##__VA_ARGS__))

struct hj_t {
  void *context;
  chtab_t *tab;
  spill_t *spill;
  arena_t *arena;
  int64_t memlimit;
  hj_dispatch_t dispatch;
  unsigned int intermittent_count;
  hj_type_t type;

  spf_t *spf; // spillfile in use

  int64_t build_nrec;  // #rec inserted into build
  int64_t probe_nrec;  // #rec fed to probe
  int64_t probe_count; // #times the htab has been probed
  char errmsg[200];
};

const char *hj_errmsg(hj_t *hj) { return hj->errmsg; }

int64_t hj_nrec_fed_to_build(hj_t *hj) { return hj->build_nrec; }
int64_t hj_nrec_fed_to_probe(hj_t *hj) { return hj->probe_nrec; }
int64_t hj_probe_count(hj_t *hj) { return hj->probe_count; }

#define MATCH(hj, br, pr)                                                      \
  ((matchfn((hj)->context, br, pr)) ? perr(hj, "matchfn failed %s", FLINE) : 0)

hj_t *hj_start(void *context, hj_type_t type, int64_t memlimit,
               const char *spilldir, const hj_dispatch_t *dispatch) {
  hj_t *hj = calloc(1, sizeof(*hj));
  CHECKBAIL(hj);

  hj->tab = chtab_create();
  CHECKBAIL(hj->tab);

  hj->spill = spill_create(spilldir);
  CHECKBAIL(hj->spill);

  hj->arena = arena_create();
  CHECKBAIL(hj->arena);

  hj->context = context;
  hj->memlimit = memlimit;
  hj->dispatch = *dispatch;
  hj->intermittent_count = 0;
  hj->type = type;

  hj->build_nrec = 0;
  hj->probe_nrec = 0;
  hj->probe_count = 0;

  if (!hj->dispatch.serialize_build) {
    hj->dispatch.serialize_build = default_serialize;
  }
  if (!hj->dispatch.serialize_probe) {
    hj->dispatch.serialize_probe = default_serialize;
  }
  if (!hj->dispatch.checkstop) {
    hj->dispatch.checkstop = dummy_checkstop;
  }

  return hj;

bail:
  hj_release(hj);
  return 0;
}

typedef struct atom_t atom_t;
struct atom_t {
  intptr_t next; // points to next atom_t; we steal a bit to indicate HIT.
  char rec[0];
};

static inline int checkstop(hj_t *hj) {
  return (0xfff == (hj->intermittent_count++ & 0xfff))
             ? hj->dispatch.checkstop(hj->context)
             : 0;
}

/* Feed the hashjoin with a build record. The build record will either be
 * inserted into the htab or spilled. */
int hj_build(hj_t *hj, uint64_t hval, void *br) {
  if (checkstop(hj)) {
    return 0;
  }
  spill_t *sp = hj->spill;
  int brlen = hj->dispatch.reclen_build(hj->context, br);
  void **pp = chtab_find(hj->tab, hval);
  // insert if hval already exists in htab
  int do_insert = (0 != pp);

  // insert if htab is below memory limit
  do_insert = do_insert || (arena_size(hj->arena) < hj->memlimit);

  if (do_insert) {
    // for HJ_IN or HJ_NOT_IN, we want to avoid duplicates in the hashtable,
    // but there is no way to do so unless we add a compare_build(br1, br2)
    // function to the dispatch function.

    // insert br into htab
    atom_t *atom = arena_alloc(hj->arena, sizeof(atom_t) + brlen);
    if (!atom) {
      return perr(hj, "out of memory %s", FLINE);
    }

    hj->dispatch.serialize_build(hj->context, br, atom->rec, brlen);
    if (!pp) {
      // insert into chtab if this is the first atom with 'hval'
      pp = chtab_emplace_ex(hj->tab, hval);
      if (!pp) {
        return perr(hj, "out of memory %s", FLINE);
      }
    }

    // link atom to the list at *pp
    atom->next = (intptr_t)*pp;
    *pp = atom;
    goto success;
  }

  // Else spill the tuple

  // expand if spill is empty to start with at least 2 buckets
  int do_expand = 0;
  do_expand = do_expand || (sp->nrow == 0);

  // expand if average-bucket-size exceeds memlimit
  do_expand = do_expand || (sp->nbyte / (1 << sp->N) >= hj->memlimit);

  if (do_expand) {
    CHECK(0 == spill_expand(sp, hj->errmsg, sizeof(hj->errmsg)));
  }

  // serialize br to a buffer in spill
  void *dest = spill_emplace(sp, SPILL_BUILD, hval, brlen, hj->errmsg,
                             sizeof(hj->errmsg));
  CHECK(dest);
  hj->dispatch.serialize_build(hj->context, br, dest, brlen);

success:
  hj->build_nrec++;
  return 0;
}

// Feed the hashjoin with a probe (left) record.
int hj_probe(hj_t *hj, uint64_t hval, void *pr, hj_matchfn_t *matchfn) {
  if (checkstop(hj)) {
    return 0;
  }

  spill_t *sp = hj->spill;
  const char ISLEFT = (0 != (hj->type & HJ_LEFT));
  const char ISNOTIN = (hj->type == HJ_NOT_IN);
  const char ISIN = (hj->type == HJ_IN);

  // if the hval is in the htab, match with either hit or miss.
  void **pp = chtab_find(hj->tab, hval);
  if (pp) {
    char hitflag = 0;
    for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
      void *br = atom->rec;
      if (hj->dispatch.cond(hj->context, br, pr)) {
        hitflag = 1;
        if (ISNOTIN) {
          // there is a hit, which means NOT_IN failed.
          goto success;
        }
        CHECK(0 == MATCH(hj, br, pr));
        atom->next |= 1; // mark hit
        if (ISIN) {
          // for IN, we are done on first hit
          goto success;
        }
      }
    }
    if (0 == hitflag) {
      if (ISLEFT) { // includes HJ_NOT_IN
        CHECK(0 == MATCH(hj, 0, pr));
      }
    }
    // Done! because build0() would not spill records with this hval.
    // i.e. this hval does not exist in any build-side spill buckets.
    goto success;
  }

  // At this point, we know there is a MISS when:
  // 1. we are not spilling yet, or
  // 2. the spill knows this tup will never match a build tuple (using its
  // bloomfilter).
  if (sp->nrow == 0 || spill_can_ignore(sp, hval)) {
    // a MISS here means a match for HJ_LEFT or HJ_NOT_IN
    if (ISLEFT) { // includes HJ_NOT_IN
      CHECK(0 == MATCH(hj, 0, pr));
    }
    goto success;
  }

  // spill this tuple. It may match a build-tuple already in the spill.
  int prlen = hj->dispatch.reclen_probe(hj->context, pr);
  void *dest = spill_emplace(sp, SPILL_PROBE, hval, prlen, hj->errmsg,
                             sizeof(hj->errmsg));
  CHECK(dest);
  hj->dispatch.serialize_probe(hj->context, pr, dest, prlen);
  hj->probe_count--; /* this record will probe later. compensate for the
                        increment in success: */

success:
  hj->probe_nrec++;  // #rec fed to probe
  hj->probe_count++; // #times the htab has been probed
  return 0;
}

/*
 *  Build up the hashtable for a particular spill id.
 */
static int build(hj_t *hj, int spid) {

  // printf("--- build %d\n", spid);
  spill_t *sp = hj->spill;

  // Done with old htab. Create a new one.
  chtab_reset(hj->tab);
  arena_reset(hj->arena);

  // Make sure all records have landed on disk.
  CHECK(0 == spill_flush(sp, hj->errmsg, sizeof(hj->errmsg)));

  // Open scan on the file containing build records
  const char *path = spill_path_for_build(sp, spid);
  if (!path) {
    return 0; // nothing to do. done.
  }

  if (hj->spf) {
    spf_close(hj->spf, 0, 0, 0);
    hj->spf = 0;
  }
  spf_t *scan = spf_scan(path, hj->errmsg, sizeof(hj->errmsg));
  CHECKBAIL(scan);
  hj->spf = scan;

  // For each build tuple
  for (;;) {
    if (checkstop(hj)) {
      break;
    }

    spill_rec_t *rec;
    CHECKBAIL(0 == spf_next(scan, &rec, hj->errmsg, sizeof(hj->errmsg)));
    if (!rec) {
      break; // EOF
    }
    uint64_t hval = rec->hval;
    void *br = rec->raw;
    int brlen = rec->len;

    /* Add record to either hj->tab or other (higher up) spill build buckets */
    int destid = spill_id(sp, hval);
    if (destid == spid) {
      // insert BR into the htab
      void **pp = chtab_find(hj->tab, hval);

      // for HJ_IN or HJ_NOT_IN, we want to avoid duplicates in the hashtable,
      // but there is no way to do so unless we add a compare_build(br1, br2)
      // function to the dispatch function.

      atom_t *atom = arena_alloc(hj->arena, sizeof(atom_t) + brlen);
      if (!atom) {
        perr(hj, "out of memory %s", FLINE);
        goto bail;
      }

      memcpy(atom->rec, br, brlen);
      if (!pp) {
        pp = chtab_emplace_ex(hj->tab, hval);
        if (!pp) {
          perr(hj, "out of memory %s", FLINE);
          goto bail;
        }
      }

      atom->next = (intptr_t)*pp;
      *pp = atom;
      continue;
    }

    // insert BR into another build bucket
    if (destid < spid) { // MUST go to a higher bucket by design
      perr(hj, "internal error - destid > id %s", FLINE);
      goto bail;
    }

    // build records inserted when N = 1 may need to go to other
    // buckets if current N is 3 (i.e. we did two more expands *after*
    // the records were expanded).
    void *dest = spill_emplace(sp, SPILL_BUILD, hval, brlen, hj->errmsg,
                               sizeof(hj->errmsg));
    CHECKBAIL(dest);

    memcpy(dest, br, brlen);
  }

  // Done with this spill file
  spf_close(scan, /*truncate*/ 1, 0, 0);
  hj->spf = 0;
  return 0;

bail:
  if (scan) {
    spf_close(scan, 0, 0, 0);
    hj->spf = 0;
  }
  return -1;
}

/*
 *  Probe the hashtable with records from a particular spill probe bucket.
 *  Call matchfn for each hit/miss entries.
 */
static int probe(hj_t *hj, int spid, hj_matchfn_t *matchfn) {

  // printf("--- probe %d\n", spid);
  spill_t *sp = hj->spill;

  // Make sure all records have landed on disk.
  CHECK(0 == spill_flush(sp, hj->errmsg, sizeof(hj->errmsg)));

  // Open spill probe file for spid
  const char *path = spill_path_for_probe(sp, spid);
  if (!path) {
    return 0; // nothing to do. done.
  }

  if (hj->spf) {
    spf_close(hj->spf, 0, 0, 0);
    hj->spf = 0;
  }
  spf_t *scan = spf_scan(path, hj->errmsg, sizeof(hj->errmsg));
  CHECKBAIL(scan);
  hj->spf = scan;

  // Scan until EOF
  const char ISLEFT = (0 != (hj->type & HJ_LEFT));
  const char ISNOTIN = (hj->type == HJ_NOT_IN);
  const char ISIN = (hj->type == HJ_IN);
  for (;;) {
    if (checkstop(hj)) {
      break;
    }

    spill_rec_t *rec;
    if (spf_next(scan, &rec, hj->errmsg, sizeof(hj->errmsg))) {
      CHECKBAIL(0);
    }
    if (!rec) {
      break; // EOF
    }

    uint64_t hval = rec->hval;
    void *pr = rec->raw;

    // match against build tuples in htab
    hj->probe_count++;
    void **pp = chtab_find(hj->tab, hval);
    if (pp) {
      char hitflag = 0;
      for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
        void *br = atom->rec;
        if (hj->dispatch.cond(hj->context, br, pr)) {
          hitflag = 1;
          if (ISNOTIN) {
            // there is a hit, which means NOT_IN failed.
            goto next;
          }
          CHECK(0 == MATCH(hj, br, pr));
          atom->next |= 1; // mark hit
          if (ISIN) {
            // for IN, we are done on first hit
            goto next;
          }
        }
      }
      if (0 == hitflag) {
        if (ISLEFT) { // includes HJ_NOT_IN
          CHECK(0 == MATCH(hj, 0, pr));
        }
      }
      goto next;
    }
    if (ISLEFT) {
      CHECK(0 == MATCH(hj, 0, pr));
    }
  next:
  }

  // Done with this probe file
  spf_close(scan, /*truncate*/ 1, 0, 0);
  hj->spf = 0;
  return 0;

bail:
  if (scan) {
    spf_close(scan, 0, 0, 0);
    hj->spf = 0;
  }
  return -1;
}

static int scan_for_missed_records(hj_t *hj, hj_matchfn_t *matchfn) {
  // this function should only be called for a RIGHT or FULL join
  assert(hj->type & HJ_RIGHT);

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = hj->tab;

  for (int idx = chtab_first(tab, &hval, (void **)&atom); idx >= 0;
       idx = chtab_next(tab, idx, &hval, (void **)&atom)) {
    for (; atom; atom = (atom_t *)(atom->next & ~1)) {
      int hit = atom->next & 1;
      if (!hit) {
        void *br = atom->rec;
        CHECK(0 == MATCH(hj, br, 0));
      }
    }
  }
  return 0;
}

// Do hashjoin on each pair of build/probe files.
int hj_probe_spilled(hj_t *hj, hj_matchfn_t matchfn) {
  spill_t *sp = hj->spill;

  // Scan the current hashtable.
  // All tuples in the current hashtable that were not hit are misses.
  // For RIGHT/FULL outer join, invoke matchfn on them with build records from
  // hashtable and null probe (left) records.
  if (hj->type & HJ_RIGHT) {
    CHECK(0 == scan_for_missed_records(hj, matchfn));
  }

  for (int id = 0; spill_has_id(sp, id); id++) {

    // Build up a new hashtable for spill build file 'id'
    CHECK(0 == build(hj, id));

    // Probe the hashtable for spill probe file 'id'
    CHECK(0 == probe(hj, id, matchfn));

    // Scan the current hashtable.
    // All tuples in the current hashtable that were not hit are misses.
    // For RIGHT/FULL outer join, invoke matchfn on them with build records from
    // hashtable and null probe records.
    if (hj->type & HJ_RIGHT) {
      CHECK(0 == scan_for_missed_records(hj, matchfn));
    }
  }

  return 0;
}

void hj_release(hj_t *hj) {
  if (hj) {
    if (hj->spf) {
      spf_close(hj->spf, 0, 0, 0);
    }
    spill_destroy(hj->spill);
    chtab_destroy(hj->tab);
    arena_destroy(hj->arena);
    free(hj);
  }
}

int hj_nspill(hj_t *hj) { return (1 << hj->spill->N); }
