#define _POSIX_C_SOURCE 200809L
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

/* file format:

   [BUILD section]
   [PROBE section]
   [MARKER]

   Both Build and Probe sections are just sequential serialized records.

   The Marker contains the sizes of the build and probe sections.

 */

#define MAGIC "SPILL001"

/*
static int readfully(int fd, void *buf, int len, char *errmsg, int errlen) {
  char *p = buf;
  char *q = buf + len;
  while (p < q) {
    int n = read(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s %s", strerror(errno), FLINE);
    }

    if (n == 0) {
      return perr("%s %s", "read beyond eof", FLINE);
    }

    p += n;
  }

  return 0;
}
*/

static int writefully(int fd, const void *buf, int len, char *errmsg,
                      int errlen) {
  const char *p = buf;
  const char *q = buf + len;
  while (p < q) {
    int n = write(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s %s", strerror(errno), FLINE);
    }

    if (n == 0) {
      return perr("%s %s", strerror(errno), FLINE);
    }

    p += n;
  }

  return 0;
}

struct spf_t {
  const char *path;
  int fd;
  int append;
  char *buf;
  int bot, top, max;
  int eof;
};

spf_t *spf_open(const char *path, char *errmsg, int errlen) {

  spf_t *spf = calloc(1, sizeof(*spf));
  if (!spf) {
    perr("%s %s", "out of memory", FLINE);
    goto bail;
  }

  spf->fd = open(path, O_APPEND | O_WRONLY, 0600);
  if (spf->fd <= 0) {
    perr("%s %s", strerror(errno), FLINE);
    goto bail;
  }

  spf->append = 1;
  spf->max = 16 * 1024;
  spf->buf = malloc(spf->max);
  spf->path = strdup(path);
  if (!(spf->buf && spf->path)) {
    perr("out of memory %s", FLINE);
    goto bail;
  }

  return spf;

bail:
  spf_close(spf, 1, errmsg, errlen);
  return 0;
}

static int flush(spf_t *spf, char *errmsg, int errlen) {
  if (!spf->append) {
    return 0;
  }
  int nb = spf->top - spf->bot;
  CHECK(0 == writefully(spf->fd, spf->buf + spf->bot, nb, errmsg, errlen));
  spf->bot = spf->top = 0;
  return 0;
}

int spf_close(spf_t *spf, int truncate_flag, char *errmsg, int errlen) {
  int ret = 0;
  if (spf) {
    int fd = spf->fd;
    if (fd >= 0) {
      if (truncate_flag) {
        ret = ret ? ret : ftruncate(fd, 0);
      } else {
        ret = ret ? ret : flush(spf, errmsg, errlen);
      }
      close(fd);
    }
    free((void *)spf->path);
    free(spf->buf);
    free(spf);
  }
  return ret;
}

int spf_write(spf_t *spf, const spill_rec_t *rec, char *errmsg, int errlen) {
  assert(spf->append);
  assert(rec->magic == SPILL_REC_MAGIC);
  int recsz = rec_size(rec);

  const char *p = (const char *)rec;
  int plen = recsz;

  while (plen > 0) {
    // #bytes available for writing in fp->buf
    int nb = spf->max - spf->top;
    if (nb == 0) {
      CHECK(0 == flush(spf, errmsg, errlen));
      continue;
    }
    if (nb > plen) {
      nb = plen;
    }
    memcpy(spf->buf + spf->top, p, nb);
    spf->top += nb;
    plen -= nb;
    p += nb;
  }

  return 0;
}

spf_t *spf_scan(const char *path, char *errmsg, int errlen) {
  spf_t *spf = calloc(1, sizeof(*spf));
  if (!spf) {
    perr("out of memory %s", FLINE);
    goto bail;
  }

  spf->fd = open(path, O_RDONLY);
  if (spf->fd < 0) {
    perr("%s %s", strerror(errno), FLINE);
    goto bail;
  }
  spf->append = 0;
  spf->max = 32 * 1024;
  spf->buf = malloc(spf->max);
  spf->path = strdup(path);
  if (!(spf->buf && spf->path)) {
    perr("%s %s", "out of memory", FLINE);
    goto bail;
  }

  return spf;

bail:
  spf_close(spf, 0, errmsg, errlen);
  return 0;
}

static int read_more(spf_t *spf, char *errmsg, int errlen) {
  if (spf->eof) {
    return 0;
  }

  // shift buf[bot..top] to buf[0]
  if (spf->bot) {
    int inuse = spf->top - spf->bot;
    memmove(spf->buf, spf->buf + spf->bot, inuse);
    spf->bot = 0;
    spf->top = inuse;
  }

  // nb bytes of free buffer
  int nb = spf->max - spf->top;
  if (nb == 0) {
    // extend the buffer
    int newmax = spf->max * 1.5;
    if (newmax < 0) {
      return perr("spill_scan(%s): record is too big %s", spf->path, FLINE);
    }
    char *tmp = realloc(spf->buf, newmax);
    if (!tmp) {
      return perr("out of memory %s", FLINE);
    }
    spf->buf = tmp;
    spf->max = newmax;
    nb = spf->max - spf->top;
  }
  assert(nb > 0);

again:
  int n = read(spf->fd, spf->buf + spf->top, nb);
  if (n <= 0) {
    if (n == 0) {
      spf->eof = 1;
      return 0;
    }
    /* n < 0 */
    if (errno == EAGAIN || errno == EINTR) {
      goto again;
    }
    return perr("%s %s", strerror(errno), FLINE);
  }
  spf->top += n;
  return 0;
}

int spf_next(spf_t *spf, spill_rec_t **prec, char *errmsg, int errlen) {
  assert(!spf->append);
  spill_rec_t *rec = 0;
  int recsz = 0;

  while (!rec) {
    int eof = spf->eof;

    // number of valid bytes in buf[]
    int nb = spf->top - spf->bot;
    if (nb == 0 && spf->eof) {
      // signal EOF to caller
      *prec = 0;
      return 0;
    }

    // enough for the record header?
    if (nb > (int)sizeof(*rec)) {
      // obtain the record size using the header
      rec = (spill_rec_t *)&spf->buf[spf->bot];
      recsz = rec_size(rec);

      // enough for one full record?
      if (nb < recsz) {
        rec = 0;
      }
    }

    // read more into buffer if we still don't have a complete record
    if (!rec) {
      if (eof) {
        return perr("partial last record in spill file %s", FLINE);
      }
      CHECK(0 == read_more(spf, errmsg, errlen));
    }
  }

  // return the rec
  assert(rec->magic == SPILL_REC_MAGIC);
  *prec = rec;

  // next byte to read is beyond this record
  spf->bot += recsz;

  return 0;
}
