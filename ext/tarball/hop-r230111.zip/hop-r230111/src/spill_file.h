#ifndef SPILL_FILE_H
#define SPILL_FILE_H

#include <stdint.h>

// A serialized record in the spill file
#define SPILL_REC_MAGIC 0x739132aa
typedef struct spill_rec_t spill_rec_t;
struct spill_rec_t {
  int32_t magic;
  int32_t len;
  uint64_t hval;
  char raw[0]; // len bytes
};

static inline int rec_size(const spill_rec_t *rp) {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Warray-bounds"
  // size of spill record, inclusive of header
  return &rp->raw[rp->len] - (char *)rp;
#pragma GCC diagnostic pop
}

typedef struct spf_t spf_t;

spf_t *spf_open(const char *path, char *errmsg, int errlen);
int spf_close(spf_t *spf, int truncate_flag, char *errmsg, int errlen);
int spf_write(spf_t *spf, const spill_rec_t *rec, char *errmsg, int errlen);

spf_t *spf_scan(const char *path, char *errmsg, int errlen);
int spf_next(spf_t *spf, spill_rec_t **prec, char *errmsg, int errlen);

#endif /* SPILL_FILE_H */
