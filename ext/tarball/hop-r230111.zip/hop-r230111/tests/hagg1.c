#include "../src/hashagg.h"
#include "harness.h"

/*
   Do agg count, sum, avg on a table like this:

   A    B
   1    1
   2    2
   1    3
   2    4
   1    5
   2    6
   1    7
   2    8

   select A, count(B), sum(B), avg(B) from T group by A;
*/

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples
typedef struct tuple_t tuple_t;
struct tuple_t {
  int A;
  int B;
};

// Generate tuples
static int get_tuple(tuple_t *tp) {
  static int serial = 0;
  if (serial >= 8) {
    return -1;
  }
  serial++;

  tp->A = 1 + (serial - 1) % 2;
  tp->B = serial;
  printf("%d %d\n", tp->A, tp->B);
  return 0;
}

static int reclen(void *context, const void *rec) {
  (void)context;
  (void)rec;
  return sizeof(tuple_t);
}

// Two tuples are equal if t1->A == t2->A
static int keyeq(void *context, void *rec1, void *rec2) {
  (void)context;
  const tuple_t *t1 = rec1;
  const tuple_t *t2 = rec2;
  return t1->A == t2->A;
}

// Our agg will store count and sum
typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  int count;
  int sum;
};

// On init: alloc memory for aggdata associated with rec and initialize with
// count and sum.
static void *init(void *context, void *rec) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = malloc(sizeof(*dp));
  if (dp) {
    dp->count = 1;
    dp->sum = tp->B;
    printf("init %d %d sum %d\n", tp->A, tp->B, dp->sum);
  }
  return dp;
}

// On transition: update count and sum of aggdata related to rec
static void *trans(void *context, void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  printf("trans %d %d sum %d -> %d\n", tp->A, tp->B, dp->sum, dp->sum + tp->B);
  dp->count++;
  dp->sum += tp->B;
  return dp;
}

static int first = 1;

// On finalize: save results and free aggdata allocated
static void finalize(const tuple_t *tp, aggdata_t *dp) {
  if (first) {
    printf("%s\t%s\t%s\t%s\n", "A", "count", "sum", "avg");
    first = 0;
  }
  printf("%d\t%d\t%d\t%f\n", tp->A, dp->count, dp->sum,
         dp->sum / (double)dp->count);
  free(dp);
}

int main() {
  // Create a hashagg
  char *context = 0;
  hagg_dispatch_t dispatch = {0};
  dispatch.keyeq = keyeq;
  dispatch.init = init;
  dispatch.trans = trans;
  dispatch.reclen = reclen;
  hagg_t *agg = hagg_start(context, 100, ".", &dispatch);

  // Feed the hashagg with tuples
  printf("\n--- feeding\n");
  while (1) {
    tuple_t tup;
    if (0 != get_tuple(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.A);
    CHECK(0 == hagg_feed(agg, hval, &tup));
  }

  // Obtain the #batches
  int top = hagg_batch_max(agg);

  // Process each batch
  for (int id = 0; id < top; id++) {
    printf("\n--- finalizing %d\n", id);
    hagg_iter_t iter;
    CHECK(0 == hagg_process_batch(agg, id, &iter));
    while (1) {
      const void *rec;
      void *data;
      CHECK(0 == hagg_next(&iter, &rec, &data));
      if (rec == 0) {
        break; // EOF
      }
      finalize((const tuple_t *)rec, (aggdata_t *)data);
    }
  }

  // Done!
  hagg_release(agg);

  return 0;
}
