// FULL JOIN
#include "hjrec.hpp"

int main() {
  char *context = 0;
  hj_dispatch_t dispatch;
  memset(&dispatch, 0, sizeof(dispatch));

  printf("\nFULL OUTER JOIN\n\n");
  dispatch.reclen_build = reclen;
  dispatch.reclen_probe = reclen;
  dispatch.cond = keyeq;
  hj = hj_start(context, HJ_FULL, 100, ".", &dispatch);
  CHECK(hj);
  build();
  probe();
  hj_release(hj);

  print(result);

  printf("hit_both = %d\n", count_hit_both);
  printf("hit_left = %d\n", count_hit_left);
  printf("hit_right = %d\n", count_hit_right);
  CHECK(50 == count_hit_both);
  CHECK(50 == count_hit_left);
  CHECK(50 == count_hit_right);
  printf("\n");

  return 0;
}
