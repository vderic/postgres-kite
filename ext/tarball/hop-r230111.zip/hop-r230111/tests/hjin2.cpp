#include "hjin.hpp"

int main() {
  char *context = 0;
  hj_dispatch_t dispatch;
  memset(&dispatch, 0, sizeof(dispatch));

  printf("\nJOIN NOT IN\n\n");
  dispatch.reclen_build = reclen;
  dispatch.reclen_probe = reclen;
  dispatch.cond = keyeq;
  hj = hj_start(context, HJ_NOT_IN, 100, ".", &dispatch);
  CHECK(hj);
  build();
  probe();
  hj_release(hj);

  print(result);

  printf("\n");
  printf("hit_both = %d\n", count_hit_both);
  printf("hit_left = %d\n", count_hit_left);
  printf("hit_right = %d\n", count_hit_right);
  printf("\n");

  return 0;
}
