#pragma once

extern "C" {
#include "../src/hashjoin.h"
#include "harness.h"
}
#include <algorithm>
#include <string>
#include <vector>

enum book_field_t {
  BOOK_ID,
  BOOK_TITLE,
  BOOK_TYPE,
  BOOK_AUTHOR_ID,
  BOOK_EDITOR_ID,
  BOOK_TRANSLATOR_ID
};

const std::vector<const char *> BOOK = {
    "1#Time to Grow Up!#original#11#21#",
    "2#Your Trip#translated#15#22#32",
    "3#Lovely Love#original#14#24#",
    "4#Dream Your Life#original#11#24#",
    "5#Oranges#translated#12#25#31",
    "6#Your Happy Life#translated#15#22#33",
    "7#Applied AI#translated#13#23#34",
    "8#My Last Book#original#11#28#",
};

enum author_field_t { AUTHOR_ID, AUTHOR_NAME };
const std::vector<const char *> AUTHOR = {
    "11#Ellen Writer", "12#Olga Savelieva", "13#Jack Smart",
    "14#Donald Brain", "15#Yao Dou",
};

enum editor_field_t { EDITOR_ID, EDITOR_NAME };
const std::vector<const char *> EDITOR = {
    "21#Daniel Brown",     "22#Mark Johnson",     "23#Maria Evans",
    "24#Cathrine Roberts", "25#Sebastian Wright", "26#Barbara Jones",
    "27#Matthew Smith",
};

enum translator_field_t { TRANSLATOR_ID, TRANSLATOR_NAME };
const std::vector<const char *> TRANSLATOR = {
    "31#Ira Davies",
    "32#Ling Weng",
    "33#Kristian Green",
    "34#Roman Edwards",
};

static std::string field(const char *rec, int fnum) {
  const char *p = rec;
  for (int i = 0; i < fnum; i++) {
    p = strchr(p, '#');
    CHECK(p);
    p++;
  }
  const char *q = strchr(p, '#');
  size_t len = q ? q - p : strlen(p);
  return std::string{p, len};
}

static int reclen(void *context, const void *rec) {
  (void)context;
  return strlen((const char *)rec) + 1;
}

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

static void print(const std::vector<std::string> &vec) {
  for (auto &s : vec) {
    printf("%s\n", s.c_str());
  }
}
