#pragma once

extern "C" {
#include "../src/hashjoin.h"
#include "harness.h"
}

#include <algorithm>
#include <string>
#include <vector>

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the left side of the join
typedef struct left_t left_t;
struct left_t {
  int side;
  int key;
  int value;
};
static int is_left(const void *p) { return ((left_t *)p)->side == 'L'; }

// Tuples from the right side of the join
typedef struct right_t right_t;
struct right_t {
  int side;
  char key[100];
  int value;
};
static int is_right(const void *p) { return ((right_t *)p)->side == 'R'; }

// Get the next left tuple
// even numbers [2,4,6,...,200]
static int get_left(left_t *tp) {
  static int serial = 0;
  if (serial >= 200) {
    return -1;
  }
  serial += 2;

  tp->side = 'L';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple
// serial [1..100]
static int get_right(right_t *tp) {
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  memset(tp, 0, sizeof(*tp)); // silent valgrind
  tp->side = 'R';
  sprintf(tp->key, "%d", serial);
  tp->value = serial;

  return 0;
}

int count_hit_both = 0;
int count_hit_right = 0;
int count_hit_left = 0;
std::vector<std::string> result;

static void print(const std::vector<std::string> &vec) {
  for (auto &s : vec) {
    printf("%s\n", s.c_str());
  }
}

static int match(void *context, void *br, void *pr) {
  (void)context;
  CHECK(!br || is_right(br));
  CHECK(!pr || is_left(pr));
  auto RP = (const right_t *)br;
  auto LP = (const left_t *)pr;
  char out[1000];

  if (!LP) {
    sprintf(out, "hit (- - -) (%c %s %d)", RP->side, RP->key, RP->value);
    count_hit_right++;
  } else if (!RP) {
    sprintf(out, "hit (%c %d %d) (- - -)", LP->side, LP->key, LP->value);
    count_hit_left++;
  } else {
    sprintf(out, "hit (%c %d %d) (%c %s %d)", LP->side, LP->key, LP->value,
            RP->side, RP->key, RP->value);
    count_hit_both++;
  }
  result.push_back(out);
  return 0;
}

static int keyeq(void *context, void *br, void *pr) {
  (void)context;
  CHECK(is_right(br));
  CHECK(is_left(pr));
  auto RP = (const right_t *)br;
  auto LP = (const left_t *)pr;
  return LP->key == atoi(RP->key);
}

static int reclen(void *context, const void *rec) {
  (void)context;
  if (is_left(rec)) {
    return sizeof(left_t);
  }
  if (is_right(rec)) {
    return sizeof(right_t);
  }
  CHECK(0);
  return -1;
}

hj_t *hj = 0;

// Scan right side and feed to hj
static void build() {

  // For each tuple from RIGHT side
  for (;;) {
    right_t tup;
    if (get_right(&tup)) {
      break;
    }
    uint64_t hval = hashi(atoi(tup.key));

    CHECK(0 == hj_build(hj, hval, &tup));
  }
}

static void probe() {

  // For each tuple from LEFT side
  for (;;) {
    left_t tup;
    if (get_left(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    CHECK(0 == hj_probe(hj, hval, &tup, match));
  }

  CHECK(0 == hj_probe_spilled(hj, match));
}
