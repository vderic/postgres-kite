#define _XOPEN_SOURCE 500
#include "hashagg.h"
#include "arena.h"
#include "chtab.h"
#include "komihash.h"
#include "spill.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(agg, fmt, ...)                                                    \
  reterr(snprintf((agg)->errmsg, sizeof((agg)->errmsg), fmt, ##__VA_ARGS__))

static void dummy_reset(void *){};

static int dummy_checkstop(void *) { return 0; }

static void default_serialize(void *context, const void *rec, void *dest,
                              int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

struct hagg_t {
  void *context;
  chtab_t *tab;
  spill_t *spill;
  arena_t *arena; /* stores atoms */
  const char *spilldir;
  int64_t memlimit;
  int64_t *aggdata_memusage;
  unsigned int intermittent_count;
  int stopped; // stop flag. once stop, ignore all requests.
  hagg_dispatch_t dispatch;
  int64_t count; // #rec fed to the hagg

  hagg_t *subhagg; // used for recursive hashagg on spilled batches
  int32_t subseed; // additional hval seed when processing spilled batches
  int sublevel;    // recursion depth

  spf_t *scan; // active scan
  char errmsg[200];
};

const char *hagg_errmsg(hagg_t *agg) { return agg->errmsg; }

hagg_t *hagg_start(void *context, int64_t memlimit, int64_t *aggdata_memusage,
                   const char *spilldir, const hagg_dispatch_t *dispatch) {

  hagg_t *agg = calloc(1, sizeof(*agg));
  CHECKBAIL(agg);

  agg->tab = chtab_create();
  CHECKBAIL(agg->tab);

  agg->spilldir = strdup(spilldir);
  CHECKBAIL(agg->spilldir);

  agg->arena = arena_create();
  CHECKBAIL(agg->arena);

  agg->context = context;
  agg->memlimit = memlimit;
  agg->aggdata_memusage = aggdata_memusage;
  agg->dispatch = *dispatch;
  if (!agg->dispatch.reset) {
    agg->dispatch.reset = dummy_reset;
  }
  if (!agg->dispatch.serialize) {
    agg->dispatch.serialize = default_serialize;
  }
  if (!agg->dispatch.checkstop) {
    agg->dispatch.checkstop = dummy_checkstop;
  }

  agg->subseed = rand();

  return agg;

bail:
  hagg_release(agg);
  return 0;
}

void hagg_release(hagg_t *agg) {
  if (agg) {
    if (agg->scan) {
      spf_close(agg->scan, 0, 0, 0);
    }

    chtab_destroy(agg->tab);
    arena_destroy(agg->arena);
    hagg_release(agg->subhagg);

    spill_destroy(agg->spill);

    free((void *)agg->spilldir);
    free(agg);
  }
}

static inline int checkstop(hagg_t *agg) {
  agg->stopped |= (0xfff == (agg->intermittent_count++ & 0xfff)
                       ? agg->dispatch.checkstop(agg->context)
                       : 0);
  return agg->stopped;
}

// The hashtable contains pointers to list of atoms with the same hashval.
// Each atom contains pointers to the record and the associated agg data.
typedef struct atom_t atom_t;
struct atom_t {
  atom_t *next;  // link to next atom with the same hval
  void *aggdata; // agg data returned by init() and trans()
  int32_t len;   // len of rec[]
  char rec[0];   // rec[len] bytes
};

// Insert a new key into the htab. This will invoke initfn() on the new entry.
// pp is a pointer to a location in the hashtable. We need to hook the new
// atom to the list achored at pp.
static int new_atom(hagg_t *agg, void **pp, void *rec, int len) {
  if (len < 0) {
    // note: reclen() can be expensive. Call it only when we absolutely need it.
    len = agg->dispatch.reclen(agg->context, rec);
  }
  atom_t *atom = arena_alloc(agg->arena, sizeof(atom_t) + len);
  if (!atom) {
    return perr(agg, "out of memory (%s)", FLINE);
  }
  atom->len = len;
  agg->dispatch.serialize(agg->context, rec, atom->rec, len);
  atom->next = *pp;
  *pp = atom;

  atom->aggdata = agg->dispatch.init(agg->context);
  if (!atom->aggdata) {
    return perr(agg, "initfn failed (%s)", FLINE);
  }

  atom->aggdata = agg->dispatch.trans(agg->context, rec, atom->aggdata);
  return atom->aggdata ? 0 : perr(agg, "transfn failed (%s)", FLINE);
}

// scan the list looking for (atom->rec == rec)
static inline atom_t *chase(hagg_t *agg, atom_t *list, void *rec) {
  atom_t *atom = list;
  while (atom && !agg->dispatch.keyeq(agg->context, atom->rec, rec)) {
    atom = atom->next;
  }
  return atom;
}

int hagg_feed(hagg_t *agg, uint64_t hval, void *rec, int len) {

  if (checkstop(agg)) {
    return 0;
  }

  // Accounting
  agg->count++;

  // Look for records matching hval in chtab.
  void **pp = chtab_find(agg->tab, hval);
  if (pp) {
    // Found an entry!
    // Look for records matching rec in atom chain.
    atom_t *atom = chase(agg, (atom_t *)*pp, rec);
    if (atom) {
      // Found a match: do trans(). This is the HOT path!!!
      // Most times, we can save a call to reclen() on this call path.
      atom->aggdata = agg->dispatch.trans(agg->context, rec, atom->aggdata);
      return atom->aggdata ? 0 : perr(agg, "transfn failed (%s)", FLINE);
    }

    // Not found: make a new atom, do init(), trans(), and attach to list pp
    return new_atom(agg, pp, rec, len);
  }

  // Insert if htab is below memory limit
  if (arena_size(agg->arena) + *agg->aggdata_memusage < agg->memlimit) {
    // Call chtab_emplace_ex() which skips a call to its internal find()
    // routine. This is a slight optimization when we know for sure hval does
    // not exist in the chtab.
    pp = chtab_emplace_ex(agg->tab, hval);
    return new_atom(agg, pp, rec, len);
  }

  // Else spill the tuple.

  // If necessary, initialize the spill files.
  if (!agg->spill) {
    agg->spill = spill_create(agg->spilldir, /*use_bloom_filter*/ 0,
                              agg->errmsg, sizeof(agg->errmsg));
    CHECK(agg->spill);
  }

  // If ncessary, obtain reclen.
  if (len < 0) {
    // Note: reclen() can be expensive. Call only when we absolutely need it.
    len = agg->dispatch.reclen(agg->context, rec);
  }

  // Spill it.
  void *dest =
      spill_emplace(agg->spill, hval, len, agg->errmsg, sizeof(agg->errmsg));
  CHECK(dest);

  // Copy to dest.
  agg->dispatch.serialize(agg->context, rec, dest, len);

  return 0;
}

static int do_subhagg(hagg_t *agg, int spbkt) {
  // Cleanup
  if (agg->scan) {
    spf_close(agg->scan, 0, 0, 0);
    agg->scan = 0;
  }

  // Start a sub hashagg on the batch.
  hagg_release(agg->subhagg);
  agg->subhagg = hagg_start(agg->context, agg->memlimit, agg->aggdata_memusage,
                            agg->spill->dir, &agg->dispatch);
  if (!agg->subhagg) {
    return perr(agg, "out of memory (%s)", FLINE);
  }
  agg->subhagg->sublevel = agg->sublevel + 1;

  // Scan the spill file, and feed to subhagg
  const char *path = spill_path(agg->spill, spbkt);
  if (!path) {
    return 0; // nothing to do. done.
  }
  agg->scan = spf_scan(path, agg->errmsg, sizeof(agg->errmsg));
  CHECK(agg->scan);

  // For each spill record, rehash and feed to subhagg.
  while (!agg->stopped) {
    spill_rec_t *sprec;
    CHECK(0 == spf_next(agg->scan, &sprec, agg->errmsg, sizeof(agg->errmsg)));
    if (!sprec) {
      break; // EOF
    }
    uint64_t hval = sprec->hval;
    void *rec = sprec->raw;

    // Rehash with subseed and insert into subhagg.
    hval = komihash(&agg->subseed, sizeof(agg->subseed), sprec->hval);
    if (hagg_feed(agg->subhagg, hval, rec, sprec->len)) {
      strcpy(agg->errmsg, agg->subhagg->errmsg);
      return -1;
    }

    agg->stopped |= agg->subhagg->stopped;
  }
  spf_close(agg->scan, /*truncate*/ 1, 0, 0);
  agg->scan = 0;
  return 0;
}

// For each entry in htab, invoke finalize function.
static int finalize(hagg_t *agg, hagg_finfn_t *fin) {

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = agg->tab;

  // first slot
  int idx = chtab_first(tab, &hval, (void **)&atom);
  while (idx >= 0) {
    if (checkstop(agg)) {
      return 0;
    }

    // slot contains a list.
    // scan the list and invoke fin()
    for (; atom; atom = atom->next) {
      if (fin(agg->context, atom->rec, atom->aggdata)) {
        return perr(agg, "finfn failed (%s)", FLINE);
      }
    }

    // next slot
    idx = chtab_next(tab, idx, &hval, (void **)&atom);
  }

  return 0;
}

int hagg_finalize(hagg_t *agg, hagg_finfn_t *fin) {
  if (checkstop(agg)) {
    return 0;
  }

  // Finalize entries in the htab.
  CHECK(0 == finalize(agg, fin));

  // Done with the htab
  chtab_destroy(agg->tab);
  arena_destroy(agg->arena);
  agg->tab = 0, agg->arena = 0, agg->subhagg = 0;
  agg->dispatch.reset(agg->context);

  if (agg->spill) {

    // No more writes to spill. Flush and close spill files.
    CHECK(0 == spill_close(agg->spill, agg->errmsg, sizeof(agg->errmsg)));

    // Process each spill file recursively.
    for (int bkt = 0; bkt < SPILL_NBUCKET && !agg->stopped; bkt++) {
      // Process the bucket. This will create a new agg->subhagg.
      CHECK(0 == do_subhagg(agg, bkt));

      // Finalize the subhagg.
      if (hagg_finalize(agg->subhagg, fin)) {
        strcpy(agg->errmsg, agg->subhagg->errmsg);
        return -1;
      }
      agg->stopped |= agg->subhagg->stopped;

      // Release the subhagg asap.
      hagg_release(agg->subhagg);
      agg->subhagg = 0;
    }
  }

  return 0;
}

int hagg_iter_init(hagg_t *agg, hagg_iter_t *iter) {
  memset(iter, 0, sizeof(*iter));
  iter->top = 1;
  hagg_subiter_t *sip = &iter->stack[iter->top - 1];
  sip->agg = agg;
  sip->bkt = -1;
  uint64_t hval;
  sip->idx = chtab_first(sip->agg->tab, &hval, &sip->atom);
  return 0;
}

int hagg_iter_next(hagg_iter_t *iter, void **ret_rec, void **ret_aggrec,
                   char *errmsg, int errmsglen) {
again:
  assert(1 <= iter->top && iter->top < HAGG_ITER_STACKMAX);
  hagg_subiter_t *sip = &iter->stack[iter->top - 1];
  if (sip->atom) {
    // return current slot data
    atom_t *atom = sip->atom;
    *ret_rec = atom->rec;
    *ret_aggrec = atom->aggdata;

    // move to next slot
    uint64_t hval;
    sip->idx = chtab_next(sip->agg->tab, sip->idx, &hval, &sip->atom);
    return 0;
  }

  if (sip->bkt < 0) {
    // done with the hashtab.
    chtab_destroy(sip->agg->tab);
    arena_destroy(sip->agg->arena);
    sip->agg->tab = 0, sip->agg->arena = 0, sip->agg->subhagg = 0;
    sip->agg->dispatch.reset(sip->agg->context);

    if (sip->agg->spill) {
      // No more writes to spill. Flush and close spill files.
      CHECK(0 == spill_close(sip->agg->spill, errmsg, errmsglen));
    }
  }

  // move to next spill bucket
  sip->bkt++;
  if (sip->bkt >= SPILL_NBUCKET || 0 == sip->agg->spill) {
    // all buckets are done for this subhagg. move up.
    iter->top--;
    if (iter->top == 0) {
      // all done
      *ret_rec = 0;
      *ret_aggrec = 0;
      return 0;
    }
    goto again;
  }

  if (iter->top >= HAGG_ITER_STACKMAX) {
    snprintf(errmsg, errmsglen, "hashagg spill overflow (%s)", FLINE);
    return -1;
  }

  if (do_subhagg(sip->agg, sip->bkt)) {
    snprintf(errmsg, errmsglen, "%s", sip->agg->errmsg);
    return -1;
  }
  hagg_t *subhagg = sip->agg->subhagg;
  iter->top++;
  sip = &iter->stack[iter->top - 1];
  sip->agg = subhagg;
  sip->bkt = -1;
  uint64_t hval;
  sip->idx = chtab_first(sip->agg->tab, &hval, &sip->atom);
  goto again;
}
