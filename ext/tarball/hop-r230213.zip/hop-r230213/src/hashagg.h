#ifndef HASHAGG_H
#define HASHAGG_H

#include <stdint.h>

typedef struct hagg_t hagg_t;

// Check if two records fed to hagg are equal.
// serialized_rec1 and rec2 are not const because they maybe modified
// (swizzled). serialized_rec1 is the serialized record from hagg_serializefn_t
// rec2 is the source data pointer passed from hagg_feed
typedef int hagg_keyeqfn_t(void *context, void *serialized_rec1, void *rec2);

// Initialize a new agg entry. Returns an aggrec to be associated with
// a new entry.  This probably involves a malloc() call to create aggrec.
//
// Note: this function probably needs to also return the #bytes memory
// consumed.
typedef void *hagg_initfn_t(void *context);

// Transition function. Given (rec, aggrec), return same or different
// aggrec to be associated with rec.  This probably involves
// realloc(aggrec) if the associated struct changes size.
// rec is not const because it may be modified (swizzled).
// rec is the source data pointer passed from hagg_feed
//
// Note: this function probably needs to also return the delta #bytes of
// of memory consumed.
typedef void *hagg_transfn_t(void *context, void *rec, void *aggrec);

// Finalize function. Take (rec, aggrec) and do something with it
// before it is destroyed.  This probably involves free(aggrec).
// serialized_rec is not const because it may be modified (swizzled).
// serialized_rec is the serialized record from hagg_serializefn_t
typedef int hagg_finfn_t(void *context, void *serialized_rec, void *aggrec);

// Notification that the hashtable has been reset to empty
typedef void hagg_resetfn_t(void *context);

// Return the serialized length of rec.
// rec is the source data pointer passed from hagg_feed
typedef int hagg_reclenfn_t(void *context, const void *rec);

// Serialize rec to dest.
// rec is the source data pointer passed from hagg_feed
typedef void hagg_serializefn_t(void *context, const void *rec, void *dest,
                                int destsz);

// Callback that will be invoked from time to time. Return true to stop
// processing.
typedef int hagg_checkstopfn_t(void *context);

typedef struct hagg_dispatch_t hagg_dispatch_t;
struct hagg_dispatch_t {
  // mandatory
  hagg_keyeqfn_t *keyeq;
  hagg_initfn_t *init;
  hagg_transfn_t *trans;
  hagg_reclenfn_t *reclen;
  // optional
  hagg_resetfn_t *reset;
  hagg_serializefn_t *serialize;
  hagg_checkstopfn_t *checkstop;
};

/**
 *  Start a hashagg. Aggdata_memusage points to an address that stores
 *  the #bytes used for aggdata for this operation. The sum of this
 *  number and the bytes used in the hashtable is the total memory
 *  that is checked against memlimit to determine if the hashtable
 *  is full and new records should be spilled.
 *
 *  Returns NULL if out-of-memory.
 */
extern hagg_t *hagg_start(void *context, int64_t memlimit,
                          int64_t *aggdata_memusage, const char *spilldir,
                          const hagg_dispatch_t *dispatch);

/**
 * Feed a record R to the agg. Hagg will:
 *  1. Call reclenfn(R) if the supplied value is -1.
 *  2. Call the RR=serializefn(R) to make a copy of R internally.
 *  3. If the hashtable does not overflow, call initfn(RR) and transfn(RR).
 *     Otherwise, spill RR to disk.
 *
 * Returns 0 on success, -1 otherwise.
 *
 * Note: rec is not const because it may be modified (swizzled).
 */
extern int hagg_feed(hagg_t *agg, uint64_t hval, void *rec, int reclen);

/**
 *  Finalize the agg. The fin function will be invoked for each
 *  distinct entry in the hashtable. Returns 0 on success, -1
 *  otherwise.
 */
extern int hagg_finalize(hagg_t *agg, hagg_finfn_t *fin);

#define HAGG_ITER_STACKMAX 10
typedef struct hagg_subiter_t hagg_subiter_t;
struct hagg_subiter_t {
  hagg_t *agg;
  int bkt;
  int idx;
  void *atom;
};

typedef struct hagg_iter_t hagg_iter_t;
struct hagg_iter_t {
  hagg_subiter_t stack[HAGG_ITER_STACKMAX];
  int top;
};

extern int hagg_iter_init(hagg_t *agg, hagg_iter_t *iter);
extern int hagg_iter_next(hagg_iter_t *iter, void **ret_rec, void **ret_aggrec,
                          char *errmsg, int errmsglen);

/**
 * Release all resources.
 */
extern void hagg_release(hagg_t *agg);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hagg_errmsg(hagg_t *agg);

#endif /* HASHAGG_H */
