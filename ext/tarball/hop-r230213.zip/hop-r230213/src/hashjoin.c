#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "hashjoin.h"
#include "arena.h"
#include "chtab.h"
#include "komihash.h"
#include "spill.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

static int dummy_checkstop(void *) { return 0; }
static void default_serialize(void *context, const void *rec, void *dest,
                              int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

#define perr(hj, fmt, ...)                                                     \
  reterr(snprintf((hj)->errmsg, sizeof((hj)->errmsg), fmt, ##__VA_ARGS__))

struct hj_t {
  void *context;
  chtab_t *tab;
  const char *spdir;
  spill_t *spbuild;
  spill_t *spprobe;
  arena_t *arena;
  int64_t memlimit;
  hj_dispatch_t dispatch;
  unsigned int intermittent_count;
  int stopped;
  hj_type_t type;

  hj_t *subhj;     // used for recursive hj on spilled batches
  int32_t subseed; // additional hval seed when processing spilled batches
  int sublevel;    // recursion depth

  spf_t *scan; // active scan

  int64_t build_nrec;  // #rec inserted into build
  int64_t probe_nrec;  // #rec fed to probe
  int64_t probe_count; // #times the htab has been probed
  char errmsg[200];
};

const char *hj_errmsg(hj_t *hj) { return hj->errmsg; }

int64_t hj_nrec_in_build(hj_t *hj) { return hj->build_nrec; }
int64_t hj_nrec_in_probe(hj_t *hj) { return hj->probe_nrec; }
int64_t hj_probe_count(hj_t *hj) { return hj->probe_count; }

#define MATCH(hj, br, pr)                                                      \
  ((matchfn((hj)->context, br, pr)) ? perr(hj, "matchfn failed %s", FLINE) : 0)

hj_t *hj_start(void *context, hj_type_t type, int64_t memlimit,
               const char *spilldir, const hj_dispatch_t *dispatch) {
  hj_t *hj = calloc(1, sizeof(*hj));
  CHECKBAIL(hj);

  hj->tab = chtab_create();
  CHECKBAIL(hj->tab);

  hj->spdir = strdup(spilldir);
  CHECKBAIL(hj->spdir);

  hj->arena = arena_create();
  CHECKBAIL(hj->arena);

  hj->context = context;
  hj->memlimit = memlimit;
  hj->dispatch = *dispatch;
  hj->intermittent_count = 0;
  hj->type = type;

  hj->build_nrec = 0;
  hj->probe_nrec = 0;
  hj->probe_count = 0;

  if (!hj->dispatch.serialize_build) {
    hj->dispatch.serialize_build = default_serialize;
  }
  if (!hj->dispatch.serialize_probe) {
    hj->dispatch.serialize_probe = default_serialize;
  }
  if (!hj->dispatch.checkstop) {
    hj->dispatch.checkstop = dummy_checkstop;
  }

  hj->subseed = rand();

  return hj;

bail:
  hj_release(hj);
  return 0;
}

typedef struct atom_t atom_t;
struct atom_t {
  intptr_t next; // points to next atom_t; we steal a bit to indicate HIT.
  char rec[0];
};

static inline int checkstop(hj_t *hj) {
  hj->stopped |= (0xfff == (hj->intermittent_count++ & 0xfff)
                      ? hj->dispatch.checkstop(hj->context)
                      : 0);
  return hj->stopped;
}

/* Feed the hashjoin with a build record. The build record will either be
 * inserted into the htab or spilled. */
int hj_build(hj_t *hj, uint64_t hval, void *br, int brlen) {
  if (checkstop(hj)) {
    return 0;
  }

  brlen = (brlen < 0 ? hj->dispatch.reclen_build(hj->context, br) : brlen);

  void **pp = chtab_find(hj->tab, hval);
  // insert if hval already exists in htab
  int do_insert = (0 != pp);

  // insert if htab is below memory limit
  do_insert = do_insert || (arena_size(hj->arena) < hj->memlimit);

  if (do_insert) {
    // for HJ_IN or HJ_NOT_IN, we want to avoid duplicates in the hashtable,
    // but there is no way to do so unless we add a compare_build(br1, br2)
    // function to the dispatch function.

    // insert br into htab
    atom_t *atom = arena_alloc(hj->arena, sizeof(atom_t) + brlen);
    if (!atom) {
      return perr(hj, "out of memory (%s)", FLINE);
    }

    hj->dispatch.serialize_build(hj->context, br, atom->rec, brlen);
    if (!pp) {
      // insert into chtab if this is the first atom with 'hval'
      pp = chtab_emplace_ex(hj->tab, hval);
      if (!pp) {
        return perr(hj, "out of memory (%s)", FLINE);
      }
    }

    // link atom to the list at *pp
    atom->next = (intptr_t)*pp;
    *pp = atom;

  } else {
    // Else spill the tuple
    if (!hj->spbuild) {
      hj->spbuild = spill_create(hj->spdir, /*use_bloom_filter*/ 1, hj->errmsg,
                                 sizeof(hj->errmsg));
      CHECK(hj->spbuild);
    }

    // serialize br to a buffer in spill
    void *dest =
        spill_emplace(hj->spbuild, hval, brlen, hj->errmsg, sizeof(hj->errmsg));
    CHECK(dest);
    hj->dispatch.serialize_build(hj->context, br, dest, brlen);
  }

  hj->build_nrec++;
  return 0;
}

// Feed the hashjoin with a probe (left) record.
int hj_probe(hj_t *hj, uint64_t hval, void *pr, int prlen,
             hj_matchfn_t *matchfn) {
  if (checkstop(hj)) {
    return 0;
  }

  const char ISLEFT = (0 != (hj->type & HJ_LEFT));
  const char ISNOTIN = (hj->type == HJ_NOT_IN);
  const char ISIN = (hj->type == HJ_IN);

  // if the hval is in the htab, match with either hit or miss.
  void **pp = chtab_find(hj->tab, hval);
  if (pp) {
    char hitflag = 0;
    for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
      void *br = atom->rec;
      if (hj->dispatch.cond(hj->context, br, pr)) {
        hitflag = 1;
        if (ISNOTIN) {
          // there is a hit, which means NOT_IN failed.
          goto success;
        }
        CHECK(0 == MATCH(hj, br, pr));
        atom->next |= 1; // mark hit
        if (ISIN) {
          // for IN, we are done on first hit
          goto success;
        }
      }
    }
    if (0 == hitflag) {
      if (ISLEFT) { // includes HJ_NOT_IN
        CHECK(0 == MATCH(hj, 0, pr));
      }
    }
    // Done! because build0() would not spill records with this hval.
    // i.e. this hval does not exist in any build-side spill buckets.
    goto success;
  }

  // At this point, we know there is a MISS when:
  // 1. we are not spilling yet, or
  // 2. this tup will never match a build tuple based on a bloomfilter;
  if (!hj->spbuild || !mbloom_check(hj->spbuild->bloom, hval)) {
    // a MISS here means a match for HJ_LEFT or HJ_NOT_IN
    if (ISLEFT) { // includes HJ_NOT_IN
      CHECK(0 == MATCH(hj, 0, pr));
    }
    goto success;
  }

  // spill this tuple. It may match a build-tuple already in the spill.
  if (!hj->spprobe) {
    hj->spprobe = spill_create(hj->spdir, /*use_bloom_filter*/ 0, hj->errmsg,
                               sizeof(hj->errmsg));
    CHECK(hj->spprobe);
  }
  prlen = (prlen < 0 ? hj->dispatch.reclen_probe(hj->context, pr) : prlen);
  void *dest =
      spill_emplace(hj->spprobe, hval, prlen, hj->errmsg, sizeof(hj->errmsg));
  CHECK(dest);
  hj->dispatch.serialize_probe(hj->context, pr, dest, prlen);
  hj->probe_count--; /* this record will probe later. compensate for the
                        increment in success: */

success:
  hj->probe_nrec++;  // #rec fed to probe
  hj->probe_count++; // #times the htab has been probed
  return 0;
}

static int scan_for_missed_records(hj_t *hj, hj_matchfn_t *matchfn) {
  // this function should only be called for a RIGHT or FULL join
  assert(hj->type & HJ_RIGHT);

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = hj->tab;

  for (int idx = chtab_first(tab, &hval, (void **)&atom); idx >= 0;
       idx = chtab_next(tab, idx, &hval, (void **)&atom)) {
    for (; atom; atom = (atom_t *)(atom->next & ~1)) {
      int hit = atom->next & 1;
      if (!hit) {
        void *br = atom->rec;
        CHECK(0 == MATCH(hj, br, 0));
      }
    }
  }
  return 0;
}

static int process(hj_t *hj, int spid, hj_matchfn_t *matchfn) {

  if (checkstop(hj)) {
    return 0;
  }

  //  Cleanup
  if (hj->scan) {
    spf_close(hj->scan, 0, 0, 0);
    hj->scan = 0;
  }

  // Start a subhj on the batch
  hj_release(hj->subhj);
  hj->subhj =
      hj_start(hj->context, hj->type, hj->memlimit, hj->spdir, &hj->dispatch);
  if (!hj->subhj) {
    return perr(hj, "out of memory (%s)", FLINE);
  }
  hj->subhj->sublevel = hj->sublevel + 1;

  // Scan build side, and add to the subhj
  if (hj->spbuild) {
    const char *path = spill_path(hj->spbuild, spid);
    hj->scan = spf_scan(path, hj->errmsg, sizeof(hj->errmsg));
    CHECK(hj->scan);

    // For each build tuple ...
    while (!hj->stopped) {
      spill_rec_t *sprec;
      CHECK(0 == spf_next(hj->scan, &sprec, hj->errmsg, sizeof(hj->errmsg)));
      if (!sprec) {
        break; // EOF
      }
      uint64_t hval = sprec->hval;
      void *br = sprec->raw;
      int brlen = sprec->len;

      // Rehash with subseed and add to subhj's build side.
      hval = komihash(&hj->subseed, sizeof(hj->subseed), sprec->hval);
      if (hj_build(hj->subhj, hval, br, brlen)) {
        strcpy(hj->errmsg, hj->subhj->errmsg);
        return -1;
      }

      hj->stopped |= hj->subhj->stopped;
    }
    spf_close(hj->scan, /*truncate*/ 1, 0, 0);
    hj->scan = 0;
  }

  // Scan probe side, and add to the subhj
  if (hj->spprobe) {
    const char *path = spill_path(hj->spprobe, spid);
    // Scan probe side
    hj->scan = spf_scan(path, hj->errmsg, sizeof(hj->errmsg));
    CHECK(hj->scan);

    // For each probe tuple ...
    while (!hj->stopped) {
      spill_rec_t *sprec;
      CHECK(0 == spf_next(hj->scan, &sprec, hj->errmsg, sizeof(hj->errmsg)));
      if (!sprec) {
        break; // EOF
      }
      uint64_t hval = sprec->hval;
      void *pr = sprec->raw;
      int prlen = sprec->len;

      // Rehash with subseed and add to subhj's probe side.
      hval = komihash(&hj->subseed, sizeof(hj->subseed), sprec->hval);
      if (hj_probe(hj->subhj, hval, pr, prlen, matchfn)) {
        strcpy(hj->errmsg, hj->subhj->errmsg);
        return -1;
      }

      hj->stopped |= hj->subhj->stopped;
    }
    spf_close(hj->scan, /*truncate*/ 1, 0, 0);
    hj->scan = 0;
  }

  // Finish up the subhj
  CHECK(0 == hj_probe_spilled(hj->subhj, matchfn));
  hj->stopped |= hj->subhj->stopped;

  // Release the subhj asap
  hj_release(hj->subhj);
  hj->subhj = 0;

  return 0;
}

// Do hashjoin on each pair of build/probe files.
int hj_probe_spilled(hj_t *hj, hj_matchfn_t matchfn) {
  // Scan the current hashtable.
  // All tuples in the current hashtable that were not hit are misses.
  // For RIGHT/FULL outer join, invoke matchfn on them with build records from
  // hashtable and null probe (left) records.
  if (hj->type & HJ_RIGHT) {
    CHECK(0 == scan_for_missed_records(hj, matchfn));
  }

  // Done with the htab. Release to free up mem.
  chtab_destroy(hj->tab);
  arena_destroy(hj->arena);
  hj->tab = 0, hj->arena = 0;

  // If there are spill files ...
  if (hj->spbuild || hj->spprobe) {

    // No more writes to spill. Flush and close spill files.
    if (hj->spbuild) {
      CHECK(0 == spill_close(hj->spbuild, hj->errmsg, sizeof(hj->errmsg)));
    }
    if (hj->spprobe) {
      CHECK(0 == spill_close(hj->spprobe, hj->errmsg, sizeof(hj->errmsg)));
    }

    // Process each pair of spill files recursively.
    for (int bkt = 0; bkt < SPILL_NBUCKET && !hj->stopped; bkt++) {
      // Process the bucket. This will create a new subhj.
      CHECK(0 == process(hj, bkt, matchfn));
    }
  }

  return 0;
}

void hj_release(hj_t *hj) {
  if (hj) {
    if (hj->scan) {
      spf_close(hj->scan, 0, 0, 0);
    }
    chtab_destroy(hj->tab);
    arena_destroy(hj->arena);
    hj_release(hj->subhj);

    spill_destroy(hj->spbuild);
    spill_destroy(hj->spprobe);

    free((void *)hj->spdir);
    free(hj);
  }
}
