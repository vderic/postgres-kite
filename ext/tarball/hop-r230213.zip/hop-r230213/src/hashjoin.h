#ifndef HASHJOIN_H
#define HASHJOIN_H

#include <stdint.h>

typedef struct hj_t hj_t;

// Callback on hit/miss.
// br: build record
// pr: probe record
// br and pr are not const because they maybe modified (swizzled)
typedef int hj_matchfn_t(void *context, void *br, void *pr);

// Check if a build record and a probe record matches.
// br and pr are not const because they maybe modified (swizzled)
typedef int hj_cond_t(void *context, void *br, void *pr);

// Given a build/probe record, return the length of the record.
typedef int hj_reclen_t(void *context, const void *rec);

// Callback that will be invoked from time to time. Return true to stop
// processing.
typedef int hj_checkstop_t(void *context);

// Callback to prepare a rec for memcpy or disk write
typedef void hj_serialize_rec_t(void *context, const void *rec, void *dest,
                                int destsz);

typedef struct hj_dispatch_t hj_dispatch_t;
struct hj_dispatch_t {
  /* mandatory */
  hj_cond_t *cond;
  hj_reclen_t *reclen_build;
  hj_reclen_t *reclen_probe;
  /* optional */
  hj_serialize_rec_t *serialize_build; // default is memcpy
  hj_serialize_rec_t *serialize_probe;
  hj_checkstop_t *checkstop;
};

/*
 * IMPORTANT:
 *   LEFT is defined as PROBE side
 *   RIGHT is defined as BUILD side
 */
enum hj_type_t {
  HJ_INNER = 0,                 // matching pairs only
  HJ_LEFT = 1,                  // pairs + unmatched LHS tuples
  HJ_RIGHT = 2,                 // pairs + unmatched RHS tuples
  HJ_FULL = HJ_LEFT | HJ_RIGHT, // pairs + unmatched LHS + unmatched RHS
  HJ_IN = 8,
  HJ_NOT_IN = 16 | HJ_LEFT,
};
typedef enum hj_type_t hj_type_t;

/*
 * HJ_IN: select * from A where A.i in (select i from B);
 * Logical algorithm: build RIGHT side, but drop duplicates, i.e.  the
 * Hashtable shall contain unique entries only. Probe with LEFT
 * normally like INNER join. However, our cond function cannot
 * compare two build records; it can only compare a build and a probe
 * record.  Hence, we only drop duplicates when two build records are
 * bitwise equivalent. This means the htab MAY contain duplicates. To
 * achieve the same effect, on the probe side, we skip traversal of
 * the collison as soon as there is a match, ensuring that one probe
 * will never result in more than one matches.
 *
 * HJ_NOT_IN: select * from A where A.i not in (select i from B);
 * Complement of HJ_IN, EXCEPT: do not probe when the LEFT key has a
 * NULL. This is because any (NULL == NULL) or (NULL != NULL)
 * evaluates to NULL (not False), and the probe tuple can be skipped.
 */

/**
 * Start a hashjoin. Returns NULL if out-of-memory.
 * The intermittent param is optional and can be NULL.
 */
extern hj_t *hj_start(void *context, hj_type_t type, int64_t memlimit,
                      const char *spilldir, const hj_dispatch_t *dispatch);

/**
 * Insert a record into the build side of the join. The build record is
 * either copied into memory managed by hj, or spilled to disk.
 * If brlen < 0, invoke reclen_build() to obtain brlen.
 * Returns 0 on success, -1 otherwise.
 */
extern int hj_build(hj_t *hj, uint64_t hval, void *br, int brlen);

/**
 * Probe the hashtable. The probe record may be spilled to disk. For each match,
 * call matchfn.
 * If prlen < 0, invoke reclen_probe() to obtain prlen.
 * Returns 0 on success, -1 otherwise.
 */
extern int hj_probe(hj_t *hj, uint64_t hval, void *pr, int prlen,
                    hj_matchfn_t matchfn);

/**
 * Join the records in each pair of build/probe spill files. For each match,
 * call matchfn. Returns 0 on success, -1 otherwise.
 */
extern int hj_probe_spilled(hj_t *hj, hj_matchfn_t matchfn);

/**
 * Release resources.
 */
extern void hj_release(hj_t *hj);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hj_errmsg(hj_t *hj);

/**
 * Return #records fed to hj_build() so far.
 */
extern int64_t hj_nrec_in_build(hj_t *hj);

/**
 * Return #records fed to hj_probe() so far.
 */
extern int64_t hj_nrec_in_probe(hj_t *hj);

/**
 * Return #times the hash table has been probed.
 * hj_probe_count <= hj_nrec_fed_to_probe() because some
 * records may be spilled. However, at the end of the join,
 * hj_probe_count will be equal to hj_nrec_fed_to_probe.
 */
extern int64_t hj_probe_count(hj_t *hj);

#endif /* HASHJOIN_H */
