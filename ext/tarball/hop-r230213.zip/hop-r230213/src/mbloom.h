#ifndef MBLOOM_H
#define MBLOOM_H

#include <stdint.h>
#include <stdlib.h>

typedef struct mbloom_t mbloom_t;
struct mbloom_t {
  uint32_t nbyte; // size of map[]
  uint64_t mask;
  char map[0]; // map starts here
};

mbloom_t *mbloom_create(int nbits);

static inline void mbloom_destroy(mbloom_t *bp) { free(bp); }

static inline void mbloom_add(mbloom_t *bp, uint64_t hval) {
  uint64_t pos = (hval >> 13) & bp->mask;
  bp->map[pos / 8] |= (0x80 >> (pos % 8));
}

static inline int mbloom_check(mbloom_t *bp, uint64_t hval) {
  uint64_t pos = (hval >> 13) & bp->mask;
  return (bp->map[pos / 8] & (0x80 >> (pos % 8))) != 0;
}

#endif /* MBLOOM_H */
