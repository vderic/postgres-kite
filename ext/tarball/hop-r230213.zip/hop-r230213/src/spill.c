#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "spill.h"
#include "../src/komihash.h"
#include "mbloom.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

/*
static int local_random() {
  static uint64_t seed1 = 0;
  static uint64_t seed2 = 0;
  if (seed1 == 0) {
    seed1 = seed2 = getpid();
  }
  return komirand(&seed1, &seed2) & 0x7FFFFFFF;
}
*/

static uint32_t next_serial() {
  static _Atomic uint32_t serial_gen = 0;
  return ++serial_gen;
}

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

// Get a file name in the spill dir with a VERY low probability of
// name collision. File name "spill_{time}_{pid}_{serial}".
static char *rand_path(const char *dir) {
  char *path = 0;
  if (-1 == asprintf(&path, "%s/spill_%" PRIx64 "_%x_%x", dir, time(0),
                     getpid(), next_serial())) {
    return 0;
  }
  return path;
}

// Create a spill file and return the path
static char *create_file(const char *dir, char *errmsg, int errlen) {
  for (;;) {
    /* get a path name and try to create the file. If we failed because the file
     * already exists, retry! */
    char *path = rand_path(dir);
    if (!path) {
      perr("out of memory (%s)", FLINE);
      return 0;
    }

    int fd = open(path, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (fd < 0) {
      perr("open(%s): %s (%s)", path, strerror(errno), FLINE);
      free(path);
      if (errno == EEXIST) {
        // collision! this is VERY UNLIKELY.
        continue; // try again
      }
      return 0;
    }

    // success
    close(fd);
    return path;
  }
}

// For a value N, there are 2^N buckets, each with two
// spill files for build and probe.
typedef struct spill_bucket_t bucket_t;
struct spill_bucket_t {
  int id;     // range [0..NBUCKET)
  char *path; // path to file
  spf_t *spf; // spill file (NULL if closed)
  int64_t nbyte;
  int64_t nrow;
};

// Delete a bucket. Will drop the files.
static void bucket_drop(bucket_t *p) {
  if (p) {
    if (p->path) {
      unlink(p->path);
      free(p->path);
    }
    if (p->spf) {
      spf_close(p->spf, /*truncate*/ 1, 0, 0);
      p->spf = 0;
    }
    free(p);
  }
}

// Create a bucket
static bucket_t *bucket_new(int id, const char *dir, char *errmsg, int errlen) {
  bucket_t *p = calloc(1, sizeof(*p));
  if (!p) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }
  p->id = id;
  p->path = create_file(dir, errmsg, errlen);
  CHECKBAIL(p->path);
  p->spf = spf_open(p->path, errmsg, errlen);
  CHECKBAIL(p->spf);
  return p;

bail:
  if (p) {
    bucket_drop(p);
  }
  return 0;
}

// Close the spf file
static int bucket_close(bucket_t *p, char *errmsg, int errlen) {
  // Previously closed?
  if (!p->spf) {
    return 0;
  }

  // Close it
  int ret = spf_close(p->spf, /*truncate*/ 0, errmsg, errlen);
  p->spf = 0;
  return ret;
}

static void *bucket_emplace(bucket_t *p, uint64_t hval, int len, char *errmsg,
                            int errlen) {
  if (!p->spf) {
    perr("spill file is closed (%s)", FLINE);
    return 0;
  }

  return spf_emplace(p->spf, hval, len, errmsg, errlen);
}

// Create the spill
spill_t *spill_create(const char *dir, int use_bloom_filter, char *errmsg,
                      int errlen) {
  spill_t *sp = calloc(1, sizeof(spill_t));
  if (!sp) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  sp->dir = strdup(dir);
  if (!sp->dir) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  for (int i = 0; i < SPILL_NBUCKET; i++) {
    sp->bucket[i] = bucket_new(i, dir, errmsg, errlen);
    CHECKBAIL(sp->bucket[i]);
  }

  if (use_bloom_filter) {
    sp->bloom = mbloom_create(1024 * 1024 * 8); // 1MB
    if (!sp->bloom) {
      ; // ignore
    }
  }

  return sp;

bail:
  spill_destroy(sp);
  return 0;
}

// Cleanup and delete the spill
void spill_destroy(spill_t *sp) {
  if (sp) {
    for (int i = 0; i < SPILL_NBUCKET; i++) {
      bucket_drop(sp->bucket[i]);
    }
    mbloom_destroy(sp->bloom);
    free((void *)sp->dir);
    free(sp);
  }
}

// Add a record to the corresponding spill file
void *spill_emplace(spill_t *sp, uint64_t hval, int len, char *errmsg,
                    int errlen) {
  // which bucket?
  int id = hval % SPILL_NBUCKET;

  // add to bloom filter
  if (sp->bloom) {
    mbloom_add(sp->bloom, hval);
  }

  // find bucket[id]
  bucket_t *bucket = sp->bucket[id];
  void *p = bucket_emplace(bucket, hval, len, errmsg, errlen);
  if (!p) {
    return 0;
  }

  sp->nrow++;
  sp->nbyte += len; // this does not include spill_rec_t header
  return p;
}

// Flush all records in spill buffer
int spill_close(spill_t *sp, char *errmsg, int errlen) {
  for (int i = 0; i < SPILL_NBUCKET; i++) {
    bucket_close(sp->bucket[i], errmsg, errlen);
  }
  return 0;
}

const char *spill_path(spill_t *sp, int id) {
  if (!(0 <= id && id < SPILL_NBUCKET)) {
    return 0;
  }
  return sp->bucket[id]->path;
}
