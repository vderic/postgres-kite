#define _POSIX_C_SOURCE 200809L
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

#define MAGIC "SPILL001"

/*
static int readfully(int fd, void *buf, int len, char *errmsg, int errlen) {
  char *p = buf;
  char *q = buf + len;
  while (p < q) {
    int n = read(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s %s", strerror(errno), FLINE);
    }

    if (n == 0) {
      return perr("%s %s", "read beyond eof", FLINE);
    }

    p += n;
  }

  return 0;
}
*/

static int writefully(int fd, const void *buf, int len, char *errmsg,
                      int errlen) {
  const char *p = buf;
  const char *q = buf + len;
  while (p < q) {
    int n = write(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s (%s)", strerror(errno), FLINE);
    }

    if (n == 0) {
      return perr("%s (%s)", strerror(errno), FLINE);
    }

    p += n;
  }

  return 0;
}

struct spf_t {
  const char *path;
  int fd;
  int mode; // W for write, R for read.
  char *buf;
  int bot, top, max;
  int eof;
};

static int ensure_buf(spf_t *spf, int len, char *errmsg, int errlen) {
  int nb = spf->top - spf->bot;
  int avail = spf->max - nb;
  // fits?
  if (avail >= len) {
    if (spf->top + len >= spf->max && spf->bot) {
      // shift to make space
      memmove(spf->buf, spf->buf + spf->bot, nb);
      spf->bot = 0;
      spf->top = nb;
    }
    assert(spf->top + len <= spf->max);
    return 0;
  }

  // flush
  if (writefully(spf->fd, spf->buf + spf->bot, nb, errmsg, errlen)) {
    return -1;
  }
  spf->top = spf->bot = 0;

  // can it fit?
  nb = 0;
  avail = spf->max;
  if (avail >= len) {
    return 0;
  }

  // still can't fit
  int newmax = len + 100;
  char *newbuf = malloc(newmax);
  if (!newbuf) {
    perr("out of memory (%s)", FLINE);
    return -1;
  }
  free(spf->buf);
  spf->buf = newbuf;
  spf->max = newmax;
  return 0;
}

spf_t *spf_open(const char *path, char *errmsg, int errlen) {

  spf_t *spf = calloc(1, sizeof(*spf));
  if (!spf) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  spf->fd = open(path, O_APPEND | O_WRONLY, 0600);
  if (spf->fd <= 0) {
    perr("%s (%s)", strerror(errno), FLINE);
    goto bail;
  }

  spf->mode = 'W';
  spf->max = 16 * 1024;
  spf->buf = malloc(spf->max);
  spf->path = strdup(path);
  if (!(spf->buf && spf->path)) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  return spf;

bail:
  spf_close(spf, 1, errmsg, errlen);
  return 0;
}

static int flush(spf_t *spf, char *errmsg, int errlen) {
  if (spf->mode != 'W') {
    return 0;
  }
  int nb = spf->top - spf->bot;
  CHECK(0 == writefully(spf->fd, spf->buf + spf->bot, nb, errmsg, errlen));
  spf->bot = spf->top = 0;
  return 0;
}

int spf_close(spf_t *spf, int truncate_flag, char *errmsg, int errlen) {
  // This routine will not unlink the file. It either flushes buffers to the
  // file or truncate the file.
  assert(spf->mode == 'W' || spf->mode == 'R');
  int ret = 0;
  if (spf) {
    int fd = spf->fd;
    if (fd >= 0) {
      if (truncate_flag) {
        ret = ret ? ret : ftruncate(fd, 0);
      } else {
        ret = ret ? ret : flush(spf, errmsg, errlen);
      }
      close(fd);
    }
    free((void *)spf->path);
    free(spf->buf);
    free(spf);
  }
  return ret;
}

void *spf_emplace(spf_t *spf, uint64_t hval, int len, char *errmsg,
                  int errlen) {
  assert(spf->mode == 'W');
  spill_rec_t *rec = 0;
  int reclen = ALIGN8(sizeof(*rec) + len);
  if (reclen <= (int)sizeof(*rec)) {
    perr("invalid len %d (%s)", len, FLINE);
  }

  // Make sure buf[top..top+reclen] is available
  CHECKP(0 == ensure_buf(spf, reclen, errmsg, errlen));

  // Fill in the header
  rec = (spill_rec_t *)&spf->buf[spf->top];
  rec->magic = SPILL_REC_MAGIC;
  rec->len = len;
  rec->padding = reclen - (sizeof(*rec) + len);
  rec->hval = hval;

  // Consume the space
  spf->top += reclen;

  // Caller will copy into this addr
  return rec->raw;
}

spf_t *spf_scan(const char *path, char *errmsg, int errlen) {
  spf_t *spf = calloc(1, sizeof(*spf));
  if (!spf) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  spf->fd = open(path, O_RDONLY);
  if (spf->fd < 0) {
    perr("%s (%s)", strerror(errno), FLINE);
    goto bail;
  }
  spf->mode = 'R';
  spf->max = 32 * 1024;
  spf->buf = malloc(spf->max);
  spf->path = strdup(path);
  if (!(spf->buf && spf->path)) {
    perr("out of memory %s", FLINE);
    goto bail;
  }

  return spf;

bail:
  spf_close(spf, 0, errmsg, errlen);
  return 0;
}

static int read_more(spf_t *spf, char *errmsg, int errlen) {
  if (spf->eof) {
    return 0;
  }

  // shift buf[bot..top] to buf[0]
  if (spf->bot) {
    int inuse = spf->top - spf->bot;
    memmove(spf->buf, spf->buf + spf->bot, inuse);
    spf->bot = 0;
    spf->top = inuse;
  }

  // #byte of free buffer
  int avail = spf->max - spf->top;
  if (avail == 0) {
    // extend the buffer
    int newmax = spf->max * 1.5;
    if (newmax < 0) {
      return perr("spill_scan(%s): record is too big (%s)", spf->path, FLINE);
    }
    char *tmp = malloc(newmax);
    if (!tmp) {
      return perr("out of memory (%s)", FLINE);
    }
    memcpy(tmp, spf->buf, spf->top);
    free(spf->buf);
    spf->buf = tmp;
    spf->max = newmax;
    avail = spf->max - spf->top;
  }
  assert(avail > 0);

again:
  int n = read(spf->fd, spf->buf + spf->top, avail);
  if (n <= 0) {
    if (n == 0) {
      spf->eof = 1;
      return 0;
    }
    /* n < 0 */
    if (errno == EAGAIN || errno == EINTR) {
      goto again;
    }
    return perr("%s (%s)", strerror(errno), FLINE);
  }
  spf->top += n;
  return 0;
}

int spf_next(spf_t *spf, spill_rec_t **ret_rec, char *errmsg, int errlen) {
  assert(spf->mode == 'R');
  while (1) {
    int eof = spf->eof;

    // Number of valid bytes in buf[]
    int inuse = spf->top - spf->bot;
    if (inuse == 0 && spf->eof) {
      // signal EOF to caller
      *ret_rec = 0;
      return 0;
    }

    // If the full rec is in the buffer, return it.
    if (inuse > (int)sizeof(spill_rec_t)) {
      // Obtain the record size.
      spill_rec_t *sprec = (spill_rec_t *)&spf->buf[spf->bot];

      if (sprec->magic != SPILL_REC_MAGIC) {
        return perr("spf_next: bad magic number (%s)", FLINE);
      }

      int recsz = sprec->raw + sprec->len + sprec->padding - (char *)sprec;
      if (inuse >= recsz) {
        // Return the rec.
        *ret_rec = sprec;

        // Advance beyond this record.
        spf->bot += recsz;
        return 0;
      }
    }

    // Read more into buffer
    if (eof) {
      return perr("partial last record in spill file (%s)", FLINE);
    }
    CHECK(0 == read_more(spf, errmsg, errlen));
  }
}
