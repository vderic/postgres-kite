#ifndef SPILL_FILE_H
#define SPILL_FILE_H

#include <assert.h>
#include <stdint.h>

// A serialized record in the spill file
#define SPILL_REC_MAGIC 0x7391
typedef struct spill_rec_t spill_rec_t;
struct spill_rec_t {
  uint16_t magic;
  uint8_t padding;
  uint8_t unused;
  uint32_t len;
  uint64_t hval;
  char raw[0]; // len bytes
};

typedef struct spf_t spf_t;

spf_t *spf_open(const char *path, char *errmsg, int errlen);
int spf_close(spf_t *spf, int truncate_flag, char *errmsg, int errlen);
void *spf_emplace(spf_t *spf, uint64_t hval, int len, char *errmsg, int errlen);

spf_t *spf_scan(const char *path, char *errmsg, int errlen);
int spf_next(spf_t *spf, spill_rec_t **prec, char *errmsg, int errlen);

#endif /* SPILL_FILE_H */
