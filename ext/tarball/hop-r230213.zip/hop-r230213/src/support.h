#ifndef SUPPORT_H
#define SUPPORT_H

#include <string.h>

// clang-format off
#define CHECK(x)  if (x); else return -1
#define CHECKP(x) if (x); else return NULL
#define CHECKBAIL(x) if (x); else goto bail
// clang-format on

/* FLINE: returns a string repr (filename:lineno) */
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

static inline const char *fline(const char *s) {
  const char *p = strrchr(s, '/');
  return p ? p + 1 : s;
}

#define FLINE fline("(" __FILE__ ":" TOSTRING(__LINE__) ")")

#define ALIGN4(x) (((x) + 3) & ~3)
#define ALIGN8(x) (((x) + 7) & ~7)

#endif /* SUPPORT_H */
