/*

  1. the htab can contain 10 entries
  2. LEFT = create 100 rows of (X, X), where X range 1..100.
  3. RIGHT = create 300*4 rows of (X, Y), where X range 1..300, Y = -X.

     note: RIGHT has 4 sets of 1..300, Each set has 100 match with LEFT,
           So, expect 400 hits when joining LEFT and RIGHT.

  4. for row in LEFT: add to build side.
  5. for row in RIGHT: add to probe side.
  6. probe_spilled.
  7. done!

 */
#include "../src/hashjoin.h"
#include "harness.h"

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the left side of the join
typedef struct left_t left_t;
struct left_t {
  int key;
  int value;
  int side;
};
static int is_left(const left_t *tp) { return tp->side == 'L'; }

// Tuples from the right side of the join
typedef struct right_t right_t;
struct right_t {
  int key;
  int value;
  int side;
  int dummy; // to make sizeof(right_t) != sizeof(left_t)
};
static int is_right(const right_t *tp) { return tp->side == 'R'; }

// Get the next left tuple.
// Key range [1..100]
static int get_left(left_t *tp) {
  // left table has tuples with keys from 1..100
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  tp->side = 'L';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple.
// Key range [1..300]
static int get_right(right_t *tp) {
  // right table has tuples with keys from 1..300
  static int serial = 0;
  if (serial >= 1200) {
    return -1;
  }
  memset(tp, 0, sizeof(*tp));
  tp->side = 'R';
  tp->key = 1 + serial % 300;
  tp->value = -serial;

  serial++;
  return 0;
}

int count_hit = 0;
int count_miss = 0;

static int match(void *context, void *br, void *pr) {
  (void)context;
  const left_t *LP = (left_t *)br;
  const right_t *RP = (right_t *)pr;
  CHECK(!LP || is_left(LP));
  CHECK(!RP || is_right(RP));

  if (!LP) {
    printf("miss (%c %d %d)\n", RP->side, RP->key, RP->value);
    count_miss++;
  } else if (!RP) {
    printf("miss (%c %d %d)\n", LP->side, LP->key, LP->value);
    count_miss++;
  } else {
    printf("hit (%c %d %d) (%c %d %d)\n", LP->side, LP->key, LP->value,
           RP->side, RP->key, RP->value);
    count_hit++;
  }
  return 0;
}

static int keyeq(void *context, void *br, void *pr) {
  (void)context;
  const left_t *LP = br;
  const right_t *RP = pr;
  CHECK(is_left(LP));
  CHECK(is_right(RP));
  return LP->key == RP->key;
}

static int reclen(void *context, const void *rec) {
  (void)context;
  const left_t *LP = rec;
  if (is_left(LP)) {
    return sizeof(*LP);
  }
  const right_t *RP = rec;
  if (is_right(RP)) {
    return sizeof(*RP);
  }
  CHECK(0);
  return -1;
}

hj_t *hj = 0;

// Scan left side and feed to hj
static void build() {

  // For each tuple from LEFT side
  for (;;) {
    left_t tup;
    if (get_left(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    CHECK(0 == hj_build(hj, hval, &tup, -1));
  }
}

static void probe() {

  // For each tuple from RIGHT side
  for (;;) {
    right_t tup;
    if (get_right(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    CHECK(0 == hj_probe(hj, hval, &tup, -1, match));
  }

  CHECK(0 == hj_probe_spilled(hj, match));
}

int main() {
  char *context = 0;
  hj_dispatch_t dispatch = {0};
  dispatch.reclen_build = reclen;
  dispatch.reclen_probe = reclen;
  dispatch.cond = keyeq;

  hj = hj_start(context, HJ_FULL, 200, ".", &dispatch);
  CHECK(hj);

  {
    build();
    probe();
  }

  printf("\n");
  printf("#hit = %d\n", count_hit);
  printf("#miss = %d\n", count_miss);

  CHECK(count_hit == 400);
  CHECK(count_miss == 800);

  hj_release(hj);

  return 0;
}
