#include "hjpub.hpp"

int main() {
  /*
    -- INNER JOIN
    SELECT b.id, b.title, a.first_name, a.last_name
    FROM books b
    INNER JOIN authors a
    ON b.author_id = a.id
    ORDER BY b.id;
  */
  const std::vector<std::string> expected = {
      "1 | Time to Grow Up! | Ellen Writer",
      "2 | Your Trip | Yao Dou",
      "3 | Lovely Love | Donald Brain",
      "4 | Dream Your Life | Ellen Writer",
      "5 | Oranges | Olga Savelieva",
      "6 | Your Happy Life | Yao Dou",
      "7 | Applied AI | Jack Smart",
      "8 | My Last Book | Ellen Writer",
  };
  std::vector<std::string> result;

  auto keyeq = [](void *context, void *br, void *pr) -> int {
    // author[AUTHOR_ID] == book[BOOK_AUTHOR_ID]
    (void)context;
    const char *author = (const char *)br;
    const char *book = (const char *)pr;
    return std::string{field(author, AUTHOR_ID)} ==
           std::string{field(book, BOOK_AUTHOR_ID)};
  };
  auto match = [](void *context, void *br, void *pr) -> int {
    (void)context;
    const char *author = (const char *)br;
    const char *book = (const char *)pr;
    std::string line;
    line.append(field(book, BOOK_ID));
    line.append(" | ");
    line.append(field(book, BOOK_TITLE));
    line.append(" | ");
    line.append(field(author, AUTHOR_NAME));
    std::vector<std::string> *result = (std::vector<std::string> *)context;
    result->push_back(line);
    return 0;
  };

  hj_dispatch_t dispatch;
  memset(&dispatch, 0, sizeof(dispatch));
  dispatch.reclen_build = reclen;
  dispatch.reclen_probe = reclen;
  dispatch.cond = keyeq;
  hj_t *hj = hj_start(&result, HJ_INNER, 100, ".", &dispatch);

  for (const char *rec : AUTHOR) {
    if (auto hkey = field(rec, AUTHOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      CHECK(0 == hj_build(hj, hval, (char *)rec, -1));
    }
  }
  for (const char *rec : BOOK) {
    if (auto hkey = field(rec, BOOK_AUTHOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      CHECK(0 == hj_probe(hj, hval, (char *)rec, -1, match));
    }
  }
  CHECK(0 == hj_probe_spilled(hj, match));

  std::sort(result.begin(), result.end());
  print(result);
  CHECK(result == expected);
  hj_release(hj);

  return 0;
}
