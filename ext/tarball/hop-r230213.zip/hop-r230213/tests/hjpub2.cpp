#include "hjpub.hpp"

int main() {
  /*
    -- INNER JOIN
    SELECT b.id, b.title, b.type, t.last_name AS translator
    FROM books b
    JOIN translators t
    ON b.translator_id = t.id
    ORDER BY b.id;
  */
  const std::vector<std::string> expected = {
      "2 | Your Trip | translated | Ling Weng",
      "5 | Oranges | translated | Ira Davies",
      "6 | Your Happy Life | translated | Kristian Green",
      "7 | Applied AI | translated | Roman Edwards",
  };
  std::vector<std::string> result;

  auto keyeq = [](void *context, void *br, void *pr) -> int {
    // translator[TRANSLATOR_ID] == book[BOOK_TRANSLATOR_ID]
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    return std::string{field(trans, TRANSLATOR_ID)} ==
           std::string{field(book, BOOK_TRANSLATOR_ID)};
  };
  auto match = [](void *context, void *br, void *pr) -> int {
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    std::string line;
    line.append(field(book, BOOK_ID));
    line.append(" | ");
    line.append(field(book, BOOK_TITLE));
    line.append(" | ");
    line.append(field(book, BOOK_TYPE));
    line.append(" | ");
    line.append(field(trans, TRANSLATOR_NAME));
    std::vector<std::string> *result = (std::vector<std::string> *)context;
    result->push_back(line);
    return 0;
  };

  hj_dispatch_t dispatch;
  memset(&dispatch, 0, sizeof(dispatch));
  dispatch.reclen_build = reclen;
  dispatch.reclen_probe = reclen;
  dispatch.cond = keyeq;
  hj_t *hj = hj_start(&result, HJ_INNER, 100, ".", &dispatch);
  for (const char *rec : TRANSLATOR) {
    if (auto hkey = field(rec, TRANSLATOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      CHECK(0 == hj_build(hj, hval, (char *)rec, -1));
    }
  }
  for (const char *rec : BOOK) {
    if (auto hkey = field(rec, BOOK_TRANSLATOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      CHECK(0 == hj_probe(hj, hval, (char *)rec, -1, match));
    }
  }
  CHECK(0 == hj_probe_spilled(hj, match));

  std::sort(result.begin(), result.end());
  print(result);

  CHECK(result == expected);
  hj_release(hj);
  return 0;
}
