# Sort

## SortedRun (srun)

  1. input: N records.
  2. sort the records
  3. write to a new file
  4. return the file name

## SortBucket (sbucket)

  1. input: M runs

  2. if M == 1:
     - return the name of the run.

  3. if M <= 7:
     - start a PQ on the M runs.
     - merge into 1 result run.
     - delete the M runs.
     - return the name of the result run.

  4. otherwise:
     - start 7 new buckets and assign M runs among them.
     - each bucket shall produce 1 run.
     - now we have <= 7 runs. goto 3.


## ExtSort

### ExtSort.feed:

  1. start with a memlimit sort-buffer.

  2. Insert each build record into the sort-buffer as long as it fits.

  3. On first overflow, sort the buffer and write to a new
     sorted-run.

  4. Assign the sorted-run to one of 7 Sort Bucket.

  5. Reset the sort-buffer, and goto 2.

### ExtSort.emit:

  1. sort the sort-buffer
  
  2. if there is 0 sorted-runs:
     - emit sorted records in the buffer.
     - free the sort-buffer.
     - Done!

  2. if there is a PQ:
     - pop records from PQ and emit them
     - Done!

  3. write recs in sort buffer to a new sorted-run.
     - this is the final sorted run.
     - assign the sorted run to a bucket.

  4. free the sort-buffer.

  5. Get runs from the 7 buckets and start PQ. Goto 2.
