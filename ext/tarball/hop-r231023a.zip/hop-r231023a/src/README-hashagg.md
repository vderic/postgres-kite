# HashAgg

# Build

A hashagg keeps an in-memory hashtable. The hash table contains
(feed-rec, agg-rec), where key is feed-rec and value is agg-rec. For a
fresh feed-rec that is not in the hashtable, we obtain the agg-rec by
calling initfn (step 1). Once we have the initial agg-rec, we call
transfn(feed-rec, agg-rec) to obtain a new aggrec after transformation
(step 2). For a feed-rec that is already in the hashtable, we just do
step 2 directly.

When memory used exceeds memlimit, new build records fed to the
hashagg is processed as follows:

  - check if the record is a duplicate of another one in the hash table.

  - If so, invoke the transfn using the record in the hashtable and
    update the agg-rec for the hashtable entry.

  - Otherwise, spill the build record into one of 8 spill files using hval.

# Finalize

First step of finalize is to iterate the hashtable and call emitfn on
each (feed-rec, agg-rec) in the hashtable. Release all memory used by
the hashtable.

If there are no spills, we are done!

Otherwise:

   - for each spill file, start a sub-hashagg.

   - for each feed-record in the spill file, rehash the record with
     salt, and feed it to the sub-hashagg.

   - call finalize on the sub-hashagg.


