#include "arena.h"
#include "support.h"
#include <assert.h>
#include <stdlib.h>

#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

#define BLOCKSZ (1024 * 8)
typedef struct block_t block_t;
struct block_t {
  block_t *next;
  int32_t top;
  int32_t dummy;
  char data[BLOCKSZ - 16];
};

typedef struct chunk_t chunk_t;
struct chunk_t {
  chunk_t *next;
  char data[0];
};

#define THRESHOLD (BLOCKSZ / 4)

typedef struct Arena_t Arena_t;
struct Arena_t {
  int64_t nbyte; // #bytes explicitly allocated by caller (must be first item in
                 // struct to overlap with arena_t)
  block_t *block; /* for strings smaller than THRESHOLD */
  chunk_t *chunk; /* for strings larger than THRESHOLD */
};

arena_t *arena_create() {
  Arena_t *p = calloc(1, sizeof(*p));
  return (arena_t *)p;
}

void arena_destroy(arena_t *arena) {
  Arena_t *ap = (Arena_t *)arena;
  if (arena) {
    // free all chunks and all blocks (except the first)
    arena_reset(arena);

    // the first block may be saved by arena_reset()...
    if (ap->block) {
      assert(ap->block->next == 0);
      free(ap->block);
    }

    // done with arena
    free(arena);
  }
}

void arena_reset(arena_t *arena) {
  Arena_t *ap = (Arena_t *)arena;

  // free all chunks
  for (chunk_t *chk = ap->chunk; chk;) {
    chunk_t *next = chk->next;
    free(chk);
    chk = next;
  }

  // free every block except the first
  block_t *first = ap->block;
  if (first) {
    block_t *curr = first->next;
    first->next = 0;
    while (curr) {
      block_t *next = curr->next;
      free(curr);
      curr = next;
    }
  }

  // full reset
  memset(ap, 0, sizeof(*ap));

  // reuse the first block
  ap->block = first;
}

void *arena_alloc(arena_t *arena, int nb) {
  if (nb < 0) {
    // bad param
    assert(0);
    return 0;
  }
  if (nb == 0) {
    // alloc(0) is valid. Make it allocate 4 bytes.
    nb = 4;
  }

  Arena_t *ap = (Arena_t *)arena;
  nb = ALIGN8(nb);

  if (nb <= THRESHOLD) {
    // small object. allocate in block.
    block_t *blk = ap->block;
    int avail = blk ? sizeof(blk->data) - blk->top : 0;
    if (avail < nb) {
      // cannot fit! make a new block.
      blk = malloc(sizeof(*blk));
      EXPECTX(blk, return NULL);

      blk->top = 0;
      blk->next = ap->block;
      ap->block = blk;

      avail = sizeof(blk->data);
      assert(avail >= nb);
    }

    // advance the end marker
    blk->top += nb;

    // allocated nb bytes
    ap->nbyte += nb;

    // return pointer to allocated mem
    return blk->data + blk->top - nb;
  }

  // big object. allocate in chunk list.
  chunk_t *chk = malloc(sizeof(chunk_t) + nb);
  EXPECTX(chk, return NULL);

  chk->next = ap->chunk;
  ap->chunk = chk;

  // return pointer to allocated mem
  ap->nbyte += sizeof(chunk_t) + nb;
  return chk->data;
}
