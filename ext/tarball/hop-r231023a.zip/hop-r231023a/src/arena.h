#ifndef HOP_ARENA_H
#define HOP_ARENA_H

#include <stdint.h>
#include <string.h>

typedef struct arena_t arena_t;
struct arena_t {
  int64_t nbyte;
};

arena_t *arena_create();
void arena_destroy(arena_t *arena);
void arena_reset(arena_t *arena);
void *arena_alloc(arena_t *arena, int nb);

static inline void *arena_dup(arena_t *arena, const void *s, int slen) {
  void *p = arena_alloc(arena, slen);
  if (p) {
    memcpy(p, s, slen);
  }
  return p;
}

static inline int64_t arena_size(arena_t *arena) { return arena->nbyte; }

#endif /* HOP_ARENA_H */
