#ifndef HOP_CHTAB_H
#define HOP_CHTAB_H

#include <stdint.h>

typedef struct chtab_t chtab_t;

/**
 *  This hashtable maps hval to a pointer.
 */

/**
 *  Returns a new htab or NULL if out of memory
 */
extern chtab_t *chtab_create();

/**
 *  Destroy a htab.
 */
extern void chtab_destroy(chtab_t *tab);

/**
 *  Empty out the htab.
 */
extern void chtab_reset(chtab_t *tab);

/**
 *  Return a memory location that caller can store a value (a pointer)
 *  associated with hval. If hval already exists, it returns a memory
 *  location which stores the current associated value. Otherwise, the
 *  memory location returned will store 0.
 *
 *  Returns NULL if out of memory.
 */
extern void **chtab_emplace(chtab_t *tab, uint64_t hval);

/**
 *  Emplace a new entry without searching first because chtab_find
 *  was done and we know for sure that hval does not exist in tab. This
 *  runs faster than chtab_emplace().
 */
extern void **chtab_emplace_ex(chtab_t *tab, uint64_t hval);

/**
 *  Find. Returns NULL if not found.
 */
extern void **chtab_find(const chtab_t *tab, uint64_t hval);

/**
 *  Return the first valid index, or -1 if table is empty.
 */
extern int chtab_first(const chtab_t *tab, uint64_t *hval, void **value);

/**
 *  Return the next valid index, or -1 on failure.
 */
extern int chtab_next(const chtab_t *tab, int idx, uint64_t *hval,
                      void **value);

#endif /* HOP_CHTAB_H */
