#define _XOPEN_SOURCE 500
#include "extsort.h"
#include "arena.h"
#include "rfile.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

// Function to perform the insertion sort on arr[low..n]
static void insertion_sort(char *arr[], int low, int n,
                           extsort_keycmpfn_t *keycmpfn, void *context) {

  for (int i = low + 1; i <= n; i++) {
    char *val = arr[i];
    int j = i;
    // move items bigger than val up by 1 slot
    while (j > low && keycmpfn(context, arr[j - 1], val) > 0) {
      arr[j] = arr[j - 1];
      j--;
    }
    arr[j] = val;
  }
}

// Partition function for quicksort
static int partition(char *arr[], int low, int high,
                     extsort_keycmpfn_t *keycmpfn, void *context) {
  char *pivot = arr[high];
  // j is the final pos of pivot:
  // ==> everything below j is smaller than pivot.
  int j = low;

  for (int i = low; i < high; i++) {
    // arr[i] < pivot?
    if (keycmpfn(context, arr[i], pivot) < 0) {
      char *temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
      j++;
    }
  }

  char *temp = arr[j];
  arr[j] = arr[high];
  arr[high] = temp;

  return j;
}

// Hybrid function -> Quick + Insertion sort
// Sort arr[low..high].  NOTE: high index is inclusive.
static void hybrid_quick_sort(char *arr[], int low, int high,
                              extsort_keycmpfn_t *keycmpfn, void *context) {
#define THRESHOLD 10
  while (low < high) {

    // If sizeof([low..high]) < THRESHOLD: use insertion sort, stop recursion.
    if (high - low + 1 < THRESHOLD) {
      insertion_sort(arr, low, high, keycmpfn, context);
      return;
    }

    // do quicksort.

    int pivot = partition(arr, low, high, keycmpfn, context);

    // Optimised quicksort which use recursion on the smaller array,
    // and iterate on the larger array.

    // If the left side is smaller than the right, sort left part
    // recursively, and continue with the right part of the array.
    if (pivot - low < high - pivot) {
      hybrid_quick_sort(arr, low, pivot - 1, keycmpfn, context);
      low = pivot + 1;
    } else {
      // Else the right side is smaller than left, sort right side
      // recursively, and continue with the left side.
      hybrid_quick_sort(arr, pivot + 1, high, keycmpfn, context);
      high = pivot - 1;
    }
  }
}

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(srt, fmt, ...)                                                    \
  reterr(snprintf((srt)->errmsg, sizeof((srt)->errmsg), fmt, ##__VA_ARGS__))

#define NBUCKET 7

// Sort buckets. Multiple sort runs can be added to a sort bucket.
// The sort bucket will merge the runs and return 1 run.
typedef struct sbucket_t sbucket_t;
typedef struct rfile_registry_t rfile_registry_t;

static sbucket_t *sbucket_create(extsort_t *srt);
/* Add a run file to a bucket. The file is now considered owned by the bucket.
 */
static int sbucket_add(sbucket_t *bkt, int id);

/* Merge the run files in the bucket. The result is another run file. */
static int sbucket_merge(sbucket_t *bkt);

/* Return id of the result sorted run file, or -1 on error.
 * Once the result is returned, the result run file is owned
 * by the caller.
 */
static int sbucket_result(sbucket_t *bkt);

/* Release resources. All run files in the will be deleted.
 * If sbucket_result() was not called, the result run file will
 * also be deleted.
 */
static void sbucket_destroy(sbucket_t *bkt);

struct extsort_t {
  rfile_registry_t *registry;  /* registry of paths */
  void *context;               /* pass to callbacks */
  int64_t memlimit;            /* #bytes for sort buffer */
  extsort_dispatch_t dispatch; // callback functions
  int64_t nrec;                // #records fed to us

  // records and their reclens fed to us
  arena_t *arena;
  ptrvec_t recvec; // points into arena
  intvec_t lenvec;

  // priority queue on runs
  rfilepq_t pq;

  sbucket_t *bucket[NBUCKET];
  int nextbucket; // next run goes into this bucket

  rfile_t *run; // current active sortedrun scan

  char errmsg[200];
};

static void reset_buffer(extsort_t *srt) {
  arena_reset(srt->arena);
  ptrvec_reset(&srt->recvec);
  intvec_reset(&srt->lenvec);
}

// Sort srt->ptrvec[]
static inline int sort_ptrvec(extsort_t *srt) {
  char **pp = srt->recvec.pptr;
  int n = srt->recvec.top;
  extsort_keycmpfn_t *keycmpfn = srt->dispatch.keycmpfn;

  hybrid_quick_sort(pp, 0, n - 1, keycmpfn, srt->context);

  return 0;
}

const char *extsort_errmsg(extsort_t *srt) { return srt->errmsg; }

static void default_serializefn(void *context, const void *rec, void *dest,
                                int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

// Create a new extsort.
extsort_t *extsort_open(void *context, int64_t memlimit, const char *spilldir,
                        extsort_dispatch_t dispatch) {
  assert(dispatch.keycmpfn);

  extsort_t *srt = calloc(1, sizeof(*srt));
  EXPECTX(srt, goto bail);

  srt->registry = rfile_registry_create(spilldir);
  EXPECTX(srt->registry, goto bail);

  srt->arena = arena_create();
  EXPECTX(srt->arena, goto bail);

  srt->context = context;
  srt->memlimit = memlimit;

  srt->dispatch = dispatch;
  if (!srt->dispatch.serializefn) {
    srt->dispatch.serializefn = default_serializefn;
  }

  rfilepq_init(&srt->pq, srt->registry, srt->context, srt->dispatch.keycmpfn);

  return srt;

bail:
  extsort_close(srt);
  return 0;
}

void extsort_close(extsort_t *srt) {
  if (!srt) {
    return;
  }

  // Close any sorted run in use.
  if (srt->run) {
    (void)rfile_close(srt->run, 1, 0, 0);
    srt->run = 0;
  }
  rfilepq_close(&srt->pq);

  // Free all buckets.
  for (int i = 0; i < NBUCKET; i++) {
    sbucket_destroy(srt->bucket[i]);
  }

  rfile_registry_destroy(srt->registry);

  // Free the ptrvec
  free(srt->recvec.pptr);
  free(srt->lenvec.arr);

  //
  arena_destroy(srt->arena);

  // Free the srt handle
  free(srt);
}

// Flush the buffer in srt that contains unsorted records to a sorted run.
static int flush(extsort_t *srt) {
  char *errmsg = srt->errmsg;
  int errlen = sizeof(srt->errmsg);
  int N = srt->recvec.top;

  // cardinality of lenvec and recvec must be in sync.
  assert(srt->lenvec.top == N);

  assert(N != 0);
  if (N == 0) {
    // nothing to flush
    return 0;
  }

  // sort ptrvec.
  EXPECT(0 == sort_ptrvec(srt));

  // create a new run
  srt->run = rfile_create(srt->registry, errmsg, errlen);
  EXPECT(srt->run);

  sbucket_t **bkt = &srt->bucket[srt->nextbucket % NBUCKET];
  srt->nextbucket++;
  if (!*bkt) {
    // bucket does not exist yet ... create it.
    *bkt = sbucket_create(srt);
    EXPECT(*bkt);
  }

  // assign to a bucket
  EXPECT(0 == sbucket_add(*bkt, rfile_id(srt->run)));

  // write each record to the new sorted run
  {
    for (int i = 0; i < N; i++) {
      char *rec = srt->recvec.pptr[i];
      int len = srt->lenvec.arr[i];
      char *dest = rfile_emplace(srt->run, len, 0, errmsg, errlen);
      EXPECT(dest);

      // note: must use serialize() because rec is swizzled by keycmp
      srt->dispatch.serializefn(srt->context, rec, dest, len);
    }
  }

  // close the run.
  EXPECT(0 == rfile_close(srt->run, 0, errmsg, errlen));
  srt->run = 0;

  // empty out record buffer
  reset_buffer(srt);

  return 0;
}

int extsort_feed(extsort_t *srt, void *rec, int len) {

  srt->nrec++;

  // copy rec into buffer
  char *p = arena_dup(srt->arena, rec, len);
  if (!p) {
    return perr(srt, "extsort_feed: out of memory (%s)", FLINE);
  }
  if (ptrvec_add(&srt->recvec, p)) {
    return perr(srt, "extsort_feed: out of memory (%s)", FLINE);
  }
  if (intvec_add(&srt->lenvec, len)) {
    return perr(srt, "extsort_feed: out of memory (%s)", FLINE);
  }

  if (arena_size(srt->arena) > srt->memlimit) {
    EXPECT(0 == flush(srt));
  }

  return 0;
}

/**
 * Finalize the sort. The emitfn will be invoked for each sorted record.
 * Returns 0 on success, -1 otherwise.
 */
int extsort_emit(extsort_t *srt, extsort_emitfn_t *emitfn) {
  // simple case: there is 0 sorted-runs?
  if (srt->nextbucket == 0) {
    // sort our buffer
    EXPECT(0 == sort_ptrvec(srt));

    // call emitfn on each record
    char **pp = srt->recvec.pptr;
    int n = srt->recvec.top;
    for (int i = 0; i < n; i++) {
      int rc = emitfn(srt->context, pp[i]);
      /* 1 to continue, 0 to stop, -1 on error */
      if (rc <= 0) {
        return rc < 0 ? perr(srt, "emitfn failed (%s)", FLINE) : 0;
      }
    }
    // sort is DONE!
    // Early free big buffer.
    reset_buffer(srt);
    return 0;
  }

  // write the final sorted-run
  EXPECT(0 == flush(srt));

  // Early free big buffer.
  reset_buffer(srt);

again:
  // if there is a PQ: pop, emit and done.
  if (srt->pq.nitem) {
    rfilepq_t *pq = &srt->pq;

    // Loop until pq is empty
    while (1) {
      void *rec;
      int len;
      EXPECT(0 ==
             rfilepq_pop(pq, &rec, &len, srt->errmsg, sizeof(srt->errmsg)));
      if (rec == 0) {
        break; // EOF
      }
      int rc = emitfn(srt->context, rec);
      /* 1 to continue, 0 to stop, -1 on error */
      if (rc <= 0) {
        return rc < 0 ? perr(srt, "emitfn failed (%s)", FLINE) : 0;
      }
    }
    // sort is DONE!
    return 0;
  }

  // --- need to merge buckets and create a PQ

  // The Merge Loop
  // merge the runs in each bucket
  for (int i = 0; i < NBUCKET; i++) {
    if (srt->bucket[i]) {
      EXPECT(0 == sbucket_merge(srt->bucket[i]));
      // printf("\nBucket %d done\n\n", i);
    }
  }

  assert(srt->run == 0);

  // Start pq on results in buckets. Do this in a separate loop from
  // the Merge Loop above so that we don't open too many files at the
  // same time.
  for (int i = 0; i < NBUCKET; i++) {
    if (!srt->bucket[i]) {
      continue;
    }

    int id = sbucket_result(srt->bucket[i]);
    assert(id);
    assert(rfile_registry_get(srt->registry, id));
    EXPECT(0 == rfilepq_push(&srt->pq, id, srt->errmsg, sizeof(srt->errmsg)));

    assert(srt->run == 0);
  }

  goto again;
}

/* Sort Bucket */
struct sbucket_t {
  extsort_t *srt;
  int result; // ID of result sorted run

  intvec_t rfile_id;

  // priority queue on runs
  rfilepq_t pq;

  sbucket_t *bucket[NBUCKET];
  int nextbucket; // next run goes into this bucket

  rfile_t *run; // current active run
};

static int sbucket_result(sbucket_t *bkt) {
  int ret = bkt->result;
  bkt->result = 0;
  return ret;
}

static sbucket_t *sbucket_create(extsort_t *srt) {
  sbucket_t *bkt = calloc(1, sizeof(*bkt));
  if (!bkt) {
    perr(srt, "out of memory (%s)", FLINE);
    return NULL;
  }
  bkt->srt = srt;

  return bkt;
}

static void sbucket_destroy(sbucket_t *bkt) {
  if (!bkt) {
    return;
  }

  // Close any sorted run in use.
  if (bkt->run) {
    (void)rfile_close(bkt->run, 1, 0, 0);
    bkt->run = 0;
  }
  rfilepq_close(&bkt->pq);

  // Free all buckets.
  for (int i = 0; i < NBUCKET; i++) {
    sbucket_destroy(bkt->bucket[i]);
  }

  // dispose all runs
  for (int i = 0; i < bkt->rfile_id.top; i++) {
    rfile_registry_forget(bkt->srt->registry, bkt->rfile_id.arr[i]);
  }

  rfile_registry_forget(bkt->srt->registry, bkt->result);

  free(bkt->rfile_id.arr);
  free(bkt);
}

static int sbucket_add(sbucket_t *bkt, int rfile_id) {
  if (intvec_add(&bkt->rfile_id, rfile_id)) {
    return perr(bkt->srt, "out of memory (%s)", FLINE);
  }
  return 0;
}

/* ------------------------------------------------------------

  1. input: M runs

  2. if M == 1:
     - return the name of the run.

  3. if M <= 7:
     - start a PQ on the M runs.
     - merge into 1 result run.
     - delete the M runs.
     - return the name of the result run.

  4. otherwise:
     - start 7 new buckets and assign M runs among them.
     - each bucket shall produce 1 run.
     - now we have <= 7 runs. goto 3.

 */
static int sbucket_merge(sbucket_t *bkt) {
  // merge runs in bkt->path[] into bkt->result

  int nrun = bkt->rfile_id.top;
  int *runid = bkt->rfile_id.arr;
  extsort_t *srt = bkt->srt;
  char *errmsg = srt->errmsg;
  int errlen = sizeof(srt->errmsg);

  // there are no runs?
  if (nrun <= 0) {
    return perr(bkt->srt, "internal error (%s)", FLINE);
  }

  // result exists?
  if (bkt->result) {
    return perr(bkt->srt, "internal error (%s)", FLINE);
  }

  // only 1 run: easy... it is the result.
  if (nrun == 1) {
    bkt->result = runid[0];
    return 0;
  }

again:
  // if <= 7 run: start pq and merge
  if (nrun <= 7) {
    // printf("\n... merging %d runs\n\n", nrun);

    rfilepq_init(&bkt->pq, srt->registry, srt->context, srt->dispatch.keycmpfn);

    for (int i = 0; i < nrun; i++) {
      EXPECT(0 == rfilepq_push(&bkt->pq, runid[i], errmsg, errlen));
    }

    // create result run
    bkt->run = rfile_create(srt->registry, errmsg, errlen);
    EXPECT(bkt->run);

    // pop from pq and write to result run
    for (;;) {
      void *rec;
      int len;
      EXPECT(0 == rfilepq_pop(&bkt->pq, &rec, &len, errmsg, errlen));
      // EOF?
      if (rec == 0) {
        break;
      }
      char *dest = rfile_emplace(bkt->run, len, 0, errmsg, errlen);
      EXPECT(dest);

      // note: must use serialize() because pp[i] is swizzled by keycmp
      srt->dispatch.serializefn(srt->context, rec, dest, len);
    }

    // save the result path
    bkt->result = rfile_id(bkt->run);
    // printf("\n... result %d\n", bkt->result);

    // flush and close the result run
    EXPECT(0 == rfile_close(bkt->run, 0, errmsg, errlen));

    // closed!
    bkt->run = 0;
    return 0;
  }

  // > 7 runs: start sub-buckets and assign the runs among them
  for (int i = 0; i < nrun; i++) {
    sbucket_t **pp = &bkt->bucket[bkt->nextbucket % NBUCKET];
    bkt->nextbucket++;

    // create bucket if not exists
    if (!*pp) {
      *pp = sbucket_create(srt);
      EXPECT(*pp);
    }
    // add to bucket
    EXPECT(0 == sbucket_add(*pp, runid[i]));
  }

  // merge the runs in each bucket. save the result in runid[]
  nrun = 0;
  for (int i = 0; i < NBUCKET; i++) {
    if (bkt->bucket[i]) {
      EXPECT(0 == sbucket_merge(bkt->bucket[i]));

      runid[nrun++] = sbucket_result(bkt->bucket[i]);

      sbucket_destroy(bkt->bucket[i]);
      bkt->bucket[i] = 0;
    }
  }

  goto again;
}
