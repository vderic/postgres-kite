#ifndef HOP_EXTSORT_H
#define HOP_EXTSORT_H

#include <stdint.h>

// An external sort operation.
typedef struct extsort_t extsort_t;

// Compare rec1 and rec2. Return 1, 0 or -1.
typedef int extsort_keycmpfn_t(void *context, void *rec1, void *rec2);

// Serialize rec to dest.
typedef void extsort_serializefn_t(void *context, const void *rec, void *dest,
                                   int destsz);

// Emit result. The sort has been completed. Return 1 to continue, 0 to stop, or
// -1 on failure.
typedef int extsort_emitfn_t(void *context, void *rec);

// Callback functions.
typedef struct extsort_dispatch_t extsort_dispatch_t;
struct extsort_dispatch_t {
  extsort_keycmpfn_t *keycmpfn;
  /* optinal */
  extsort_serializefn_t *serializefn;
};

/**
 *  Begin a sort.
 */
extern extsort_t *extsort_open(void *context, int64_t memlimit,
                               const char *spilldir,
                               extsort_dispatch_t dispatch);

/**
 *  Feed a record to the sort.
 */
extern int extsort_feed(extsort_t *srt, void *rec, int len);

/**
 * Finalize the sort. The emitfn will be invoked for each sorted record.
 * Returns 0 on success, -1 otherwise.
 */
extern int extsort_emit(extsort_t *srt, extsort_emitfn_t *emitfn);

/**
 *  Release the sort.
 */
extern void extsort_close(extsort_t *srt);

/**
 *  Retrieve last errmsg.
 */
extern const char *extsort_errmsg(extsort_t *srt);

#endif /* HOP_EXTSORT_H*/
