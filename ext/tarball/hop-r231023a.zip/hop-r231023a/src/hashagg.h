#ifndef HOP_HASHAGG_H
#define HOP_HASHAGG_H

#include <stdint.h>

typedef struct hagg_t hagg_t;

// Check if two records fed to hagg are equal.
// serialized_rec1 and rec2 are not const because they maybe modified
// (swizzled). serialized_rec1 is the serialized record from hagg_serializefn_t
// rec2 is the source data pointer passed from hagg_feed
typedef int hagg_keyeqfn_t(void *context, void *serialized_rec1, void *rec2);

// Initialize a new agg entry. Returns an aggrec to be associated with
// a new entry.  This probably involves a malloc() call to create aggrec.
typedef void *hagg_initfn_t(void *context);

// Transition function. Given (rec, aggrec), return same or different
// aggrec to be associated with rec.  This probably involves
// realloc(aggrec) if the associated struct changes size.
// rec is a COPY of the source data pointer passed from hagg_feed.
// rec is not const because it may be modified (swizzled).
typedef void *hagg_transfn_t(void *context, void *rec, void *aggrec);

// Emit result. The hashagg has finished. Take the result, that
// is (rec, aggrec), and do something with it before it is destroyed.
// This probably involves free(aggrec).  serialized_rec is not const
// because it may be modified (swizzled).  serialized_rec is the
// serialized record from hagg_serializefn_t.
//
// Return 1 to continue, 0 to stop, or -1 on failure.
typedef int hagg_emitfn_t(void *context, void *serialized_rec, void *aggrec);

// Notification that the hashtable has been reset to empty. You should
// free memory allocated for aggdata (in your initfn and transfn) and
// set aggdata_memusage to 0. (note: &aggdata_memusage was passed to
// hagg_open().
typedef void hagg_resetfn_t(void *context);

// Serialize rec to dest.
// rec is the source data pointer passed from hagg_feed
typedef void hagg_serializefn_t(void *context, const void *rec, void *dest,
                                int destsz);

typedef struct hagg_dispatch_t hagg_dispatch_t;
struct hagg_dispatch_t {
  // mandatory
  hagg_keyeqfn_t *keyeqfn;
  hagg_initfn_t *initfn;
  hagg_transfn_t *transfn;
  hagg_emitfn_t *emitfn;
  // optional
  hagg_resetfn_t *reset;
  hagg_serializefn_t *serialize;
};

/**
 *  Start a hashagg. Aggdata_memusage points to an address that stores
 *  the #bytes used for aggdata for this operation. The sum of this
 *  number and the bytes used in the hashtable is the total memory
 *  that is checked against memlimit to determine if the hashtable
 *  is full and new records should be spilled.
 *
 *  Returns NULL if out-of-memory.
 */
extern hagg_t *hagg_open(void *context, int64_t memlimit,
                         int64_t *aggdata_memusage, const char *spilldir,
                         hagg_dispatch_t dispatch);

/**
 * Feed a record R to the agg. Hagg will:
 *  1. Call the RR=serializefn(R) to make a copy of R internally.
 *  2. If the hashtable does not overflow, call initfn(RR) and transfn(RR).
 *     Otherwise, spill RR to disk.
 *
 * Returns 0 on success, -1 otherwise.
 *
 * Note: rec is not const because it may be modified (swizzled).
 */
extern int hagg_feed(hagg_t *agg, uint64_t hval, void *rec, int reclen);

/**
 *  Finalize the agg. The emitfn function will be invoked for each
 *  distinct entry in the hashtable. The hashtable will be emptied after
 * finalize.
 *
 *  Returns 0 on success, -1 otherwise.
 */
extern int hagg_finalize(hagg_t *agg);

/**
 *  Instead of hagg_finalize(), which uses a callback to finalize
 *  hashtable entries, you might use an iterator to scan the hashtable
 *  and perform the finalization iteratively.
 */
#define HAGG_ITER_STACKMAX 10
typedef struct hagg_subiter_t hagg_subiter_t;
struct hagg_subiter_t {
  hagg_t *agg;
  int bkt;
  int idx;
  void *atom;
};

typedef struct hagg_iter_t hagg_iter_t;
struct hagg_iter_t {
  hagg_subiter_t stack[HAGG_ITER_STACKMAX];
  int top;
};

extern int hagg_iter_init(hagg_t *agg, hagg_iter_t *iter);
extern int hagg_iter_next(hagg_iter_t *iter, void **ret_rec, void **ret_aggrec,
                          char *errmsg, int errmsglen);

/**
 * Release all resources.
 */
extern void hagg_close(hagg_t *agg);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hagg_errmsg(hagg_t *agg);

#endif /* HOP_HASHAGG_H */
