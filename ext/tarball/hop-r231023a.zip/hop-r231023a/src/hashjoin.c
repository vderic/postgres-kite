#include "hashjoin.h"
#include "arena.h"
#include "chtab.h"
#include "komihash.h"
#include "rfile.h"
#include "spill.h"
#include "support.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

static void default_serialize(void *context, const void *rec, void *dest,
                              int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

#define perr(hj, fmt, ...)                                                     \
  reterr(snprintf((hj)->stat.errmsg, sizeof((hj)->stat.errmsg), fmt,           \
                  ##__VA_ARGS__))

struct hj_t {
  rfile_registry_t *registry;
  arena_t *arena;
  chtab_t *tab;
  spill_t *spbuild;
  spill_t *spprobe;

  void *context;
  int64_t memlimit;
  hj_type_t type;
  hj_dispatch_t dispatch;

  hj_t *subhj;     // used for recursive hj on spilled batches
  int32_t subseed; // additional hval seed when processing spilled batches
  int sublevel;    // recursion depth

  hj_stat_t stat;
  rfile_t *scan; // active scan
};

static inline int emit(hj_t *hj, void *pr, void *br, const char *fline) {
  int rc = hj->dispatch.emitfn(hj->context, pr, br);
  if (rc <= 0) {
    hj->stat.stopped |= (rc == 0);
    if (rc < 0) {
      return perr(hj, "emitfn failed (%s)", fline);
    }
  }
  return 0;
}

hj_t *hj_open(void *context, hj_type_t type, int64_t memlimit,
              const char *spilldir, hj_dispatch_t dispatch) {
  assert(dispatch.testfn);
  assert(dispatch.emitfn);

  hj_t *hj = calloc(1, sizeof(*hj));
  EXPECTX(hj, goto bail);

  hj->registry = rfile_registry_create(spilldir);
  EXPECTX(hj->registry, goto bail);

  hj->arena = arena_create();
  EXPECTX(hj->arena, goto bail);

  hj->tab = chtab_create();
  EXPECTX(hj->tab, goto bail);

  hj->context = context;
  hj->memlimit = memlimit;
  hj->type = type;
  hj->dispatch = dispatch;

  if (!hj->dispatch.serialize_build) {
    hj->dispatch.serialize_build = default_serialize;
  }
  if (!hj->dispatch.serialize_probe) {
    hj->dispatch.serialize_probe = default_serialize;
  }

  hj->subseed = rand();

  return hj;

bail:
  hj_close(hj);
  return 0;
}

typedef struct atom_t atom_t;
struct atom_t {
  intptr_t next; // points to next atom_t; we steal a bit to indicate HIT.
  char rec[0];
};

/* Feed the hashjoin with a build record. The build record will either be
 * inserted into the htab or spilled. */
int hj_build(hj_t *hj, uint64_t hval, void *br, int brlen) {

  assert(brlen > 0);
  hj_isdupfn_t *isdupfn = hj->dispatch.isdupfn;

  void **pp = chtab_find(hj->tab, hval);
  // Must insert if hval already exists in htab. NOTE: this is a problem
  // if there is a big skew on a particular hval.
  int do_insert = (0 != pp);

  // insert if htab is below memory limit
  do_insert = do_insert || (arena_size(hj->arena) < hj->memlimit);

  if (do_insert) {
    // user wants unique entries only in the htab
    // TODO: add tests for distinct htab
    if (isdupfn && *pp) {
      for (atom_t *atom = *pp; atom; atom = (atom_t *)(atom->next & ~1)) {
        void *br2 = atom->rec;
        if (isdupfn(hj, br, br2)) {
          return 0; // skip; do not insert duplicate entries
        }
      }
    }

    /*
    if (*pp) {
      // duplicate hval
      // if we want distinct key, scan the atom list to look for match.
    }
    */

    // insert br into htab
    atom_t *atom = arena_alloc(hj->arena, sizeof(atom_t) + brlen);
    if (!atom) {
      return perr(hj, "out of memory (%s)", FLINE);
    }

    hj->dispatch.serialize_build(hj->context, br, atom->rec, brlen);
    if (!pp) {
      // insert into chtab if this is the first atom with 'hval'
      pp = chtab_emplace_ex(hj->tab, hval);
      if (!pp) {
        return perr(hj, "out of memory (%s)", FLINE);
      }
    }

    // link atom to the list at *pp
    atom->next = (intptr_t)*pp;
    *pp = atom;

  } else {
    // Else spill the tuple
    if (!hj->spbuild) {
      hj->spbuild = spill_create(hj->registry, /*use_bloom_filter*/ 1,
                                 hj->stat.errmsg, sizeof(hj->stat.errmsg));
      EXPECT(hj->spbuild);
    }

    // serialize br to a buffer in spill
    void *dest = spill_emplace(hj->spbuild, hval, brlen, hj->stat.errmsg,
                               sizeof(hj->stat.errmsg));
    EXPECT(dest);
    hj->dispatch.serialize_build(hj->context, br, dest, brlen);
  }

  hj->stat.nbuild++;
  return 0;
}

// Feed the hashjoin with a probe (left) record.
// Return 1 to continue, 0 to stop, -1 on error.
int hj_probe(hj_t *hj, uint64_t hval, void *pr, int prlen) {

  hj->stat.nprobe++; // #rec fed to probe
  assert(prlen > 0);

  const char ISLEFT = (0 != (hj->type & HJ_LEFT));
  const char ISNOTIN = (hj->type == HJ_NOT_IN);
  const char ISIN = (hj->type == HJ_IN);

  // if the hval is in the htab, match with either hit or miss.
  void **pp = chtab_find(hj->tab, hval);
  if (pp) {
    char hitflag = 0;
    for (atom_t *atom = *pp; atom && !hj->stat.stopped;
         atom = (atom_t *)(atom->next & ~1)) {
      void *br = atom->rec;
      if (hj->dispatch.testfn(hj->context, pr, br)) {
        hitflag = 1;
        if (ISNOTIN) {
          // There is a hit, which means NOT_IN failed.
          goto success;
        }

        EXPECT(0 == emit(hj, pr, br, FLINE));

        atom->next |= 1; // mark hit
        if (ISIN) {
          // for IN, we are done on first hit
          goto success;
        }
      }
    }
    if (0 == hitflag) {
      if (ISLEFT) { // includes HJ_NOT_IN
        EXPECT(0 == emit(hj, pr, 0, FLINE));
      }
    }
    // Done! because build0() would not spill records with this hval.
    // i.e. this hval does not exist in any build-side spill buckets.
    goto success;
  }

  // At this point, we know there is a MISS when:
  // 1. we are not spilling yet, or
  // 2. this tup will never match a build tuple based on a bloomfilter;
  if (!hj->spbuild || !mbloom_check(hj->spbuild->bloom, hval)) {
    // a MISS here still counts as a match for HJ_LEFT or HJ_NOT_IN
    if (ISLEFT) { // includes HJ_NOT_IN
      EXPECT(0 == emit(hj, pr, 0, FLINE));
    }
    goto success;
  }

  // spill this tuple. It may match a build-tuple already in the spill.
  if (!hj->spprobe) {
    hj->spprobe = spill_create(hj->registry, /*use_bloom_filter*/ 0,
                               hj->stat.errmsg, sizeof(hj->stat.errmsg));
    EXPECT(hj->spprobe);
  }

  void *dest = spill_emplace(hj->spprobe, hval, prlen, hj->stat.errmsg,
                             sizeof(hj->stat.errmsg));
  EXPECT(dest);
  hj->dispatch.serialize_probe(hj->context, pr, dest, prlen);

success:
  return !hj->stat.stopped;
}

static int scan_for_missed_records(hj_t *hj) {
  // this function should only be called for a RIGHT or FULL join
  assert(hj->type & HJ_RIGHT);

  uint64_t hval;
  atom_t *atom;
  chtab_t *tab = hj->tab;

  for (int idx = chtab_first(tab, &hval, (void **)&atom); idx >= 0;
       idx = chtab_next(tab, idx, &hval, (void **)&atom)) {
    for (; atom && !hj->stat.stopped; atom = (atom_t *)(atom->next & ~1)) {
      int hit = atom->next & 1;
      if (!hit) {
        void *br = atom->rec;
        EXPECT(0 == emit(hj, 0, br, FLINE));
      }
    }
  }
  return 0;
}

// Process a spill bucket spid.
static int process(hj_t *hj, int spid) {

  if (!hj->spbuild || !hj->spprobe) {
    // For INNER join, skip if the either build side or the probe side is empty.
    if (hj->type == HJ_INNER) {
      return 0;
    }

    // For IN join, skip only if the probe side is empty.
    if (hj->type == HJ_IN) {
      if (!hj->spprobe) {
        return 0;
      }
    }

    // TODO: for LEFT join, if build is empty, all probe rec matches

    // TODO: for RIGHT join, if probe is empty, all build rec matches.
  }

  //  Cleanup
  if (hj->scan) {
    rfile_close(hj->scan, 0, 0, 0);
    hj->scan = 0;
  }

  // Start a subhj on the batch
  hj_close(hj->subhj);
  hj->subhj = hj_open(hj->context, hj->type, hj->memlimit,
                      rfile_registry_spilldir(hj->registry), hj->dispatch);
  if (!hj->subhj) {
    return perr(hj, "out of memory (%s)", FLINE);
  }
  hj->subhj->sublevel = hj->sublevel + 1;

  // Scan build side, and add to the subhj
  if (hj->spbuild) {
    int rfile_id = spill_rfile_id(hj->spbuild, spid);
    EXPECT(rfile_id > 0);
    hj->scan = rfile_scan(hj->registry, rfile_id, hj->stat.errmsg,
                          sizeof(hj->stat.errmsg));
    EXPECT(hj->scan);

    // For each build tuple ...
    while (!hj->stat.stopped) {
      void *br;
      int brlen;
      int64_t hval;

      EXPECT(0 == rfile_next(hj->scan, &br, &brlen, &hval, hj->stat.errmsg,
                             sizeof(hj->stat.errmsg)));
      if (!br) {
        break; // EOF
      }

      // Rehash with subseed and add to subhj's build side.
      hval = komihash(&hj->subseed, sizeof(hj->subseed), hval);
      if (hj_build(hj->subhj, hval, br, brlen)) {
        strcpy(hj->stat.errmsg, hj->subhj->stat.errmsg);
        return -1;
      }

      hj->stat.stopped |= hj->subhj->stat.stopped;
    }
    rfile_close(hj->scan, /*dispose*/ 1, 0, 0);
    hj->scan = 0;
  }

  // Scan probe side, and add to the subhj
  if (hj->spprobe) {
    int rfile_id = spill_rfile_id(hj->spprobe, spid);
    EXPECT(rfile_id > 0);
    // Scan probe side
    hj->scan = rfile_scan(hj->registry, rfile_id, hj->stat.errmsg,
                          sizeof(hj->stat.errmsg));
    EXPECT(hj->scan);

    // For each probe tuple ...
    while (!hj->stat.stopped) {
      void *pr;
      int prlen;
      int64_t hval;
      EXPECT(0 == rfile_next(hj->scan, &pr, &prlen, &hval, hj->stat.errmsg,
                             sizeof(hj->stat.errmsg)));
      if (!pr) {
        break; // EOF
      }

      // Rehash with subseed and add to subhj's probe side.
      hval = komihash(&hj->subseed, sizeof(hj->subseed), hval);
      int rc = hj_probe(hj->subhj, hval, pr, prlen);
      if (rc < 0) {
        strcpy(hj->stat.errmsg, hj->subhj->stat.errmsg);
        return -1;
      }

      hj->stat.stopped |= hj->subhj->stat.stopped;
    }
    rfile_close(hj->scan, /*dispose*/ 1, 0, 0);
    hj->scan = 0;
  }

  // Finish up the subhj
  EXPECT(-1 != hj_probe_spilled(hj->subhj));
  hj->stat.stopped |= hj->subhj->stat.stopped;

  // Release the subhj asap
  hj_close(hj->subhj);
  hj->subhj = 0;

  return 0;
}

// Do hashjoin on each pair of build/probe files.
int hj_probe_spilled(hj_t *hj) {
  // Scan the current hashtable.
  // All tuples in the current hashtable that were not hit are misses.
  // For RIGHT/FULL outer join, invoke matchfn on them with build records from
  // hashtable and null probe (left) records.
  if (hj->type & HJ_RIGHT) {
    EXPECT(0 == scan_for_missed_records(hj));
  }

  // Done with the htab. Release to free up mem.
  chtab_destroy(hj->tab);
  arena_destroy(hj->arena);
  hj->tab = 0, hj->arena = 0;

  // If there are spill files ...
  if (hj->spbuild || hj->spprobe) {

    // No more writes to spill. Flush and close spill files.
    if (hj->spbuild) {
      EXPECT(0 == spill_close(hj->spbuild, hj->stat.errmsg,
                              sizeof(hj->stat.errmsg)));
    }
    if (hj->spprobe) {
      EXPECT(0 == spill_close(hj->spprobe, hj->stat.errmsg,
                              sizeof(hj->stat.errmsg)));
    }

    // Process each pair of spill files recursively.
    for (int bkt = 0; bkt < SPILL_NBUCKET && !hj->stat.stopped; bkt++) {
      // Process the bucket. This will create a new subhj.
      EXPECT(0 == process(hj, bkt));
    }
  }

  return !hj->stat.stopped;
}

void hj_close(hj_t *hj) {
  if (hj) {
    if (hj->scan) {
      rfile_close(hj->scan, 0, 0, 0);
    }
    chtab_destroy(hj->tab);
    arena_destroy(hj->arena);
    hj_close(hj->subhj);

    spill_destroy(hj->spbuild);
    spill_destroy(hj->spprobe);

    rfile_registry_destroy(hj->registry);
    free(hj);
  }
}


const hj_stat_t* hj_stat(hj_t* hj) {
  return &hj->stat;
}
