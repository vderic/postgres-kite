#ifndef HOP_HASHJOIN_H
#define HOP_HASHJOIN_H

#include <stdint.h>

typedef struct hj_stat_t hj_stat_t;
struct hj_stat_t {
  int64_t nbuild;
  int64_t nprobe;
  int64_t nbuild_spilled;
  int64_t nprobe_spilled;
  int stopped;
  char errmsg[200];
};

typedef struct hj_t hj_t;

// Notify a match event on build record br and probe record pr.
// br and pr are not const because they maybe modified (swizzled).
// Return 1 to continue, 0 to stop, -1 on failure.
typedef int hj_emitfn_t(void *context, void *pr, void *br);

// Check if a build record and a probe record matches.
// br and pr are not const because they maybe modified (swizzled)
// Return 1 for test success, 0 otherwise.
typedef int hj_testfn_t(void *context, void *pr, void *br);

// Check if two build records are duplicates. Return 1 if they are duplicates, 0
// otherwise.  Provide this function in dispatch if you want the build
// htab to be distinct.
typedef int hj_isdupfn_t(void *context, void *br1, void *br2);

// Callback to prepare a rec for memcpy or disk write
typedef void hj_serializefn_t(void *context, const void *rec, void *dest,
                              int destsz);

typedef struct hj_dispatch_t hj_dispatch_t;
struct hj_dispatch_t {
  /* mandatory */
  hj_testfn_t *testfn;
  hj_emitfn_t *emitfn;
  /* optional */
  hj_isdupfn_t *isdupfn;
  hj_serializefn_t *serialize_build; // default is memcpy
  hj_serializefn_t *serialize_probe;
};

/*
 * IMPORTANT:
 *   LEFT is defined as PROBE side.
 *   RIGHT is defined as BUILD side. One way to remember this is
 *   right side is the smaller table, as in nested-loop-join.
 */
enum hj_type_t {
  HJ_INNER = 0,                 // matching pairs only
  HJ_LEFT = 1,                  // pairs + unmatched LHS tuples
  HJ_RIGHT = 2,                 // pairs + unmatched RHS tuples
  HJ_FULL = HJ_LEFT | HJ_RIGHT, // pairs + unmatched LHS + unmatched RHS
  HJ_IN = 8,
  HJ_NOT_IN = 16 | HJ_LEFT,
};
typedef enum hj_type_t hj_type_t;

/*
 * HJ_IN: select * from A where A.i in (select i from B); Logical
 * algorithm: build RIGHT side, but drop duplicates, i.e.  the
 * Hashtable shall contain unique entries only. Probe with LEFT
 * normally like INNER join. However, our hashtable does not support
 * duplicate elimination (TODO: fix this).  This means the htab MAY
 * contain duplicates. To achieve the same effect, on the probe side,
 * we skip traversal of the collision as soon as there is a match,
 * ensuring that one probe will never result in more than one matches.
 *
 * HJ_NOT_IN: select * from A where A.i not in (select i from B);
 * Complement of HJ_IN, EXCEPT: do not probe when the LEFT key has a
 * NULL. This is because any (NULL == NULL) or (NULL != NULL)
 * evaluates to NULL (not False), and the probe tuple can be skipped.
 */

/**
 * Start a hashjoin. Returns NULL if out-of-memory.
 * The intermittent param is optional and can be NULL.
 */
extern hj_t *hj_open(void *context, hj_type_t type, int64_t memlimit,
                     const char *spilldir, hj_dispatch_t dispatch);

/**
 * Insert a record into the build side of the join. The build record is
 * either copied into memory managed by hj, or spilled to disk.
 *
 * Returns 0 on success, -1 otherwise.
 */
extern int hj_build(hj_t *hj, uint64_t hval, void *br, int brlen);

/**
 * Probe the hashtable. The probe record may be spilled to disk. For each match,
 * call emitfn.
 *
 * Return 1 to continue, 0 to stop, -1 on error.
 * NOTE: the return code is different from hj_build!
 */
extern int hj_probe(hj_t *hj, uint64_t hval, void *pr, int prlen);

/**
 * Join the records in each pair of build/probe spill files. For each match,
 * call emitfn.
 *
 * Return 1 to continue, 0 to stop, -1 on error.
 * NOTE: the return code is different from hj_build!
 */
extern int hj_probe_spilled(hj_t *hj);

/**
 * Release resources.
 */
extern void hj_close(hj_t *hj);

/**
 * Status on hj.
 */
extern const hj_stat_t *hj_stat(hj_t *hj);

/**
 * Retrieve the error message of the last failed function.
 */
static inline const char *hj_errmsg(hj_t *hj) { return hj_stat(hj)->errmsg; }

#endif /* HOP_HASHJOIN_H */
