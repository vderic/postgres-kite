#include "mergejoin.h"
#include "support.h"
#include <stdio.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(hj, fmt, ...)                                                     \
  reterr(snprintf((hj)->errmsg, sizeof((hj)->errmsg), fmt, ##__VA_ARGS__))

static void default_copy(void *context, const void *rec, void *dest,
                         int destsz) {
  (void)context;
  memcpy(dest, rec, destsz);
}

struct mj_t {
  void *context;
  mj_dispatch_t dispatch;
  int stopped;

  rfile_t *right;
  void *RR; // current row in right rel
  int RRsz; // len(RR)

  int64_t mark; /* rfile mark for right rel */
  void *MRR;    /* buf for memorized row in right rel*/
  int MRRsz;    /* len(MRR) */
  int MRRmax;   /* size of MRR buffer */

  char errmsg[200];
};

mj_t *mj_open(void *context, mj_dispatch_t dispatch) {
  assert(dispatch.cmpfn);
  assert(dispatch.emitfn);
  if (!dispatch.cpright) {
    dispatch.cpright = default_copy;
  }

  mj_t *mj = calloc(1, sizeof(*mj));
  EXPECTX(mj, goto bail);

  mj->context = context;
  mj->dispatch = dispatch;
  mj->mark = -1;

  return mj;
bail:
  mj_close(mj);
  return 0;
}

void mj_close(mj_t *mj) {
  if (mj) {
    free(mj->MRR);
    free(mj);
  }
}

static int next_right(mj_t *mj, void **prec, int *psz) {
  int64_t hval; // unused
  EXPECT(0 == rfile_next(mj->right, prec, psz, &hval, mj->errmsg,
                         sizeof(mj->errmsg)));
  return 0;
}

int mj_feed_right(mj_t *mj, rfile_t *rfile) {
  assert(!mj->right);
  mj->right = rfile;

  // set up the first RR row
  EXPECT(0 == next_right(mj, &mj->RR, &mj->RRsz));
  return 0;
}

static int save_mark(mj_t *mj, void *RR, int RRsz) {
  mj->mark = rfile_mark(mj->right);
  if (mj->MRRmax < RRsz) {
    free(mj->MRR);
    int newmax = RRsz + 16;
    mj->MRR = malloc(newmax);
    if (!mj->MRR) {
      return perr(mj, "mj_feed_left: out of memory (%s)", FLINE);
    }
    mj->MRRmax = newmax;
  }
  mj->dispatch.cpright(mj->context, RR, mj->MRR, RRsz);
  mj->MRRsz = RRsz;
  return 0;
}

static int restore_mark(mj_t *mj, void **pRR, int *pRRsz) {
  // restore right side to mark
  EXPECT(0 ==
         rfile_restore(mj->right, mj->mark, mj->errmsg, sizeof(mj->errmsg)));
  *pRR = mj->MRR;
  *pRRsz = mj->MRRsz;
  return 0;
}

int mj_feed_left(mj_t *mj, void *rec) {
  if (mj->stopped) {
    return 0;
  }

  // Initial condition:
  // 1. mj->RR contains the current right row
  // 2. mj->MRR, if valid, contains the first row of a range of rows that
  //    matched in the previous round
  // 3. mark, if valid, can be used to restore right scan to the second row of a
  //    range of rows that matched in the previous round

  assert(rec);
  void *context = mj->context;
  mj_cmpfn_t *cmpfn = mj->dispatch.cmpfn;

  void *LL = rec;
  void *RR = mj->RR;
  int RRsz = mj->RRsz;

  // if MRR is valid and LL == MRR: goto emitloop
  if (mj->MRRsz && 0 == cmpfn(context, LL, mj->MRR)) {
    // restore right side to mark
    EXPECT(0 == restore_mark(mj, &RR, &RRsz));
    goto emitloop;
  }
  // forget the memorized row
  mj->MRRsz = 0;
  mj->mark = -1;

  // if no RR, done!
  // TODO: notify that innerjoin is done.
  if (!RR) {
    return 0;
  }

  // skip RR until LL==RR
  while (RR) {
    int diff = cmpfn(context, LL, RR);
    if (!diff)
      break;
    if (diff < 0) {
      // left side is smaller: ignore this LL, wait for next LL.

      // save state and return.
      mj->RR = RR;
      mj->RRsz = RRsz;
      return 0;
    }
    // left side is bigger: get next RR.
    EXPECT(0 == next_right(mj, &RR, &RRsz));
  }

  if (!RR) {
    // no more RR: done.
    // TODO: notify that innerjoin is done.
    return 0;
  }

  // Here: first time RR == LL

  EXPECT(0 == save_mark(mj, RR, RRsz));

emitloop:
  assert(mj->mark >= 0 && mj->MRRsz);
  assert(0 == cmpfn(context, LL, RR));
  // keep emitting until LL != RR
  mj_emitfn_t *emitfn = mj->dispatch.emitfn;
  do {
    int rc = emitfn(context, LL, RR);
    if (rc <= 0) {
      if (rc == 0) {
        // stop;
        mj->stopped = 1;
        return 0;
      }
      // error
      return perr(mj, "mj_feed_left: emit failed (%s)", FLINE);
    }
    EXPECT(0 == next_right(mj, &RR, &RRsz));
  } while (RR && 0 == cmpfn(context, LL, RR));

  // save RR for next LL
  mj->RR = RR;
  mj->RRsz = RRsz;
  return 0;
}
