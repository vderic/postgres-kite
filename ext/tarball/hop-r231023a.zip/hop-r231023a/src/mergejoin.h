#ifndef HOP_MERGEJOIN_H
#define HOP_MERGEJOIN_H

#include "rfile.h"

typedef struct mj_t mj_t;

// NOTE:
// 1. both sides must sorted apriori.
// 2. right side should be smaller than left side unless its rows are distinct
// by join columns.
// 3. right side is a rfile.

// Notify a match event on build record br and probe record pr.
// br and pr are not const because they maybe modified (swizzled).
// Return 1 to continue, 0 to stop, -1 on failure.
typedef int mj_emitfn_t(void *context, void *L, void *R);

// Check if a L record and a R record matches.
// L and R are not const because they maybe modified (swizzled).
// Return -1, 0 or 1.
typedef int mj_cmpfn_t(void *context, void *L, void *R);

// Copy a rec to dest; serialize if rec is swizzled.
typedef void mj_copyfn_t(void *context, const void *rec, void *dest,
                         int destsz);

typedef struct mj_dispatch_t mj_dispatch_t;
struct mj_dispatch_t {
  mj_cmpfn_t *cmpfn; /* compare a left and right rec */
  mj_emitfn_t *emitfn;

  /* optional */
  mj_copyfn_t *cpright; /* copy a right rec to dest */
};

extern mj_t *mj_open(void *context, mj_dispatch_t dispatch);
extern int mj_feed_right(mj_t *mj, rfile_t *rfile);
extern int mj_feed_left(mj_t *mj, void *rec);
extern void mj_close(mj_t *mj);

#endif /* HOP_SORTMERGEJOIN_H */
