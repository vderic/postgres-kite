#include "rfile.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

static int create_file(const char *spilldir, int *ret_fd, char **ret_path,
                       char *errmsg, int errlen);
static int writefully(int fd, const void *buf, int len, char *errmsg,
                      int errlen);

/*
 *  A record in rfile.
 */
#define RFILE_REC_MAGIC 0x26f2
typedef struct rfile_rec_t rfile_rec_t;
struct rfile_rec_t {
  uint16_t magic;
  uint8_t padding;
  uint8_t unused;
  uint32_t len; // inclusive of header
  int64_t hval; // hash value
  char byte[0];
};

struct rfile_t {
  rfile_registry_t *registry;
  int fid;
  int fd;
  int mode; // W for write, R for read.
  char *buf;
  int bot, top, max;
  int eof;
  int64_t position;
};

static int ensure_buf(rfile_t *rfile, int len, char *errmsg, int errlen) {
  int nb = rfile->top - rfile->bot;
  int avail = rfile->max - nb;
  // fits?
  if (avail >= len) {
    if (rfile->top + len >= rfile->max && rfile->bot) {
      // shift to make space
      memmove(rfile->buf, rfile->buf + rfile->bot, nb);
      rfile->bot = 0;
      rfile->top = nb;
    }
    assert(rfile->top + len <= rfile->max);
    return 0;
  }

  // flush
  if (writefully(rfile->fd, rfile->buf + rfile->bot, nb, errmsg, errlen)) {
    return -1;
  }
  rfile->top = rfile->bot = 0;

  // can it fit?
  nb = 0;
  avail = rfile->max;
  if (avail >= len) {
    return 0;
  }

  // still can't fit
  int newmax = len + 100;
  char *newbuf = malloc(newmax);
  if (!newbuf) {
    perr("out of memory (%s)", FLINE);
    return -1;
  }
  free(rfile->buf);
  rfile->buf = newbuf;
  rfile->max = newmax;
  return 0;
}

int rfile_id(rfile_t *rfile) { return rfile->fid; }

rfile_t *rfile_create(rfile_registry_t *registry, char *errmsg, int errlen) {

  rfile_t *rfile = calloc(1, sizeof(*rfile));
  if (!rfile) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  rfile->registry = registry;
  rfile->fd = -1; // important. rfile_close will close fd if it is 0.
  rfile->mode = 'W';
  rfile->max = 16 * 1024;
  rfile->buf = malloc(rfile->max);
  if (!rfile->buf) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  // open the file
  char *path = 0;
  if (create_file(rfile_registry_spilldir(registry), &rfile->fd, &path, errmsg,
                  errlen)) {
    goto bail;
  }

  // save the path and get an id
  rfile->fid = rfile_registry_add(registry, path);
  free(path);
  path = 0;

  if (rfile->fid < 0) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  return rfile;

bail:
  (void)rfile_close(rfile, 1, 0, 0);
  return 0;
}

static int flush(rfile_t *rfile, char *errmsg, int errlen) {
  if (rfile->mode != 'W') {
    return 0;
  }
  int nb = rfile->top - rfile->bot;
  EXPECT(0 ==
         writefully(rfile->fd, rfile->buf + rfile->bot, nb, errmsg, errlen));
  rfile->bot = rfile->top = 0;
  return 0;
}

// Note: rfile_close is guaranteed to succeed if dispose_flag is set.
int rfile_close(rfile_t *rfile, int dispose_flag, char *errmsg, int errlen) {
  assert(rfile->mode == 'W' || rfile->mode == 'R');
  int ret = 0;
  if (rfile) {
    int fd = rfile->fd;
    if (fd >= 0) {
      if (!dispose_flag) {
        ret = flush(rfile, errmsg, errlen);
      }
      close(fd);
    }
    if (dispose_flag) {
      rfile_registry_forget(rfile->registry, rfile->fid);
    }
    free(rfile->buf);
    free(rfile);
  }
  return ret;
}

void *rfile_emplace(rfile_t *rfile, int len, int64_t hval, char *errmsg,
                    int errlen) {
  assert(rfile->mode == 'W');
  assert(len > 0);
  rfile_rec_t *rec = 0;
  int reclen = ALIGN8(sizeof(*rec) + len);
  if (reclen <= (int)sizeof(*rec)) {
    perr("invalid len %d (%s)", len, FLINE);
  }

  // Make sure buf[top..top+reclen] is available
  if (ensure_buf(rfile, reclen, errmsg, errlen)) {
    return 0;
  }

  // Fill in the header
  rec = (rfile_rec_t *)&rfile->buf[rfile->top];
  rec->magic = RFILE_REC_MAGIC;
  rec->padding = reclen - (sizeof(*rec) + len);
  rec->unused = 0;
  rec->len = len;
  rec->hval = hval;

  // Consume the space
  rfile->top += reclen;

#ifndef NDEBUG
  // in debug mode, zero out the padding for valgrind.
  char *p = rec->byte + len;
  for (int i = 0; i < rec->padding; i++) {
    p[i] = 0;
  }
#endif

  // Caller will copy into this addr
  return rec->byte;
}

rfile_t *rfile_scan(rfile_registry_t *registry, int fid, char *errmsg,
                    int errlen) {
  rfile_t *rfile = calloc(1, sizeof(*rfile));
  if (!rfile) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }
  rfile->registry = registry;
  rfile->fd = -1; // important. rfile_close will close fd if it is 0.
  rfile->mode = 'R';
  rfile->max = 32 * 1024;
  rfile->buf = malloc(rfile->max);
  if (!rfile->buf) {
    perr("out of memory %s", FLINE);
    goto bail;
  }

  const char *path = rfile_registry_get(registry, fid);
  if (!path) {
    perr("invalid rfile id %d (%s)", fid, FLINE);
    goto bail;
  }

  rfile->fid = fid;
  rfile->fd = open(path, O_RDONLY);
  if (rfile->fd < 0) {
    perr("%s (%s)", strerror(errno), FLINE);
    goto bail;
  }

  return rfile;

bail:
  if (rfile_close(rfile, 0, errmsg, errlen)) {
#ifndef NDEBUG
    ; // ignore. we can't scan, why? leave the file for debug
#else
    // for production, discard the file.
    (void)rfile_close(rfile, 1, 0, 0);
#endif
  }
  return 0;
}

static int read_more(rfile_t *rfile, char *errmsg, int errlen) {
  if (rfile->eof) {
    return 0;
  }

  // shift buf[bot..top] to buf[0]
  if (rfile->bot) {
    int inuse = rfile->top - rfile->bot;
    memmove(rfile->buf, rfile->buf + rfile->bot, inuse);
    rfile->bot = 0;
    rfile->top = inuse;
  }

  // #byte of free buffer
  int avail = rfile->max - rfile->top;
  if (avail == 0) {
    // extend the buffer
    int newmax = rfile->max * 1.5;
    if (newmax < 0) {
      return perr("rfile_scan(%s): record is too big (%s)",
                  rfile_registry_get(rfile->registry, rfile->fid), FLINE);
    }
    char *tmp = malloc(newmax);
    if (!tmp) {
      return perr("out of memory (%s)", FLINE);
    }
    memcpy(tmp, rfile->buf, rfile->top);
    free(rfile->buf);
    rfile->buf = tmp;
    rfile->max = newmax;
    avail = rfile->max - rfile->top;
  }
  assert(avail > 0);

again:
  int n = read(rfile->fd, rfile->buf + rfile->top, avail);
  if (n <= 0) {
    if (n == 0) {
      rfile->eof = 1;
      return 0;
    }
    /* n < 0 */
    if (errno == EAGAIN || errno == EINTR) {
      goto again;
    }
    return perr("read_more: %s (%s)", strerror(errno), FLINE);
  }
  rfile->top += n;
  return 0;
}

// Return the current record, and move to the next.
int rfile_next(rfile_t *rfile, void **ret_rec, int *ret_len, int64_t *ret_hval,
               char *errmsg, int errlen) {
  assert(rfile->mode == 'R');
  *ret_rec = 0;
  *ret_len = 0;

  while (1) {
    int eof = rfile->eof;

    // Number of valid bytes in buf[]
    int inuse = rfile->top - rfile->bot;
    if (inuse == 0 && rfile->eof) {
      // signal EOF to caller
      *ret_rec = 0;
      return 0;
    }

    // If the full rec is in the buffer, return it.
    if (inuse > (int)sizeof(rfile_rec_t)) {
      // Obtain the record size.
      rfile_rec_t *pp = (rfile_rec_t *)&rfile->buf[rfile->bot];

      if (pp->magic != RFILE_REC_MAGIC) {
        return perr("rfile_next: bad magic number (%s)", FLINE);
      }

      // ppsz: #bytes including header and padding.
      int ppsz = pp->byte + pp->len + pp->padding - (char *)pp;
      if (inuse >= ppsz) {
        // Return the rec.
        *ret_rec = pp->byte;
        *ret_len = pp->len;
        *ret_hval = pp->hval;

        // Advance beyond this record.
        rfile->bot += ppsz;
        rfile->position += ppsz;
        return 0;
      }
    }

    // Read more into buffer
    if (eof) {
      return perr("rfile_next: partial last record in rfile (%s)", FLINE);
    }
    EXPECT(0 == read_more(rfile, errmsg, errlen));
  }
}

/**
 *  Obtain the current position during a scan.
 */
int64_t rfile_mark(rfile_t *rfile) {
  assert(rfile->mode == 'R');
  return rfile->position;
}

/**
 *  Seek to a remembered position so that rfile_next() will return
 *  the tuple at that location.
 */
int rfile_restore(rfile_t *rfile, int64_t mark, char *errmsg, int errlen) {
  assert(mark >= 0);
  assert(rfile->mode == 'R');
  assert(rfile->position >= mark);

  // set the position
  rfile->position = mark;
  if (-1 == lseek(rfile->fd, rfile->position, SEEK_SET)) {
    return perr("rfile_setpos: %s (%s)", strerror(errno), FLINE);
  }

  // Reset the current buffer. Next call to rfile_next() will
  // re-read from disk.
  rfile->bot = rfile->top = 0;

  return 0;
}

// artificial serial number
static uint32_t next_serial() {
  static _Atomic uint32_t serial_gen = 0;
  return ++serial_gen;
}

// Get a file name in the spill dir with a VERY low probability of
// name collision. File name "spill_{time}_{pid}_{serial}".
static char *rand_path(const char *dir) {
  char *path = 0;
  if (-1 == asprintf(&path, "%s/rfile_%" PRIx64 "_%x_%x", dir, time(0),
                     getpid(), next_serial())) {
    return 0;
  }
  return path;
}

// Create a row file and return the path and fd
static int create_file(const char *spilldir, int *ret_fd, char **ret_path,
                       char *errmsg, int errlen) {
  int fd = -1;
  char *path = 0;
  while (fd < 0) {
    /* get a path name and try to create the file. If we failed because the file
     * already exists, retry! */
    path = rand_path(spilldir);
    if (!path) {
      return perr("out of memory (%s)", FLINE);
    }

    fd = open(path, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (fd < 0) {
      perr("open(%s): %s (%s)", path, strerror(errno), FLINE);
      free(path);
      if (errno == EEXIST) {
        // collision! this is VERY UNLIKELY.
        continue; // try again
      }
      return -1;
    }
  }

  // success
  *ret_path = path;
  *ret_fd = fd;
  return 0;
}

static int writefully(int fd, const void *buf, int len, char *errmsg,
                      int errlen) {
  const char *p = buf;
  const char *q = buf + len;
  while (p < q) {
    int n = write(fd, p, q - p);
    if (n == -1) {
      if (errno == EAGAIN || errno == EINTR) {
        continue;
      }
      return perr("%s (%s)", strerror(errno), FLINE);
    }

    if (n == 0) {
      return perr("%s (%s)", strerror(errno), FLINE);
    }

    p += n;
  }

  return 0;
}
