#ifndef HOP_RFILE_H
#define HOP_RFILE_H

#include <stdint.h>

/**
 *  A Row File (abbrev. rfile) stores rows sequentially. Row files can
 *  be created for append operation, or they can be scanned
 *  sequentially.
 *
 *  Rfile registry keeps track of all row files created. At
 *  destruction, it deletes all the row files registered. It also
 *  provides a way to identify row files by int id instead of
 *  cumbersome path string.
 */
typedef struct rfile_registry_t rfile_registry_t;

/* Create a rfile path registry. Return NULL if out of memory. */
rfile_registry_t *rfile_registry_create(const char *spilldir);

/* Add path to rfile_path. Return a rfile_id on success, or -1 if out of memory
 */
int rfile_registry_add(rfile_registry_t *reg, const char *path);

/* Get the path with ID */
const char *rfile_registry_get(rfile_registry_t *reg, int rfile_id);

/* Forget the path. This will delete the file. */
void rfile_registry_forget(rfile_registry_t *reg, int rfile_id);

const char *rfile_registry_spilldir(rfile_registry_t *reg);

/* Clean up. Delete all files. */
void rfile_registry_destroy(rfile_registry_t *reg);

typedef struct rfile_t rfile_t;

/**
 *  Create a row file to write records.  The row file
 *  returned can only be used by rfile_emplace() and rfile_close(). If
 *  there is an error, the file will be closed automatically.
 */
rfile_t *rfile_create(rfile_registry_t *registry, char *errmsg, int errlen);

/**
 *  Obtain the ID of a rfile. Valid ID is >= 1. Return -1 on failure.
 */
int rfile_id(rfile_t *rfile);

/**
 *  Prepare to write to a row file. This function returns a region of
 *  memory that caller can memcpy the record right after the call.
 */
void *rfile_emplace(rfile_t *rfile, int len, int64_t hval, char *errmsg,
                    int errlen);

/**
 *  Prepare to scan a row file. The rfile returned can only be used
 *  by rfile_next() and rfile_close().
 */
rfile_t *rfile_scan(rfile_registry_t *registry, int id, char *errmsg,
                    int errlen);

/**
 *  Return a ptr to the next record in memory of the rfile. Return 0 on
 *  success, -1 otherwise. On EOF, return 0 and set prec to 0.
 */
int rfile_next(rfile_t *rfile, void **prec, int *plen, int64_t *hval,
               char *errmsg, int errlen);

/**
 *  Obtain the current position during a scan.
 */
int64_t rfile_mark(rfile_t *rfile);

/**
 *  Seek to a remembered position so that rfile_next() will return
 *  the tuple at that location.
 */
int rfile_restore(rfile_t *rfile, int64_t mark, char *errmsg, int errlen);

/**
 *  Done with a row file. File will be deleted if dispose flag is set.
 *  Note: rfile_close is guaranteed to succeed if dispose_flag is set.
 */
int rfile_close(rfile_t *rfile, int dispose, char *errmsg, int errlen);

/**
 * Priority queue on array of rfile_t
 */
#define RFILEPQ_MAX 8
typedef struct rfilepq_t rfilepq_t;
typedef struct rfilepq_item_t rfilepq_item_t;
typedef int rfilepq_keycmpfn_t(void *context, void *rec1, void *rec2);
struct rfilepq_item_t {
  int id;
  rfile_t *rfile;
  void *rec;
  int len;
};

struct rfilepq_t {
  rfile_registry_t *registry;
  void *context;
  rfilepq_keycmpfn_t *keycmpfn;

  rfilepq_item_t item[RFILEPQ_MAX];
  int nitem;
  int heapified; // true if item[] is a heap
};

static inline void rfilepq_init(rfilepq_t *pq, rfile_registry_t *registry,
                                void *context, rfilepq_keycmpfn_t *keycmpfn) {
  pq->registry = registry;
  pq->context = context;
  pq->keycmpfn = keycmpfn;
  pq->nitem = 0;
}

/* Push a sorted row file into pq. It must not be empty. Return 0 on success, -1
 * otherwise.*/
int rfilepq_push(rfilepq_t *pq, int id, char *errmsg, int errlen);

/* Pop a record from the row files in the pq. Returns 0 on success, -1
 * otherwise. If empty, Returns 0 and set prec to NULL. */
int rfilepq_pop(rfilepq_t *pq, void **rec, int *len, char *errmsg, int errlen);

void rfilepq_close(rfilepq_t *pq);

#endif /* HOP_RFILE_H */
