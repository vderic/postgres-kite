#include "rfile.h"
#include "support.h"
#include <stdio.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

static inline void swap(rfilepq_t *pq, int i, int j) {
  rfilepq_item_t tmp = pq->item[i];
  pq->item[i] = pq->item[j];
  pq->item[j] = tmp;
}

static void assert_heap(rfilepq_t *pq, int i) {
#ifndef NDEBUG
  int n = pq->nitem;
  if (i >= n) {
    return;
  }

  int me = i;
  int L = 2 * i + 1;
  int R = 2 * i + 2;
  rfilepq_item_t *item = pq->item;
  rfilepq_keycmpfn_t *cmp = pq->keycmpfn;
  void *context = pq->context;

  if (L < n) {
    assert(cmp(context, item[L].rec, item[me].rec) >= 0);
    assert_heap(pq, L);
  }

  if (R < n) {
    assert(cmp(context, item[R].rec, item[me].rec) >= 0);
    assert_heap(pq, R);
  }
#else
  (void)pq;
  (void)i;
#endif
}

static void heapify(rfilepq_t *pq, int i) {
again:
  int min = i;
  int L = 2 * i + 1;
  int R = 2 * i + 2;
  int N = pq->nitem;
  rfilepq_item_t *item = pq->item;
  rfilepq_keycmpfn_t *cmp = pq->keycmpfn;
  void *context = pq->context;

  // determine the idx of minimum val among min, L and R.
  if (L < N) {
    min = (cmp(context, item[L].rec, item[min].rec) < 0) ? L : min;
  }
  if (R < N) {
    min = (cmp(context, item[R].rec, item[min].rec) < 0) ? R : min;
  }

  // if i is not min, heap property is broken.
  if (min != i) {
    swap(pq, i, min);

    // tail recursion down the tree
    // same as heapify(pq, min)
    i = min;
    goto again;
  }
}

int rfilepq_push(rfilepq_t *pq, int id, char *errmsg, int errlen) {
  if (pq->nitem >= RFILEPQ_MAX) {
    return perr("rfilepq_push: overflow (%s)", FLINE);
  }

  // put as last element of []
  int i = pq->nitem++;
  pq->item[i].id = id;
  pq->item[i].rfile = 0;
  pq->item[i].rec = 0;

  return 0;
}

int rfilepq_pop(rfilepq_t *pq, void **ret_rec, int *ret_len, char *errmsg,
                int errlen) {
  int64_t dummy_hval;
  rfilepq_item_t *item = pq->item;
  *ret_rec = 0;
  *ret_len = 0;

  // If the pqueue is not heapified, make it so.
  if (!pq->heapified) {
    // setup initial values
    for (int j = 0; j < pq->nitem; j++) {
      item[j].rfile = rfile_scan(pq->registry, item[j].id, errmsg, errlen);
      EXPECT(item[j].rfile);

      // retrieve first value from the row file
      EXPECT(0 == rfile_next(item[j].rfile, &item[j].rec, &item[j].len,
                             &dummy_hval, errmsg, errlen));
      if (item[j].rec == 0) {
        return perr("internal error (%s)", FLINE);
      }
    }

    // heapify the whole array
    for (int i = pq->nitem / 2 - 1; i >= 0; i--) {
      heapify(pq, i);
    }
    assert_heap(pq, 0);
    pq->heapified = 1;

  } else {

    // get next value for rfile[0]
    item[0].rec = 0;
    while (pq->nitem && item[0].rec == 0) {
      EXPECT(0 == rfile_next(item[0].rfile, &item[0].rec, &item[0].len,
                             &dummy_hval, errmsg, errlen));

      if (item[0].rec == 0) {
        // rfile[0] is finished. drop it.
        (void)rfile_close(item[0].rfile, 1, 0, 0);
        swap(pq, 0, pq->nitem - 1);
        pq->nitem--;
      }
    }

    // item[0].rec has changed. make pq a heap again starting at idx 0.
    heapify(pq, 0);
    assert_heap(pq, 0);
  }

  if (pq->nitem == 0) {
    // EOF
    *ret_rec = 0;
  } else {
    // return value at root node of pqueue
    *ret_rec = item[0].rec;
    *ret_len = item[0].len;
  }

  return 0;
}

void rfilepq_close(rfilepq_t *pq) {
  rfilepq_item_t *item = pq->item;
  for (int i = 0; i < pq->nitem; i++) {
    if (item[i].rfile) {
      (void)rfile_close(item[i].rfile, 1, 0, 0);
      item[i].rfile = 0;
      item[i].rec = 0;
    }
  }
}
