#include "rfile.h"
#include "support.h"
#include <unistd.h>

/**
 *  The path register is used to map a sorted run file path name to an
 *  ID. We group all the paths here so that we can avoid copying the
 *  path all over the place, and to have a single place to find and
 *  delete all sorted run files when the sort is done.
 */
struct rfile_registry_t {
  char *spilldir;
  ptrvec_t ptrvec;
};

rfile_registry_t *rfile_registry_create(const char *spilldir) {
  rfile_registry_t *sp = calloc(1, sizeof(*sp));
  EXPECTX(sp, goto bail);

  sp->spilldir = strdup(spilldir);
  EXPECTX(sp->spilldir, goto bail);

  // take up slot 0 so that valid ID starts from 1.
  EXPECTX(0 == ptrvec_add(&sp->ptrvec, 0), goto bail);

  return sp;

bail:
  rfile_registry_destroy(sp);
  return 0;
}

/* Add path to rfile_path. Return a ID on success, or -1 if out of memory */
int rfile_registry_add(rfile_registry_t *reg, const char *path) {
  char *p = strdup(path);
  EXPECT(p);

  EXPECT(0 == ptrvec_add(&reg->ptrvec, p));

  return reg->ptrvec.top - 1;
}

// Retrieve the path of a sorted run by ID.
const char *rfile_registry_get(rfile_registry_t *reg, int id) {
  int top = reg->ptrvec.top;
  return (1 <= id && id < top) ? reg->ptrvec.pptr[id] : 0;
}

const char *rfile_registry_spilldir(rfile_registry_t *reg) {
  return reg->spilldir;
}

// Forget a sorted run ==> delete the file and free memory used to store its
// name.
void rfile_registry_forget(rfile_registry_t *reg, int id) {
  int top = reg->ptrvec.top;
  char **pp = (1 <= id && id < top) ? &reg->ptrvec.pptr[id] : 0;
  if (pp && *pp) {
    unlink(*pp);
    free(*pp);
    *pp = 0;
  }
}

void rfile_registry_destroy(rfile_registry_t *reg) {
  free(reg->spilldir);

  // delete all sorted run files
  int top = reg->ptrvec.top;
  char **pp = reg->ptrvec.pptr;
  for (int i = 1; i < top; i++) {
    char *p = pp[i];
    if (p) {
      unlink(p);
      free(p);
    }
  }
  free(pp);

  free(reg);
}
