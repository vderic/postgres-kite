

void sort_merge_join(rel left, rel right, comparator_t cmp, emiter_t emit) {

  // Ensure that at least one element is present
  if (left.empty() || right.empty()) {
    return;
  }

  // For optimal result, right rel should be smaller than left rel!

  // Sort both rels
  right.sort(cmp);
  left.sort(cmp);

  // Start Merge Join algorithm
  RR = right.next();
  LL = left.next();

  while (LL && RR) {

    // loop until LL == RR, advancing the smaller row
    while (LL && RR) {
      // if RR < LL: advance right; else: advance left
      int diff = cmp(LL, RR);
      if (!diff)
        break;
      if (diff < 0) {
        LL = left.next();
      } else {
        RR = right.next();
      }
    }

    if (!LL || !RR)
      break;

    // ... here LL == RR

    // Mark of right row and keep a copy of current right row
    right.mark();
    MRR = RR;

    while (LL && RR) {
      // for current LL, match rows from right until no match
      do {
        emit(LL, RR);
        RR = right.next();
      } while (RR && cmp(LL, RR) == 0);

      // advance LL
      LL = left.next();

      // if LL matches the MRR, go back on right rel and repeat.
      if (LL && cmp(LL, MRR) == 0) {
        // Restore right to stored mark
        right.restore();
        RR = MRR;
      }
    }
  }
}
