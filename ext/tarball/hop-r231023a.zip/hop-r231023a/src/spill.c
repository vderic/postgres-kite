#include "spill.h"
#include "../src/komihash.h"
#include "mbloom.h"
#include "rfile.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

// For a value N, there are 2^N buckets, each with two
// spill files for build and probe.
typedef struct spill_bucket_t bucket_t;
struct spill_bucket_t {
  rfile_registry_t *registry;
  int bno; // range [0..NBUCKET)
  int rfile_id;
  rfile_t *rfile; // spill file (NULL if closed)
  int64_t nbyte;
  int64_t nrow;
};

// Delete a bucket. Will drop the files.
static void bucket_drop(bucket_t *p) {
  if (p) {
    if (p->rfile) {
      rfile_close(p->rfile, /*dispose*/ 1, 0, 0);
      p->rfile = 0;
      rfile_registry_forget(p->registry, p->rfile_id);
    }
    free(p);
  }
}

// Create a bucket
static bucket_t *bucket_new(rfile_registry_t *registry, int bno, char *errmsg,
                            int errlen) {
  bucket_t *p = calloc(1, sizeof(*p));
  if (!p) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }
  p->registry = registry;
  p->bno = bno;
  p->rfile = rfile_create(registry, errmsg, errlen);
  EXPECTX(p->rfile, goto bail);
  p->rfile_id = rfile_id(p->rfile);

  return p;

bail:
  if (p) {
    bucket_drop(p);
  }
  return 0;
}

// Close the spf file
static int bucket_close(bucket_t *p, char *errmsg, int errlen) {
  // Previously closed?
  if (!p->rfile) {
    return 0;
  }

  // Close it
  int ret = rfile_close(p->rfile, /*dispose*/ 0, errmsg, errlen);
  p->rfile = 0;
  return ret;
}

static void *bucket_emplace(bucket_t *p, uint64_t hval, int len, char *errmsg,
                            int errlen) {
  if (!p->rfile) {
    perr("spill file is closed (%s)", FLINE);
    return 0;
  }

  return rfile_emplace(p->rfile, len, hval, errmsg, errlen);
}

// Create the spill
spill_t *spill_create(rfile_registry_t *registry, int use_bloom_filter,
                      char *errmsg, int errlen) {
  spill_t *sp = calloc(1, sizeof(spill_t));
  if (!sp) {
    perr("out of memory (%s)", FLINE);
    goto bail;
  }

  sp->registry = registry;

  for (int i = 0; i < SPILL_NBUCKET; i++) {
    sp->bucket[i] = bucket_new(registry, i, errmsg, errlen);
    if (!sp->bucket[i]) {
      goto bail;
    }
  }

  if (use_bloom_filter) {
    sp->bloom = mbloom_create(1024 * 1024 * 8); // 1MB
    if (!sp->bloom) {
      perr("out of memory (%s)", FLINE);
      goto bail;
    }
  }

  return sp;

bail:
  spill_destroy(sp);
  return 0;
}

// Cleanup and delete the spill
void spill_destroy(spill_t *sp) {
  if (sp) {
    for (int i = 0; i < SPILL_NBUCKET; i++) {
      bucket_drop(sp->bucket[i]);
    }
    mbloom_destroy(sp->bloom);
    free(sp);
  }
}

// Add a record to the corresponding spill file
void *spill_emplace(spill_t *sp, uint64_t hval, int len, char *errmsg,
                    int errlen) {
  // which bucket?
  int id = hval % SPILL_NBUCKET;

  // add to bloom filter
  if (sp->bloom) {
    mbloom_add(sp->bloom, hval);
  }

  // find bucket[id]
  bucket_t *bucket = sp->bucket[id];
  void *p = bucket_emplace(bucket, hval, len, errmsg, errlen);
  EXPECTX(p, return NULL);

  sp->nrow++;
  sp->nbyte += len; // this does not include spill_rec_t header
  return p;
}

// Flush all records in spill buffer
int spill_close(spill_t *sp, char *errmsg, int errlen) {
  for (int i = 0; i < SPILL_NBUCKET; i++) {
    bucket_close(sp->bucket[i], errmsg, errlen);
  }
  return 0;
}

int spill_rfile_id(spill_t *sp, int bkt) {
  EXPECT(0 <= bkt && bkt < SPILL_NBUCKET);
  return sp->bucket[bkt]->rfile_id;
}
