#ifndef HOP_SPILL_H
#define HOP_SPILL_H

#include "mbloom.h"
#include <stdint.h>

// Spill control block
typedef struct rfile_registry_t rfile_registry_t;
typedef struct spill_bucket_t spill_bucket_t;
typedef struct spill_t spill_t;
#define SPILL_NBUCKET 8
struct spill_t {
  rfile_registry_t *registry;
  spill_bucket_t *bucket[SPILL_NBUCKET]; // for bucket 0-7
  int64_t nrow;                          // total #row spilled so far
  int64_t nbyte;                         // total #byte spilled so far
  mbloom_t *bloom;
};

/**
 * Create a spill. Returns NULL if out of memory.
 */
spill_t *spill_create(rfile_registry_t *registry, int use_bloom_filter,
                      char *errmsg, int errlen);

/**
 * Destroy a spill. Free all memory and delete all spill files.
 */
void spill_destroy(spill_t *sp);

/**
 *  Check if a hval potentially match a build tuple.
 */
static inline int spill_can_ignore(spill_t *sp, uint64_t hval) {
  return !mbloom_check(sp->bloom, hval);
}

/**
 * Add a record to the corresponding spill file depending on hval.
 * Returns 0 on success, -1 otherwise.
 */
void *spill_emplace(spill_t *sp, uint64_t hval, int len, char *errmsg,
                    int errmsglen);

/**
 * Flush and close all files.
 */
int spill_close(spill_t *sp, char *errmsg, int errmsglen);

/**
 * Return the rfile_id of the rfiles. ID ranges [0..7].
 */
int spill_rfile_id(spill_t *sp, int bkt);

#endif /* HOP_SPILL_H */
