#ifndef HOP_SUPPORT_H
#define HOP_SUPPORT_H

#include <assert.h>
#include <stdlib.h>
#include <string.h>

// clang-format off
#define EXPECT(x) if (x); else return -1
#define EXPECTX(x, action)  if (x); else action
// clang-format on

/* FLINE: returns a string repr (filename:lineno) */
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

static inline const char *fline(const char *s) {
  const char *p = strrchr(s, '/');
  return p ? p + 1 : s;
}

#define FLINE fline(__FILE__ ":" TOSTRING(__LINE__))

#define ALIGN4(x) (((x) + 3) & ~3)
#define ALIGN8(x) (((x) + 7) & ~7)

// Buffer to store an array of pointers
typedef struct ptrvec_t ptrvec_t;
struct ptrvec_t {
  char **pptr; // array of char*
  int top, max;
};

static inline void ptrvec_reset(ptrvec_t *vec) {
  free(vec->pptr);
  vec->pptr = 0;
  vec->top = vec->max = 0;
}

// Add a ptr to ptrvec. Automatically expand the vector.
static inline int ptrvec_add(ptrvec_t *vec, char *x) {
  int top = vec->top;
  if (top >= vec->max) {
    int newmax = (vec->max + 10) * 1.5;
    char **newpptr = realloc(vec->pptr, sizeof(*newpptr) * newmax);
    if (!newpptr) {
      return -1;
    }
    vec->pptr = newpptr;
    vec->max = newmax;
  }
  assert(top < vec->max);
  vec->pptr[top] = x;
  vec->top++; // one more item
  return 0;
}

// Buffer to store an array of int
typedef struct intvec_t intvec_t;
struct intvec_t {
  int *arr; // array of int
  int top, max;
};

static inline void intvec_reset(intvec_t *vec) {
  free(vec->arr);
  vec->arr = 0;
  vec->top = vec->max = 0;
}

// Add an int to intvec. Automatically expand the vector.
static inline int intvec_add(intvec_t *vec, int x) {
  int top = vec->top;
  if (top >= vec->max) {
    int newmax = (vec->max + 10) * 1.5;
    int *newarr = realloc(vec->arr, sizeof(*newarr) * newmax);
    if (!newarr) {
      return -1;
    }
    vec->arr = newarr;
    vec->max = newmax;
  }
  assert(top < vec->max);
  vec->arr[top] = x;
  vec->top++; // one more item
  return 0;
}

#endif /* HOP_SUPPORT_H */
