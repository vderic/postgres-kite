set -e 
(cd test1 && bash run.sh) || exit 1
(cd test2 && bash run.sh) || exit 1
