#include "../src/chtab.h"
#include "harness.h"

typedef struct item_t item_t;
struct item_t {
  int key;
  int value;
  item_t *next;
  item_t *chain;
};

static item_t *list = 0;

static item_t *make(int key) {
  item_t *item = calloc(1, sizeof(*item));
  EXPECT(item);
  item->key = key;
  item->value = key * 2;
  item->chain = list;
  list = item;
  return item;
}

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

static chtab_t *tab = 0;

static int insert(int i) {
  item_t *item = make(i);
  uint64_t hval = hashi(i);
  void **pp = chtab_emplace(tab, hval);
  EXPECT(pp);
  item->next = *pp;
  *pp = item;
  return 0;
}

static item_t *exists(int i) {
  uint64_t hval = hashi(i);
  void **pp = chtab_find(tab, hval);
  if (pp) {
    for (item_t *item = *pp; item; item = item->next) {
      if (item->key == i) {
        return item;
      }
    }
  }
  return 0;
}

int main() {

  tab = chtab_create();
  EXPECT(tab);

  for (int i = 1; i <= 1000; i++) {
    EXPECT(0 == insert(i));
    for (int j = 1; j <= i; j++) {
      EXPECT(exists(j));
      EXPECT(!exists(-j));
    }
  }

  chtab_destroy(tab);
  for (item_t *p = list; p;) {
    item_t *next = p->chain;
    free(p);
    p = next;
  }

  return 0;
}
