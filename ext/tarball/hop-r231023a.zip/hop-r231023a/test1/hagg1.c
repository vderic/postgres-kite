#include "../src/hashagg.h"
#include "harness.h"

/*
   Do agg count, sum, avg on a table like this:

   A    B
   1    1
   2    2
   1    3
   2    4
   1    5
   2    6
   1    7
   2    8

   select A, count(B), sum(B), avg(B) from T group by A;
*/

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples
typedef struct tuple_t tuple_t;
struct tuple_t {
  int A;
  int B;
};

// Generate tuples
static int get_tuple(tuple_t *tp) {
  static int serial = 0;
  if (serial >= 8) {
    return -1;
  }
  serial++;

  tp->A = 1 + (serial - 1) % 2;
  tp->B = serial;
  printf("%d %d\n", tp->A, tp->B);
  return 0;
}

// Two tuples are equal if t1->A == t2->A
static int keyeq(void *context, void *rec1, void *rec2) {
  (void)context;
  const tuple_t *t1 = rec1;
  const tuple_t *t2 = rec2;
  return t1->A == t2->A;
}

// Our agg will store count and sum
typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  int count;
  int sum;
};

// On init: alloc memory for aggdata associated with rec and initialize with
// count and sum.
static void *init(void *context) {
  (void)context;
  aggdata_t *dp = malloc(sizeof(*dp));
  if (dp) {
    dp->count = 0;
    dp->sum = 0;
  }
  return dp;
}

// On transition: update count and sum of aggdata related to rec
static void *trans(void *context, void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  printf("trans %d %d sum %d -> %d\n", tp->A, tp->B, dp->sum, dp->sum + tp->B);
  dp->count++;
  dp->sum += tp->B;
  return dp;
}

static int first = 1;

// On emit: save results and free aggdata allocated
static int emit(void *context, void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  if (first) {
    // print column names
    printf("%s\t%s\t%s\t%s\n", "A", "count", "sum", "avg");
    first = 0;
  }
  printf("%d\t%d\t%d\t%f\n", tp->A, dp->count, dp->sum,
         dp->sum / (double)dp->count);
  free(dp);
  return 1;
}

int main() {
  // Create a hashagg
  char *context = 0;
  hagg_dispatch_t dispatch = {0};
  dispatch.keyeqfn = keyeq;
  dispatch.initfn = init;
  dispatch.transfn = trans;
  dispatch.emitfn = emit;

  int64_t aggdata_memusage = 0;
  hagg_t *agg = hagg_open(context, 100, &aggdata_memusage, ".", dispatch);

  // Feed the hashagg with tuples
  printf("\n--- feeding\n");
  while (1) {
    tuple_t tup;
    if (0 != get_tuple(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.A);
    EXPECT(0 == hagg_feed(agg, hval, &tup, sizeof(tup)));
  }

  printf("\n--- finalizing\n");
  EXPECT(0 == hagg_finalize(agg));

  // Done!
  hagg_close(agg);

  return 0;
}
