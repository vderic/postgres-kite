#include "../src/hashagg.h"
#include "harness.h"

/*
   Same as hagg2.c, but use the iterator interface to finish.

   Do agg count, sum, avg on a table like this:

   A    B
   1    1
   2    2
   3    3
   4	4
   ...
   1000 1000


   select A, count(B), sum(B), avg(B) from T group by A;

*/

// Hash an integer
static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples
typedef struct tuple_t tuple_t;
struct tuple_t {
  int A;
  int B;
};

// Generate tuples
static int get_tuple(tuple_t *tp) {
  static int serial = 0;
  if (serial >= 1000) {
    return -1;
  }
  serial++;

  tp->A = serial;
  tp->B = serial;
  return 0;
}

// Two tuples are considered equal if t1->A == t2->A
static int keyeq(void *context, void *rec1, void *rec2) {
  (void)context;
  const tuple_t *t1 = rec1;
  const tuple_t *t2 = rec2;
  return t1->A == t2->A;
}

// Our agg will store count and sum
typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  int count;
  int sum;
};

// On init: alloc memory for aggdata associated with rec and initialize with
// count and sum.
static void *init(void *context) {
  (void)context;
  aggdata_t *dp = malloc(sizeof(*dp));
  if (dp) {
    dp->count = 0;
    dp->sum = 0;
  }
  return dp;
}

// On transition: update count and sum of aggdata related to rec
static void *trans(void *context, void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  dp->count++;
  dp->sum += tp->B;
  return dp;
}

char *output[1000] = {0};
int line = 0;

// On emit: save results and free aggdata allocated
static int emit(void *context, void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  char *s = malloc(100);
  EXPECT(s);

  sprintf(s, "%04d\t%d\t%d\t%f", tp->A, dp->count, dp->sum,
          dp->sum / (double)dp->count);

  EXPECT(line < 1000);
  output[line++] = s;

  free(data);
  return 1;
}

static int mycmp(const void *a, const void *b) {
  char **x = (char **)a;
  char **y = (char **)b;
  return strcmp(*x, *y);
}

int main() {
  // Create a hashagg
  char *context = 0;
  hagg_dispatch_t dispatch = {0};
  dispatch.keyeqfn = keyeq;
  dispatch.initfn = init;
  dispatch.transfn = trans;
  dispatch.emitfn = emit;
  int64_t aggdata_memusage = 0;
  hagg_t *agg = hagg_open(context, 100, &aggdata_memusage, ".", dispatch);

  // Feed the hashagg with tuples
  while (1) {
    tuple_t tup;
    if (0 != get_tuple(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.A);
    EXPECT(0 == hagg_feed(agg, hval, &tup, sizeof(tup)));
  }

  // Finalize
  hagg_iter_t iter;
  EXPECT(0 == hagg_iter_init(agg, &iter));
  for (;;) {
    tuple_t *tp;
    aggdata_t *dp;
    char errmsg[100];
    EXPECT(0 == hagg_iter_next(&iter, (void **)&tp, (void **)&dp, errmsg,
                               sizeof(errmsg)));
    if (tp == 0) {
      break;
    }

    int rc = emit(context, tp, dp);
    EXPECT(rc > 0);
  }

  // Done!
  hagg_close(agg);

  // Print (sorted) results.
  printf("\nA\tcount\tsum\tavg\n");
  qsort(output, line, sizeof(char *), mycmp);
  for (int i = 0; i < line; i++) {
    printf("%s\n", output[i]);
    free(output[i]);
  }
  return 0;
}
