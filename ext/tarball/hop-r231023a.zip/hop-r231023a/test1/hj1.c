/*

  1. the htab can contain 10 entries
  2. BS = create 100 rows of (X, X), where X range 1..100.
  3. PS = create 300*4 rows of (X, Y), where X range 1..300, Y = -X.

     note: PS has 4 sets of 1..300, Each set has 100 match with BS,
           So, expect 400 hits when joining PS AND BS.

  4. for row in BS: add to build side.
  5. for row in PS: add to probe side.
  6. probe_spilled.
  7. done!

 */
#include "../src/hashjoin.h"
#include "harness.h"

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the build side of the join
typedef struct buildrec_t buildrec_t;
struct buildrec_t {
  int key;
  int value;
  int side;
};
static int is_buildrec(const buildrec_t *tp) { return tp->side == 'B'; }

// Tuples from the probe side of the join
typedef struct proberec_t proberec_t;
struct proberec_t {
  int key;
  int value;
  int side;
  int dummy; // to make sizeof(buildrec_t) != sizeof(proberec_t)
};
static int is_proberec(const proberec_t *tp) { return tp->side == 'P'; }

// Get the next left tuple.
// Key range [1..100]
static int get_buildrec(buildrec_t *tp) {
  // build table has tuples with keys from 1..100
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  tp->side = 'B';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple.
// Key range [1..300]
static int get_proberec(proberec_t *tp) {
  // right table has tuples with keys from 1..300
  static int serial = 0;
  if (serial >= 1200) {
    return -1;
  }
  memset(tp, 0, sizeof(*tp));
  tp->side = 'P';
  tp->key = 1 + serial % 300;
  tp->value = -serial;

  serial++;
  return 0;
}

int count_hit = 0;
int count_miss = 0;

static int match(void *context, void *pr, void *br) {
  (void)context;
  const buildrec_t *BR = (buildrec_t *)br;
  const proberec_t *PR = (proberec_t *)pr;
  EXPECT(!BR || is_buildrec(BR));
  EXPECT(!PR || is_proberec(PR));

  if (!BR) {
    printf("miss (%c %d %d)\n", PR->side, PR->key, PR->value);
    count_miss++;
  } else if (!BR) {
    printf("miss (%c %d %d)\n", BR->side, BR->key, BR->value);
    count_miss++;
  } else {
    printf("hit (%c %d %d) (%c %d %d)\n", BR->side, BR->key, BR->value,
           PR->side, PR->key, PR->value);
    count_hit++;
  }
  return 1;
}

static int keyeq(void *context, void *pr, void *br) {
  (void)context;
  const buildrec_t *BR = br;
  const proberec_t *PR = pr;
  EXPECT(is_buildrec(BR));
  EXPECT(is_proberec(PR));
  return BR->key == PR->key;
}

hj_t *hj = 0;

// Scan left side and feed to hj
static void build() {

  // For each tuple from build side
  for (;;) {
    buildrec_t tup;
    if (get_buildrec(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    EXPECT(0 == hj_build(hj, hval, &tup, sizeof(tup)));
  }
}

static void probe() {

  // For each tuple from RIGHT side
  for (;;) {
    proberec_t tup;
    if (get_proberec(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    EXPECT(-1 != hj_probe(hj, hval, &tup, sizeof(tup)));
  }

  EXPECT(-1 != hj_probe_spilled(hj));
}

int main() {
  char *context = 0;
  hj_dispatch_t dispatch = {0};
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;

  hj = hj_open(context, HJ_FULL, 200, ".", dispatch);
  EXPECT(hj);

  {
    build();
    probe();
  }

  printf("\n");
  printf("#hit = %d\n", count_hit);
  printf("#miss = %d\n", count_miss);

  EXPECT(count_hit == 400);
  EXPECT(count_miss == 800);

  hj_close(hj);

  return 0;
}
