// RIGHT JOIN
#include "hjrec.hpp"

int main() {
  char *context = 0;
  hj_dispatch_t dispatch;
  memset(&dispatch, 0, sizeof(dispatch));

  printf("\nRIGHT OUTER JOIN\n\n");
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;
  hj = hj_open(context, HJ_RIGHT, 100, ".", dispatch);
  EXPECT(hj);
  build();
  probe();
  hj_close(hj);

  print(result);

  printf("hit_both = %d\n", count_hit_both);
  printf("hit_left = %d\n", count_hit_left);
  printf("hit_right = %d\n", count_hit_right);
  EXPECT(50 == count_hit_both);
  EXPECT(50 == count_hit_right);
  EXPECT(0 == count_hit_left);
  printf("\n");

  return 0;
}
