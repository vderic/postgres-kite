#pragma once

extern "C" {
#include "../src/hashjoin.h"
#include "harness.h"
}

#include <algorithm>
#include <string>
#include <vector>

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

typedef struct right_t right_t;
struct right_t {
  const char side = 'R';
  const int key;
  right_t(int v) : key(v){};
};

typedef struct left_t left_t;
struct left_t {
  const char side = 'L';
  const double key;
  left_t(int v) : key(v) {}
};

std::vector<right_t> right_rel = {
    10, 11, 12, 10, 11, 12, //
    10, 11, 12, 10, 11, 12, //
    10, 11, 12, 10, 11, 12, //
    13, 14, 15, 16, 17, 18, 19,
};

std::vector<left_t> left_rel = {
    0,  1,  2,  3,  4,  5,  6,  7,  8,  9,  //
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, //
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
};

static int is_right(const void *rec) { return *(char *)rec == 'R'; }

static int is_left(const void *rec) { return *(char *)rec == 'L'; }

static int keyeq(void *context, void *pr, void *br) {
  (void)context;
  EXPECT(is_right(br));
  EXPECT(is_left(pr));
  auto RP = (const right_t *)br;
  auto LP = (const left_t *)pr;
  return LP->key == RP->key;
}

static int count_hit_right = 0;
static int count_hit_left = 0;
static int count_hit_both = 0;
static std::vector<std::string> result;

static int match(void *context, void *pr, void *br) {
  (void)context;
  EXPECT(!br || is_right(br));
  EXPECT(!pr || is_left(pr));
  auto RP = (const right_t *)br;
  auto LP = (const left_t *)pr;
  char out[1000];

  if (!LP) {
    sprintf(out, "hit (- -) (%c %d)", RP->side, RP->key);
    count_hit_right++;
  } else if (!RP) {
    sprintf(out, "hit (%c %d) (- -)", LP->side, (int)LP->key);
    count_hit_left++;
  } else {
    sprintf(out, "hit (%c %d) (%c %d)", LP->side, (int)LP->key, RP->side,
            RP->key);
    count_hit_both++;
  }
  result.push_back(out);
  return 1;
}

hj_t *hj = 0;

static void build() {
  // For each tuple from RIGHT side
  for (auto &tup : right_rel) {
    uint64_t hval = hashi(tup.key);
    EXPECT(0 == hj_build(hj, hval, &tup, sizeof(tup)));
  }
}

static void probe() {
  // For each tuple from LEFT side
  for (auto &tup : left_rel) {
    uint64_t hval = hashi(tup.key);
    EXPECT(-1 != hj_probe(hj, hval, &tup, sizeof(tup)));
  }

  EXPECT(-1 != hj_probe_spilled(hj));
}

static void print(const std::vector<std::string> &vec) {
  for (auto &s : vec) {
    printf("%s\n", s.c_str());
  }
}
