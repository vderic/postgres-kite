#include "hjin.hpp"

int main() {
  char *context = 0;
  hj_dispatch_t dispatch{};

  printf("\nJOIN IN\n\n");
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;
  hj = hj_open(context, HJ_IN, 100, ".", dispatch);
  EXPECT(hj);
  build();
  probe();
  hj_close(hj);

  std::sort(result.begin(), result.end());
  print(result);

  printf("\n");
  printf("hit_both = %d\n", count_hit_both);
  printf("hit_left = %d\n", count_hit_left);
  printf("hit_right = %d\n", count_hit_right);
  printf("\n");

  return 0;
}
