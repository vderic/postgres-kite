#include "hjpub.hpp"

int main() {
  /*
    -- INNER JOIN
    SELECT b.id, b.title, b.type, t.last_name AS translator
    FROM books b
    JOIN translators t
    ON b.translator_id = t.id
    ORDER BY b.id;
  */
  const std::vector<std::string> expected = {
      "2 | Your Trip | translated | Ling Weng",
      "5 | Oranges | translated | Ira Davies",
      "6 | Your Happy Life | translated | Kristian Green",
      "7 | Applied AI | translated | Roman Edwards",
  };
  std::vector<std::string> result;

  auto keyeq = [](void *context, void *pr, void *br) -> int {
    // translator[TRANSLATOR_ID] == book[BOOK_TRANSLATOR_ID]
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    return std::string{field(trans, TRANSLATOR_ID)} ==
           std::string{field(book, BOOK_TRANSLATOR_ID)};
  };
  auto match = [](void *context, void *pr, void *br) -> int {
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    std::string line;
    line.append(field(book, BOOK_ID));
    line.append(" | ");
    line.append(field(book, BOOK_TITLE));
    line.append(" | ");
    line.append(field(book, BOOK_TYPE));
    line.append(" | ");
    line.append(field(trans, TRANSLATOR_NAME));
    std::vector<std::string> *result = (std::vector<std::string> *)context;
    result->push_back(line);
    return 1;
  };

  hj_dispatch_t dispatch{};
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;
  hj_t *hj = hj_open(&result, HJ_INNER, 100, ".", dispatch);
  for (const char *rec : TRANSLATOR) {
    if (auto hkey = field(rec, TRANSLATOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      EXPECT(0 == hj_build(hj, hval, (char *)rec, strlen(rec)));
    }
  }
  for (const char *rec : BOOK) {
    if (auto hkey = field(rec, BOOK_TRANSLATOR_ID); hkey.length()) {
      auto hval = hashi(std::stoi(hkey));
      EXPECT(-1 != hj_probe(hj, hval, (char *)rec, strlen(rec)));
    }
  }
  EXPECT(-1 != hj_probe_spilled(hj));

  std::sort(result.begin(), result.end());
  print(result);

  EXPECT(result == expected);
  hj_close(hj);
  return 0;
}
