#include "hjpub.hpp"

int main() {
  /*
    -- LEFT JOIN
    SELECT b.id, b.title, b.type, t.name AS translator
    FROM books b
    LEFT JOIN translators t ON b.translator_id = t.id
    ORDER BY b.id;
  */
  const std::vector<std::string> expected = {
      "1 | Time to Grow Up! | original | NULL",
      "2 | Your Trip | translated | Ling Weng",
      "3 | Lovely Love | original | NULL",
      "4 | Dream Your Life | original | NULL",
      "5 | Oranges | translated | Ira Davies",
      "6 | Your Happy Life | translated | Kristian Green",
      "7 | Applied AI | translated | Roman Edwards",
      "8 | My Last Book | original | NULL"};
  std::vector<std::string> result;

  auto keyeq = [](void *context, void *pr, void *br) -> int {
    // book[BOOK_TRANSLATOR_ID] == translator[TRANSLATOR_ID]
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    return std::string{field(trans, TRANSLATOR_ID)} ==
           std::string{field(book, BOOK_TRANSLATOR_ID)};
  };
  auto match = [](void *context, void *pr, void *br) -> int {
    (void)context;
    const char *trans = (const char *)br;
    const char *book = (const char *)pr;
    std::string line;
    line.append(field(book, BOOK_ID));
    line.append(" | ");
    line.append(field(book, BOOK_TITLE));
    line.append(" | ");
    line.append(field(book, BOOK_TYPE));
    line.append(" | ");
    if (trans) {
      line.append(field(trans, TRANSLATOR_NAME));
    } else {
      line.append("NULL");
    }
    std::vector<std::string> *result = (std::vector<std::string> *)context;
    result->push_back(line);
    return 1;
  };

  hj_dispatch_t dispatch{};
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;
  hj_t *hj = hj_open(&result, HJ_LEFT, 100, ".", dispatch);
  for (const char *rec : TRANSLATOR) {
    auto hkey = field(rec, TRANSLATOR_ID);
    auto hval = hashi(std::stoi(hkey));
    EXPECT(0 == hj_build(hj, hval, (void *)rec, strlen(rec)));
  }
  for (const char *rec : BOOK) {
    auto hkey = field(rec, BOOK_TRANSLATOR_ID);
    auto hval = hashi(hkey == "" ? -1 : std::stoi(hkey));
    EXPECT(-1 != hj_probe(hj, hval, (void *)rec, strlen(rec)));
  }
  EXPECT(-1 != hj_probe_spilled(hj));

  std::sort(result.begin(), result.end());
  print(result);

  EXPECT(result == expected);
  hj_close(hj);

  return 0;
}
