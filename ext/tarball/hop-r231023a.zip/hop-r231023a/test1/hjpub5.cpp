#include "hjpub.hpp"

int main() {
  /*
    -- FULL JOIN
    SELECT b.id, b.title, e.name AS editor
    FROM books b
    FULL JOIN editors e
    ON b.editor_id = e.id
    ORDER BY b.id;
  */
  const std::vector<std::string> expected = {
      "1 | Time to Grow Up! | Daniel Brown",
      "2 | Your Trip | Mark Johnson",
      "3 | Lovely Love | Cathrine Roberts",
      "4 | Dream Your Life | Cathrine Roberts",
      "5 | Oranges | Sebastian Wright",
      "6 | Your Happy Life | Mark Johnson",
      "7 | Applied AI | Maria Evans",
      "8 | My Last Book | NULL",
      "NULL | NULL | Barbara Jones",
      "NULL | NULL | Matthew Smith",
  };
  std::vector<std::string> result;

  auto keyeq = [](void *context, void *pr, void *br) -> int {
    // book[BOOK_EDITOR_ID] == editor[EDITOR_ID]
    (void)context;
    const char *book = (const char *)br;
    const char *editor = (const char *)pr;
    return std::string{field(editor, EDITOR_ID)} ==
           std::string{field(book, BOOK_EDITOR_ID)};
  };
  auto match = [](void *context, void *pr, void *br) -> int {
    (void)context;
    const char *book = (const char *)br;
    const char *editor = (const char *)pr;
    std::string line;
    if (book) {
      line.append(field(book, BOOK_ID));
      line.append(" | ");
      line.append(field(book, BOOK_TITLE));
      line.append(" | ");
    } else {
      line.append("NULL");
      line.append(" | ");
      line.append("NULL");
      line.append(" | ");
    }
    if (editor) {
      line.append(field(editor, EDITOR_NAME));
    } else {
      line.append("NULL");
    }
    std::vector<std::string> *result = (std::vector<std::string> *)context;
    result->push_back(line);
    return 1;
  };

  hj_dispatch_t dispatch{};
  dispatch.testfn = keyeq;
  dispatch.emitfn = match;
  hj_t *hj = hj_open(&result, HJ_FULL, 100, ".", dispatch);
  for (const char *rec : BOOK) {
    auto hkey = field(rec, BOOK_EDITOR_ID);
    auto hval = hashi(std::stoi(hkey));
    EXPECT(0 == hj_build(hj, hval, (char *)rec, strlen(rec)));
  }
  for (const char *rec : EDITOR) {
    auto hkey = field(rec, EDITOR_ID);
    auto hval = hashi(std::stoi(hkey));
    EXPECT(-1 != hj_probe(hj, hval, (char *)rec, strlen(rec)));
  }
  EXPECT(-1 != hj_probe_spilled(hj));

  std::sort(result.begin(), result.end());
  print(result);
  EXPECT(result == expected);

  hj_close(hj);
  return 0;
}
