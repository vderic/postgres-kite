#pragma once

extern "C" {
#include "../src/hashjoin.h"
#include "harness.h"
}

#include <algorithm>
#include <string>
#include <vector>

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the left side of the join
typedef struct proberec_t proberec_t;
struct proberec_t {
  int side;
  int key;
  int value;
};
static int is_proberec(const void *p) { return ((proberec_t *)p)->side == 'P'; }

// Tuples from the right side of the join
typedef struct buildrec_t buildrec_t;
struct buildrec_t {
  int side;
  char key[100];
  int value;
};
static int is_buildrec(const void *p) { return ((buildrec_t *)p)->side == 'B'; }

// Get the next left tuple
// even numbers [2,4,6,...,200]
static int get_proberec(proberec_t *tp) {
  static int serial = 0;
  if (serial >= 200) {
    return -1;
  }
  serial += 2;

  tp->side = 'P';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple
// serial [1..100]
static int get_buildrec(buildrec_t *tp) {
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  memset(tp, 0, sizeof(*tp)); // silent valgrind
  tp->side = 'B';
  sprintf(tp->key, "%d", serial);
  tp->value = serial;

  return 0;
}

int count_hit_both = 0;
int count_hit_right = 0;
int count_hit_left = 0;
std::vector<std::string> result;

static void print(std::vector<std::string> &vec) {
  sort(vec.begin(), vec.end());
  for (auto &s : vec) {
    printf("%s\n", s.c_str());
  }
}

static int match(void *context, void *pr, void *br) {
  (void)context;
  EXPECT(!br || is_buildrec(br));
  EXPECT(!pr || is_proberec(pr));
  auto RP = (const buildrec_t *)br;
  auto LP = (const proberec_t *)pr;
  char out[1000];

  if (!LP) {
    sprintf(out, "hit (- - -) (%c %s %d)", RP->side, RP->key, RP->value);
    count_hit_right++;
  } else if (!RP) {
    sprintf(out, "hit (%c %d %d) (- - -)", LP->side, LP->key, LP->value);
    count_hit_left++;
  } else {
    sprintf(out, "hit (%c %d %d) (%c %s %d)", LP->side, LP->key, LP->value,
            RP->side, RP->key, RP->value);
    count_hit_both++;
  }
  result.push_back(out);
  return 1;
}

static int keyeq(void *context, void *pr, void *br) {
  (void)context;
  EXPECT(is_buildrec(br));
  EXPECT(is_proberec(pr));
  auto RP = (const buildrec_t *)br;
  auto LP = (const proberec_t *)pr;
  return LP->key == atoi(RP->key);
}

hj_t *hj = 0;

// Scan right side and feed to hj
static void build() {

  // For each tuple from RIGHT side
  for (;;) {
    buildrec_t tup;
    if (get_buildrec(&tup)) {
      break;
    }
    uint64_t hval = hashi(atoi(tup.key));

    EXPECT(0 == hj_build(hj, hval, &tup, sizeof(tup)));
  }
}

static void probe() {

  // For each tuple from LEFT side
  for (;;) {
    proberec_t tup;
    if (get_proberec(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    EXPECT(-1 != hj_probe(hj, hval, &tup, sizeof(tup)));
  }

  EXPECT(-1 != hj_probe_spilled(hj));
}
