echo Make ...
(cd ..; make -j8) > /dev/null || { echo "Make failed!"; exit 1; }

mkdir -p out
for i in ch{1..1} hagg{1..7} hj{1..5} hjpub{1..5} hjin{1..2} sort{1..100}; do
    F=$i
    if [ -f $F ]; then
	echo $F
	./$F > out/$F.out || { echo "FAILED!"; exit 1; }
	diff out/$F.out good/$F.out || { echo "FAILED!"; exit 1; }
    fi
done
