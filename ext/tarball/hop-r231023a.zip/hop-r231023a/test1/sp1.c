#include "../src/arena.h"
#include "../src/chtab.h"
#include "../src/spill.h"
#include "../src/spill_file.h"
#include "harness.h"

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the left side of the join
typedef struct left_t left_t;
struct left_t {
  int side;
  int key;
  int value;
};
static int is_left(const left_t *tp) { return tp->side == 'L'; }

// Tuples from the right side of the join
typedef struct right_t right_t;
struct right_t {
  int side;
  char key[100];
  int value;
};
static int is_right(const right_t *tp) { return tp->side == 'R'; }

// Get the next left tuple
static int get_left(left_t *tp) {
  // left table has tuples with keys from 1..100
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  tp->side = 'L';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple
static int get_right(right_t *tp) {
  // right table has tuples with keys from 1..300
  static int serial = 0;
  if (serial >= 1200) {
    return -1;
  }
  serial++;

  memset(tp, 0, sizeof(*tp));
  tp->side = 'R';
  sprintf(tp->key, "%d", 1 + (serial % 300));
  tp->value = -serial;

  return 0;
}

static arena_t *arena = 0;
static chtab_t *chtab = 0;
static spill_t *spill = 0;
static const int64_t MEMLIMIT = 200; // 200 byte before spilling
static char errmsg[200];

static void spill_left(const left_t *rec, uint64_t hval) {
  int do_expand =
      (spill->N == 0) || (spill->nbyte >= MEMLIMIT * (1 << (spill->N)));
  if (do_expand) {
    // Double the spill buckets if total #bytes in spill
    // exceeds nbucket * MEMLIMIT
    CHECK(0 == spill_expand(spill, errmsg, sizeof(errmsg)));
  }
  CHECK(spill->N > 0);

  int len = sizeof(*rec);
  void *ptr =
      spill_emplace(spill, SPILL_BUILD, hval, len, errmsg, sizeof(errmsg));
  CHECK(ptr);
  memcpy(ptr, rec, len);
}

// The hash table stores linked lists of left_atom_t;
typedef struct left_atom_t left_atom_t;
struct left_atom_t {
  left_t rec;
  left_atom_t *next;
};

static void insert_left(const left_t *rec, uint64_t hval) {
  // make a copy of left rec into atom
  left_atom_t *atom = arena_alloc(arena, sizeof(*atom));
  CHECK(atom);
  atom->rec = *rec;
  void **pp = chtab_emplace(chtab, hval);
  CHECK(pp);
  atom->next = *pp;
  *pp = atom;
}

static void build0() {
  // for each tuple from the LEFT side
  for (;;) {
    left_t tup;
    if (get_left(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    // if hashtable is smaller than MEMLIMIT, insert into the htab
    if (arena_size(arena) < MEMLIMIT) {
      insert_left(&tup, hval);
    }
    // Else if htab already has that hval, insert into the htab
    else if (chtab_find(chtab, hval)) {
      insert_left(&tup, hval);
    }
    // Else spill the tuple
    else {
      spill_left(&tup, hval);
    }
  }
}

static void build(int spid) {
  chtab_reset(chtab);
  arena_reset(arena);

  // always flush before opening files
  CHECK(0 == spill_flush(spill, errmsg, sizeof(errmsg)));

  // Open spill file
  const char *path = spill_path_for_build(spill, spid);
  if (!path) {
    return;
  }
  spf_t *scan = spf_scan(path, errmsg, sizeof(errmsg));
  CHECK(scan);

  // For each build-tuple
  for (;;) {
    spill_rec_t *rec;
    if (spf_next(scan, &rec, errmsg, sizeof(errmsg))) {
      CHECK(0);
    }
    if (!rec) {
      break; // EOF
    }
    const left_t *tp = (left_t *)rec->raw;
    CHECK(rec->len == sizeof(*tp));
    CHECK(is_left(tp));

    uint64_t hval = rec->hval;

    /* Add record to either hj->tab or other (higher up) spill build buckets */
    int destid = spill_id(spill, hval);
    if (spid == destid) {
      insert_left(tp, hval);
    } else {
      spill_left(tp, hval);
    }
  }

  spf_close(scan, /*truncate*/ 1, 0, 0);
}

/* record hits and misses */
int count_hit = 0;
int count_miss = 0;

static void hit(const left_t *LP, const right_t *RP) {
  CHECK(LP->side == 'L');
  CHECK(RP->side == 'R');
  printf("hit (%c %d %d) (%c %s %d)\n", LP->side, LP->key, LP->value, RP->side,
         RP->key, RP->value);
  count_hit++;
}

static void miss(const right_t *RP) {
  CHECK(RP->side == 'R');
  printf("miss (%c %s %d)\n", RP->side, RP->key, RP->value);
  count_miss++;
}

static void probe0() {
  // For each tuple from RIGHT side
  for (;;) {
    right_t tup;
    if (get_right(&tup)) {
      break;
    }
    uint64_t hval = hashi(atoi(tup.key));

    // if the hval is in the htab, match with either hit or miss.
    void **pp = chtab_find(chtab, hval);
    if (pp) {
      int hitflag = 0;
      for (left_atom_t *atom = *pp; atom; atom = atom->next) {
        if (atom->rec.key == atoi(tup.key)) {
          hit(&atom->rec, &tup);
          hitflag = 1;
        }
      }
      if (!hitflag) {
        miss(&tup);
      }
      // Done! because build0() would not spill records with this hval.
      // i.e. this hval does not exist in any build-side spill buckets.
      continue;
    }

    // if not spilling, yet, then we have a miss. Done.
    if (spill->nrow == 0) {
      miss(&tup);
      continue;
    }

    // if spill knows this tup does not match a build tuple. it is a miss.
    if (spill_can_ignore(spill, hval)) {
      miss(&tup);
      continue;
    }

    // spill this tuple. It may match a build-tuple already in the spill.
    int len = sizeof(tup);
    void *ptr = spill_emplace(spill, SPILL_PROBE, hval, sizeof(tup), errmsg,
                              sizeof(errmsg));
    CHECK(ptr);
    memcpy(ptr, &tup, len);
  }
}

static void probe(int id) {

  CHECK(0 == spill_flush(spill, errmsg, sizeof(errmsg)));

  const char *path = spill_path_for_probe(spill, id);
  if (!path) {
    return;
  }

  spf_t *scan = spf_scan(path, errmsg, sizeof(errmsg));
  CHECK(scan);

  for (;;) {
    spill_rec_t *rec;
    if (spf_next(scan, &rec, errmsg, sizeof(errmsg))) {
      CHECK(0);
    }
    if (!rec) {
      break; /* EOF */
    }

    uint64_t hval = rec->hval;

    const right_t *tp = (right_t *)rec->raw;
    CHECK(rec->len == sizeof(*tp));
    CHECK(is_right(tp));

    // match against build tuples in chtab
    void **pp = chtab_find(chtab, hval);
    if (pp) {
      int hitflag = 0;
      for (left_atom_t *atom = *pp; atom; atom = atom->next) {
        if (atom->rec.key == atoi(tp->key)) {
          hit(&atom->rec, tp);
          hitflag = 1;
        }
      }
      if (!hitflag) {
        miss(tp);
      }
    }
  }

  spf_close(scan, /*truncate*/ 1, 0, 0);
}

int main() {
  spill = spill_create(".");
  CHECK(spill);
  arena = arena_create();
  CHECK(arena);
  chtab = chtab_create();
  CHECK(chtab);

  {
    printf("\n---- id %d \n", 0);
    build0();
    probe0();
  }

  for (int id = 0; spill_has_id(spill, id); id++) {
    printf("\n---- id %d \n", id);
    build(id);
    probe(id);
  }

  printf("\n");
  printf("#hit = %d\n", count_hit);
  printf("#miss = %d\n", count_miss);

  CHECK(count_hit == 400);
  CHECK(count_miss == 800);

  spill_destroy(spill);
  chtab_destroy(chtab);
  arena_destroy(arena);

  return 0;
}
