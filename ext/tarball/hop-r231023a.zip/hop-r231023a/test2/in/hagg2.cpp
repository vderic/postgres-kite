#include "rel.hpp"
extern "C" {
#include "../../src/hashagg.h"
};

// --------------------------------
// This test will test agg like this:
//
// CREATE temp table R(a int, b int);
// INSERT into R (select (i,i) from generate_series(1,100) i);
// UPDATE R set a = (b - 1) % 3;
// SELECT a, count(b), sum(b) FROM R GROUP BY 1;
//  a | count | sum
// ---+-------+------
//  0 |    34 | 1717
//  1 |    33 | 1650
//  2 |    33 | 1683
// (3 rows)

// Our agg will store count and sum
typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  int count = 0;
  int sum = 0;
};

int64_t aggdata_memusage = 0;

// On init: alloc memory for aggdata associated with rec and initialize with
// count and sum.
static void *init(void *context) {
  (void)context;
  aggdata_t *dp = new aggdata_t();
  aggdata_memusage += sizeof(*dp);
  return dp;
}

// On transition: update count and sum of aggdata related to rec
static void *trans(void *context, void *rec, void *data) {
  (void)context;
  row_t *row = (row_t *)rec;
  aggdata_t *dp = (aggdata_t *)data;
  dp->count++;
  dp->sum += row->b;
  return dp;
}

// On emit: save results and free aggdata allocated
int emit_cnt = 0;
static int emit(void *context, void *rec, void *data) {
  (void)context;
  row_t *row = (row_t *)rec;
  aggdata_t *dp = (aggdata_t *)data;
  if (emit_cnt == 0) {
    // print column names
    printf("%s\t%s\t%s\n", "A", "count", "sum");
  }
  printf("%d\t%d\t%d\n", row->a, dp->count, dp->sum);
  aggdata_memusage -= sizeof(*dp);
  delete dp;
  emit_cnt++;
  return 1;
}

static void test1() {
  printf("\nInner hashjoin with a bad hash function\n");
  // R: [(0,1),(1,2),(2,3),
  //     (0,4),(1,5),(2,6),
  //     (0,7),(1,8),(2,9), ...]
  rel_t R;
  R.insert_range(1, 100);
  for (auto &row : R) {
    row.a = (row.b - 1) % 3;
  }

  hagg_dispatch_t dispatch{};
  dispatch.keyeqfn = keyeq_a;
  dispatch.initfn = init;
  dispatch.transfn = trans;
  dispatch.emitfn = emit;

  int64_t aggdata_memusage = 0;
  auto agg = hagg_open((void *)1, 100, &aggdata_memusage, ".", dispatch);

  // feed
  for (auto &row : R) {
    auto hval = bad_hash(row);
    CHECK(0 == hagg_feed(agg, hval, &row, sizeof(row)));
  }

  CHECK(0 == hagg_finalize(agg));
  hagg_close(agg);

  printf("\n[%d row%s]\n\n", emit_cnt, emit_cnt > 1 ? "s" : "");
  CHECK(aggdata_memusage == 0);
}

static void test2() {
  printf("\nInner hashjoin with a bad hash function, finalize iteratively.\n");
  // R: [(0,1),(1,2),(2,3),
  //     (0,4),(1,5),(2,6),
  //     (0,7),(1,8),(2,9), ...]
  rel_t R;
  R.insert_range(1, 100);
  for (auto &row : R) {
    row.a = (row.b - 1) % 3;
  }

  hagg_dispatch_t dispatch{};
  dispatch.keyeqfn = keyeq_a;
  dispatch.initfn = init;
  dispatch.transfn = trans;
  dispatch.emitfn = emit;

  int64_t aggdata_memusage = 0;
  auto agg = hagg_open((void *)1, 100, &aggdata_memusage, ".", dispatch);

  // feed
  for (auto &row : R) {
    auto hval = bad_hash(row);
    CHECK(0 == hagg_feed(agg, hval, &row, sizeof(row)));
  }

  // Finalize
  {
    hagg_iter_t iter;
    hagg_iter_t *it = &iter;
    void *rec;
    void *aggrec;
    char errmsg[200];
    CHECK(0 == hagg_iter_init(agg, it));
    emit_cnt = 0;
    while (1) {
      CHECK(0 == hagg_iter_next(it, &rec, &aggrec, errmsg, sizeof(errmsg)));
      if (!rec)
        break;
      CHECK(1 == emit((void *)1, rec, aggrec));
    }
  }
  hagg_close(agg);
  printf("\n[%d row%s]\n\n", emit_cnt, emit_cnt > 1 ? "s" : "");
  CHECK(aggdata_memusage == 0);
}

int main() {
  test1();
  test2();
  return 0;
}
