#include "rel.hpp"
extern "C" {
#include "../../src/hashjoin.h"
};

int main() {
  printf("select * from P /*HASH*/ FULL JOIN B on P.a = B.a;\n\n");

  rel_t B, P;
  P.insert_modulo(3, 1, 40);
  B.insert_modulo(4, 1, 40);

  hj_dispatch_t dispatch{};
  dispatch.testfn = keyeq_a;
  dispatch.emitfn = rel_emit2;

  rel_emit2_cnt = 0;
  hj_t *hj = hj_open((void *)1, HJ_FULL, 1024, ".", dispatch);
  CHECK(hj);

  for (auto &row : B) {
    auto hval = hash_a(row);
    CHECK(0 == hj_build(hj, hval, &row, sizeof(row)));
  }

  for (auto &row : P) {
    auto hval = hash_a(row);
    CHECK(-1 != hj_probe(hj, hval, &row, sizeof(row)));
  }

  CHECK(-1 != hj_probe_spilled(hj));

  hj_close(hj);

  printf("\n[%d %s]\n\n", rel_emit2_cnt, rel_emit2_cnt > 1 ? "rows" : "row");
  return 0;
}
