#include "rel.hpp"
extern "C" {
#include "../../src/mergejoin.h"
};

char errmsg[200];

int main() {
  printf("select * from P /*MERGE*/ INNER JOIN B on P.a = B.a;\n\n");

  rel_t R, L;
  R.insert_modulo(3, 1, 40); // [3,6,9,12,...]
  L.insert_modulo(4, 1, 40); // [4,8,12,16,...]

  // write R to an rfile. The id of the rfile is fid.
  rfile_registry_t *reg = rfile_registry_create("/tmp");
  CHECK(reg);
  rfile_t *rfile = rfile_create(reg, errmsg, sizeof(errmsg));
  CHECK(rfile);
  int fid = rfile_id(rfile);

  for (auto &row : R) {
    row_t *p =
        (row_t *)rfile_emplace(rfile, sizeof(row), 0, errmsg, sizeof(errmsg));
    *p = row;
  }
  CHECK(0 == rfile_close(rfile, 0, errmsg, sizeof(errmsg)));

  mj_dispatch_t dispatch{};
  dispatch.cmpfn = keycmp_a;
  dispatch.emitfn = rel_emit2;
  mj_t *mj = mj_open((void *)1, dispatch);

  // feed right
  rfile = rfile_scan(reg, fid, errmsg, sizeof(errmsg));
  CHECK(rfile);
  CHECK(0 == mj_feed_right(mj, rfile));

  // feed left
  for (auto &row : L) {
    CHECK(0 == mj_feed_left(mj, &row));
  }

  rfile_close(rfile, 1, 0, 0);

  mj_close(mj);
  rfile_registry_destroy(reg);

  printf("\n[%d %s]\n\n", rel_emit2_cnt, rel_emit2_cnt > 1 ? "rows" : "row");
  CHECK(3 == rel_emit2_cnt);
  return 0;
}
