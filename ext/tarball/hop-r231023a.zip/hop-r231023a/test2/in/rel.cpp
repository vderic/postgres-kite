#include "rel.hpp"
extern "C" {
#include "../../src/komihash.h"
}
#include <assert.h>

static int rowkeygen = 1;

row_t::row_t(int x) : key(rowkeygen++) { a = b = c = x; }

void rel_t::insert_modulo(int modulo, int start, int stop) {
  if (start < stop) {
    for (int i = start; i <= stop; i++) {
      if (0 == (i % modulo)) {
        push_back({i});
      }
    }
  } else {
    for (int i = start; i >= stop; i--) {
      if (0 == (i % modulo)) {
        push_back({i});
      }
    }
  }
}

void rel_t::insert_range(int start, int stop) {
  if (start < stop) {
    for (int i = start; i <= stop; i++) {
      push_back({i});
    }
  } else {
    for (int i = start; i >= stop; i--) {
      push_back({i});
    }
  }
}

void rel_t::shuffle() {
  int n = size();
  auto &me = *this;
  for (int i = 0; i < n; i++) {
    int j = i + rand() % (n - i);
    row_t tmp = me[j];
    me[j] = me[i];
    me[i] = tmp;
  }
}

int fatal(const char *file, int line) {
  fprintf(stderr, "fatal: (%s:%d)\n", file, line);
  assert(0);
  abort();
  return -1;
}

int keyeq_a(void *context, void *rec1, void *rec2) {
  CHECK(context == (void *)1); // always set to 1
  row_t *r1 = (row_t *)rec1;
  row_t *r2 = (row_t *)rec2;
  return r1->a == r2->a;
}

int keycmp_a(void *context, void *rec1, void *rec2) {
  CHECK(context == (void *)1); // always set to 1
  row_t *r1 = (row_t *)rec1;
  row_t *r2 = (row_t *)rec2;
  return r1->a > r2->a ? 1 : (r1->a == r2->a ? 0 : -1);
}

int64_t hash_a(const row_t &row) { return komihash(&row.a, sizeof(row.a), 0); }

int rel_emit2_cnt = 0;

static void rel_emit2_header() {
  printf(" r1.key   r1.a   r1.b   r1.c   r2.key   r2.a   r2.b   r2.c\n");
  printf("--------|------|------|------|--------|------|------|------\n");
}

int rel_emit2(void *context, void *rec1, void *rec2) {
  if (rel_emit2_cnt == 0) {
    rel_emit2_header();
  }
  rel_emit2_cnt++;

  CHECK(context == (void *)1);
  row_t *r1 = (row_t *)rec1;
  row_t *r2 = (row_t *)rec2;

  if (r1) {
    printf("    %3d    %3d    %3d    %3d  ", r1->key, r1->a, r1->b, r1->c);
  } else {
    printf("      x      x      x      x  ");
  }

  if (r2) {
    printf("    %3d    %3d    %3d    %3d\n", r2->key, r2->a, r2->b, r2->c);
  } else {
    printf("      x      x      x      x\n");
  }

  return 1;
}

rel_t rel_emit1_dest;
int rel_emit1(void *context, void *rec) {

  CHECK(context == (void *)1);
  row_t *row = (row_t *)rec;
  rel_emit1_dest.push_back(*row);
  return 1;
}
