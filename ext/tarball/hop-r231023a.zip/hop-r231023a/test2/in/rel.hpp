#pragma once

#include <cstdio>
#include <cstdlib>
#include <vector>

struct row_t {
  int key;
  int a, b, c;

  row_t(int x = 0);
};

static inline bool operator==(const row_t &x, const row_t &y) {
  return x.key == y.key && x.a == y.a && x.b == y.b && x.c == y.c;
}

class rel_t : public std::vector<row_t> {
public:
  rel_t() = default;
  rel_t(int start, int stop) { insert_range(start, stop); }

  void insert_modulo(int modulo, int start, int stop);
  void insert_range(int start, int stop);
  void shuffle();
};

extern int fatal(const char *file, int line);
extern int keyeq_a(void *context, void *rec1, void *rec2);
extern int keycmp_a(void *context, void *rec1, void *rec2);

// hash row using column a.
extern int64_t hash_a(const row_t &row);

// a really bad hash function
static inline int64_t bad_hash(const row_t &row) {
  (void)row;
  return 1;
}

extern int rel_emit2_cnt;
extern int rel_emit2(void *context, void *pr, void *br);

extern rel_t rel_emit1_dest;
extern int rel_emit1(void *context, void *rec);

#define ALIGN8(x) (((x) + 7) & ~7)

#define CHECK(cond) ((cond) ? 0 : fatal(__FILE__, __LINE__))
