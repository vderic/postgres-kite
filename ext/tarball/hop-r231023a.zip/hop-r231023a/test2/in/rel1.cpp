#include "rel.hpp"
#include <cstring>

int main() {
  // reverse order
  rel_t rel{100, 1};
  for (int i = 0; i < 100; i++) {
    CHECK(rel[i].a == 100 - i);
  }

  // in order
  rel = rel_t{1, 100};
  for (int i = 0; i < 100; i++) {
    CHECK(rel[i].a == i + 1);
  }

  // shuffle
  {
    rel_t shuffled = rel;
    shuffled.shuffle();

    int tmp[100];
    memset(tmp, 0, sizeof(tmp));
    int count = 0;

    for (int i = 0; i < 100; i++) {
      auto v = shuffled[i].a;
      CHECK(1 <= v && v <= 100);
      CHECK(tmp[v - 1] == 0);
      tmp[v - 1] = v;

      if (v != i + 1) {
        count++;
      }
    }
    CHECK(0 != count);
    for (int i = 0; i < 100; i++) {
      CHECK(tmp[i] == i + 1);
    }
  }

  return 0;
}
