#include "rel.hpp"
#include <cstring>

extern "C" {
#include "../../src/rfile.h"
}

// Write 100 recs
// return the rfile id
static int test_write(rfile_registry_t *reg, char *errmsg, int errlen) {
  auto rfile = rfile_create(reg, errmsg, errlen);
  CHECK(rfile);

  auto id = rfile_id(rfile);

  // write the file
  rel_t rel{1, 100};
  for (int i = 0; i < 100; i++) {
    auto &row = rel[i];
    int64_t hval = hash_a(row);
    void *p = rfile_emplace(rfile, sizeof(row), hval, errmsg, errlen);
    CHECK(p);

    memcpy(p, &rel[i], sizeof(row));
  }

  CHECK(0 == rfile_close(rfile, 0, errmsg, errlen));

  return id;
}

// Read 100 recs
static void test_read(rfile_registry_t *reg, int id, char *errmsg, int errlen) {
  auto rfile = rfile_scan(reg, id, errmsg, errlen);
  CHECK(rfile);

  int i = 0;
  for (;;) {
    row_t *rec;
    int len;
    int64_t hval;

    CHECK(0 == rfile_next(rfile, (void **)&rec, &len, &hval, errmsg, errlen));
    if (!rec) {
      break; // EOF
    }

    CHECK(rec->a == i + 1);

    i++;
  }

  CHECK(i == 100);

  CHECK(0 == rfile_close(rfile, 0, errmsg, errlen));
}

// Read [1..10], mark, read [11..30], restore, read [11..30]
static void test_mark(rfile_registry_t *reg, int id, char *errmsg, int errlen) {

  auto rfile = rfile_scan(reg, id, errmsg, errlen);
  CHECK(rfile);

  // read rec [1..10]
  for (int i = 0; i < 10; i++) {
    row_t *rec;
    int len;
    int64_t hval;

    CHECK(0 == rfile_next(rfile, (void **)&rec, &len, &hval, errmsg, errlen));
    if (!rec) {
      break; // EOF
    }

    CHECK(rec->a == i + 1);
  }

  // remember the position of record 11
  auto mark = rfile_mark(rfile);
  CHECK(mark >= 0);

  // read rec [11..30]
  for (int i = 10; i < 30; i++) {
    row_t *rec;
    int len;
    int64_t hval;

    CHECK(0 == rfile_next(rfile, (void **)&rec, &len, &hval, errmsg, errlen));
    if (!rec) {
      break; // EOF
    }

    CHECK(rec->a == i + 1);
  }

  // go back to record 11
  CHECK(0 == rfile_restore(rfile, mark, errmsg, errlen));

  // read rec [11..30]
  for (int i = 10; i < 30; i++) {
    row_t *rec;
    int len;
    int64_t hval;

    CHECK(0 == rfile_next(rfile, (void **)&rec, &len, &hval, errmsg, errlen));
    if (!rec) {
      break; // EOF
    }

    CHECK(rec->a == i + 1);
  }

  CHECK(0 == rfile_close(rfile, 0, errmsg, errlen));
}

int main() {
  char errmsg[200];
  int errlen = sizeof(errmsg);

  auto reg = rfile_registry_create("/tmp");
  CHECK(reg);
  CHECK(0 == strcmp("/tmp", rfile_registry_spilldir(reg)));

  auto id = test_write(reg, errmsg, errlen);
  CHECK(id > 0);

  test_read(reg, id, errmsg, errlen);

  test_mark(reg, id, errmsg, errlen);

  rfile_registry_destroy(reg);
}
