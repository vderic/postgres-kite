#include "rel.hpp"
extern "C" {
#include "../../src/extsort.h"
};

int main() {
  extsort_dispatch_t dispatch{};
  dispatch.keycmpfn = keycmp_a;

  printf("Open sort and close. Check valgrind for 0 mem leak.\n");
  auto srt = extsort_open(0, 4 * 100, ".", dispatch);
  CHECK(srt);

  // There is no records. Emitfn should not be called.
  CHECK(0 == extsort_emit(srt, rel_emit1));

  extsort_close(srt);
  return 0;
}
