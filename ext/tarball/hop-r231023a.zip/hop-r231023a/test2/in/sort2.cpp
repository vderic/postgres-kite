#include "rel.hpp"
extern "C" {
#include "../../src/extsort.h"
};

int main() {
  extsort_dispatch_t dispatch{};
  dispatch.keycmpfn = keycmp_a;

  printf("Sort 50 rows in 100-row mem buffer; no spill.\n");
  auto srt =
      extsort_open((void *)1, ALIGN8(sizeof(row_t)) * 100, ".", dispatch);
  CHECK(srt);

  // Feed
  rel_t sorted{1, 50};
  rel_t shuffled = sorted;
  shuffled.shuffle();

  for (auto &row : shuffled) {
    CHECK(0 == extsort_feed(srt, &row, sizeof(row)));
  }

  // Emit
  CHECK(0 == extsort_emit(srt, rel_emit1));
  extsort_close(srt);

  // Verify
  CHECK(sorted == rel_emit1_dest);

  return 0;
}
