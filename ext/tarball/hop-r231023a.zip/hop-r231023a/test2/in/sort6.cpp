#include "rel.hpp"
extern "C" {
#include "../../src/extsort.h"
};

static void test1() {
  extsort_dispatch_t dispatch{};
  dispatch.keycmpfn = keycmp_a;

  printf("\nSort a sorted array...\n");
  auto srt =
      extsort_open((void *)1, ALIGN8(sizeof(row_t)) * 100, ".", dispatch);
  CHECK(srt);

  // Feed
  rel_t sorted{1, 10000};
  for (auto &row : sorted) {
    CHECK(0 == extsort_feed(srt, &row, sizeof(row)));
  }

  // Emit
  CHECK(0 == extsort_emit(srt, rel_emit1));
  extsort_close(srt);

  // Verify
  CHECK(sorted == rel_emit1_dest);
}

static void test2() {
  extsort_dispatch_t dispatch{};
  dispatch.keycmpfn = keycmp_a;

  printf("\nSort a reversed array...\n");
  auto srt =
      extsort_open((void *)1, ALIGN8(sizeof(row_t)) * 100, ".", dispatch);
  CHECK(srt);

  // Feed
  rel_t reversed{10000, 1};
  for (auto &row : reversed) {
    CHECK(0 == extsort_feed(srt, &row, sizeof(row)));
  }

  // Emit
  rel_emit1_dest.clear();
  CHECK(0 == extsort_emit(srt, rel_emit1));
  extsort_close(srt);

  // Verify
  for (int i = 0; i < 10000; i++) {
    CHECK(rel_emit1_dest[i].a == i + 1);
  }
}

int main() {
  printf("Sort 10000 rows in 100-row mem buffer; level 3 spill.\n");
  test1();
  test2();
  return 0;
}
