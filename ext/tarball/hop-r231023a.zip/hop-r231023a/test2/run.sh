echo Make ...
(cd ..; make -j8) > /dev/null || { echo "Make failed!"; exit 1; }

mkdir -p out
for i in rel1 hj{1..10} mj1 sort{1..10} hagg{1..10}; do
    F=$i
    if [ -f in/$F ]; then
	echo $F
	./in/$F > out/$F.out || { echo "FAILED!"; exit 1; }
	diff out/$F.out good/$F.out || { echo "FAILED!"; exit 1; }
    fi
done
