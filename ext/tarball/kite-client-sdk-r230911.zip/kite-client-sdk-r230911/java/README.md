Run ``mvn clean package`` to build
